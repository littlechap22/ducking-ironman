M-GEMMA Map-Matching Algorithm README

Requirements:
Apart from a C++ compiler, no other special requirements are needed.

Compile:
# ./compile.sh

Run:
# ./run.sh

Help (to get more information about the available flags):
# ./mgemma -h


Map description:
The map is located in data/map.txt
The first line has the number of nodes (N) in the map.
Each of the N following lines have: [Node ID] [Longitude] [Latitude] [Average SNR] [DOP].
After that, there is another line with the number of links (L).
Each of the following L lines have: [Start Node ID] [End Node ID] [Average Speed] [No. times crossed].

Trace input:
Traces are in NMEA format and are expected to be in folder data/nmea. All files with .txt extension are considered.
This folder can be changed using the flag -t.

Output:
Each processed trace, produces a .kml file which contains the results of the map matching.

