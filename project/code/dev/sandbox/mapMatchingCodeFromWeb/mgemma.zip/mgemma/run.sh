#!/bin/bash
./mgemma -M -t data/nmea/ > data/output.txt

