#!/bin/bash
rm mgemma
g++ src/*.cpp -O2 -Wall -o mgemma

