#include "MGEMMA.h"

namespace MapMatching {

	MGEMMA::MGEMMA(mapRepresentation::Map * map, Route * route, bool log)
		: trace (route->size(), INVALID_LINK)
	{
		this->map = map;
		this->route = route;
		out = NULL;

		params.D_LIMIT = 20.0;
		params.PROB_INVALID_LINK = 0.20;
		params.POP_SIZE = 50;
		params.DIRECT_PASS = 0.03;
		params.BEST_INDIVIDUAL_MATURITY = 75;

		params.TOLERANCE_LINKS = 5;
		params.TOLERANCE_SUPER_LINKS = 1;

		params.RECOMBINATION_PROB = 0.75;
		params.MUTATION_PROB = 0.01;
		params.TOURNAMENT_PROB_BEST_INDIVIDUAL = 0.60;
		
		params.W_AVG = 0.7;
		params.W_MAX = 1.0;
		params.W_MAX_MIN = 0.8;
		params.W_UNCOV = 5.5;
		params.W_GAP = 1.5;
		params.W_CONTLEN = 0.3;
		params.W_AVGDISC = 1;
		params.W_MAXDISC = 1;

		if (log)
		{
			stringstream ss;
			ss << "data" << FILE_SEPARATOR << route->getName() << "_genetic_log.txt";
			out = new std::ofstream(ss.str().c_str(), ios::ios_base::out|ios::ios_base::trunc);
		}
	}

	MGEMMA::~MGEMMA()
	{
		int i;

		for (i=0; i<matchedTraces.size(); i++)
			delete matchedTraces[i];

		for (i=0; i<shortMatchedTraces.size(); i++)
			delete shortMatchedTraces[i];

		for (i=0; i<unmatchInfo.size(); i++)
			delete unmatchInfo[i];

		if (out != NULL)
			delete out;
	}


	void MGEMMA::run(bool generateKML)
	{
		int i;
		std::set<int> gaps;
		std::vector<std::set<mapRepresentation::LinkKey> > allCandidates (route->size());

		MapMatching::MarchalBMatching marchalMatching(map, route);

		marchalMatching.run(true, false);
		std::vector<Path *> forwardsMatchedParts(marchalMatching.getMatched());

		marchalMatching.run(false, false);
		std::vector<Path *> backwardsMatchedParts(marchalMatching.getMatched());

		//std::cout << "Paths forwards:" << std::endl;
		//for (i=0; i<forwardsMatchedParts.size(); i++)
		//	forwardsMatchedParts[i]->printPath();

		//std::cout << "Paths backwards:" << std::endl;
		//for (i=0; i<backwardsMatchedParts.size(); i++)
		//	backwardsMatchedParts[i]->printPath();

		std::vector<int> points = reconstructMatchedTrace(&allCandidates, forwardsMatchedParts, backwardsMatchedParts);

		std::vector<std::pair<int, int> > segments(buildAmbiguousSegments(points));

		gaps = runGeneticOnAmbiguousSegments(segments, &allCandidates);

		constructOutput(gaps, forwardsMatchedParts, segments);

		if (generateKML)
		{
			kmlMatch::KMLBuilder kmlFile(map, route, trace, std::vector<pair<int, int> >(0), "youTrace");
			kmlFile.buildKML();
		}

		for (i=0; i<forwardsMatchedParts.size(); i++)
			delete forwardsMatchedParts[i];

		for (i=0; i<backwardsMatchedParts.size(); i++)
			delete backwardsMatchedParts[i];

	}

	std::vector<Path *> MGEMMA::getMatched()
	{
		std::vector<Path *> matched(matchedTraces.size());

		for (int i = 0; i < matchedTraces.size(); i++)
			matched[i] = new Path(*matchedTraces[i]);

		return matched;
	}

	std::vector<Path *> MGEMMA::getShortMatched()
	{
		std::vector<Path *> matched(shortMatchedTraces.size());

		for (int i = 0; i < shortMatchedTraces.size(); i++)
			matched[i] = new Path(*shortMatchedTraces[i]);

		return matched;
	}

	std::vector<unMatchInfo *> MGEMMA::getUnmatchedInfo()
	{
		std::vector<unMatchInfo *> unMatch(unmatchInfo.size());

		for (int i = 0; i < unmatchInfo.size(); i++)
			unMatch[i] = new unMatchInfo(*unmatchInfo[i]);

		return unMatch;
	}

	std::vector<int> MGEMMA::reconstructMatchedTrace(std::vector<std::set<mapRepresentation::LinkKey> > * candidates, std::vector<Path *>& forwardsMatchedParts, std::vector<Path *>& backwardsMatchedParts)
	{
		int i, j, k;
		bool add, conFS, conSF, sameSL;
		Point p;
		mapRepresentation::mLink tLink;
		std::set<int> temp;
		std::vector<int> criticalPoints;
		std::vector<mapRepresentation::LinkKey> pCandidates;

		for (i=0; i<forwardsMatchedParts.size(); i++)
		{
			for (j=0; j<forwardsMatchedParts[i]->path.size(); j++)
				if (forwardsMatchedParts[i]->path[j].first >= 0)
				{
					trace[forwardsMatchedParts[i]->path[j].first] = forwardsMatchedParts[i]->path[j].second;
					candidates->at(forwardsMatchedParts[i]->path[j].first).insert(forwardsMatchedParts[i]->path[j].second);
				}
		}

		for (i=0; i<backwardsMatchedParts.size(); i++)
		{
			for (j=0; j<backwardsMatchedParts[i]->path.size(); j++)
			{
				if (backwardsMatchedParts[i]->path[j].first >= 0)
					if (trace[backwardsMatchedParts[i]->path[j].first] != backwardsMatchedParts[i]->path[j].second)
					{
						conFS = map->isConnected(trace[backwardsMatchedParts[i]->path[j].first], backwardsMatchedParts[i]->path[j].second);
						conSF = map->isConnected(backwardsMatchedParts[i]->path[j].second, trace[backwardsMatchedParts[i]->path[j].first]);
						sameSL = map->belongSameSuperLink(trace[backwardsMatchedParts[i]->path[j].first], backwardsMatchedParts[i]->path[j].second);

						if ((!conFS && !conSF) || !sameSL)
						{
							trace[backwardsMatchedParts[i]->path[j].first] = INVALID_LINK;
							candidates->at(backwardsMatchedParts[i]->path[j].first).insert(backwardsMatchedParts[i]->path[j].second);
							temp.insert(backwardsMatchedParts[i]->path[j].first);
						}
					}
			}
		}

		for (i=0; i<(int)trace.size()-1; i++)
		{
			if ((trace[i] != INVALID_LINK && trace[i+1] == INVALID_LINK) || (i == 0 && trace[i] == INVALID_LINK))
			{
				for (j=i+1; j<(int)trace.size(); j++)
				{
					if ((trace[j-1] == INVALID_LINK && trace[j] != INVALID_LINK) || j + 1 == trace.size())
					{
						if (j+1==trace.size())
							j++;

						if (j - i <= 5)
						{
							for (k = (i==0 ? 0 : i+1); k<j; k++)
							{
								pCandidates = map->getNearestLinks(route->getLatitude(k), route->getLongitude(k), MAX_DIST_LINK);
								candidates->at(k).insert(pCandidates.begin(), pCandidates.end());
								temp.insert(k);
							}
						}

						i = j;
						break;
					}
				}
			}
		}

		// add points close to transitions
		for (i=0; i<forwardsMatchedParts.size(); i++)
		{
			if (forwardsMatchedParts[i]->path.front().first > 0)
			{
				k = min(forwardsMatchedParts[i]->path.front().first + 4, (int) route->size()-1);

				for (j = max(forwardsMatchedParts[i]->path.front().first - 2, 0); j <= k; j++)
					temp.insert(j);
			}

			if (forwardsMatchedParts[i]->path.back().first < (int) route->size()-1)
			{
				k = max(forwardsMatchedParts[i]->path.back().first - 4, 0);

				for (j = min(forwardsMatchedParts[i]->path.back().first + 2, (int) route->size()-1); j >= k; j--)
					temp.insert(j);
			}
		}

		//add always trace borders
		for (i=0; i<=2; i++)
		{
			pCandidates = map->getNearestLinks(route->getLatitude(i), route->getLongitude(i), MAX_DIST_LINK);
			candidates->at(i).insert(pCandidates.begin(), pCandidates.end());
			temp.insert(i);
		}

		for (i=(int)route->size()-3; i<=(int)route->size()-1; i++)
		{
			pCandidates = map->getNearestLinks(route->getLatitude(i), route->getLongitude(i), MAX_DIST_LINK);
			candidates->at(i).insert(pCandidates.begin(), pCandidates.end());
			temp.insert(i);
		}

		for (i=0; i<trace.size(); i++)
		{
			if (i<(int)trace.size()-2 && trace[i] != INVALID_LINK && trace[i+1] == INVALID_LINK)
			{
				k = max(i-3 , 0);
				add = true;

				for (j=k; j<i && add; j++)
					if (candidates->at(j).size() > 1)
						add = false;

				if (add)
					for (j=k; j<=i; j++)
						temp.insert(j);
			}


			if (i>1 && trace[i-1] == INVALID_LINK && trace[i] != INVALID_LINK)
			{
				k = min(i+2, (int)trace.size()-1);
				add = true;

				for (j=i; j<=k; j++)
					if (candidates->at(j).size() > 1)
						add = false;

				if (add)
					for (j=i-1; j<=k; j++)
						temp.insert(j);
			}
		}

		criticalPoints.insert(criticalPoints.begin(), temp.begin(), temp.end());
		return criticalPoints;
	}

	std::vector<std::pair<int, int> > MGEMMA::buildAmbiguousSegments(std::vector<int>& criticalPoints)
	{
		int i, first, last;
		std::vector<pair<int, int> > segments;

		if (!criticalPoints.empty())
		{
			sort(criticalPoints.begin(), criticalPoints.end());

			first = criticalPoints.front();
			last = criticalPoints.front();

			for (i=1; i<criticalPoints.size(); i++)
			{
				if (criticalPoints[i] - last > 3)
				{
					segments.push_back(std::pair<int, int> (max(first-2, 0), min(last+2, (int)route->size())));
					first = criticalPoints[i];
					last = criticalPoints[i];
				}
				else
					last = criticalPoints[i];
			}

			segments.push_back(std::pair<int, int> (max(first-2, 0), min(last+2, (int)route->size())));

			if (segments.front().first > 3)
				segments.insert(segments.begin(), std::pair<int, int> (0, min(3, (int)route->size())));
			else
				segments.front().first = 0;

			if (segments.back().second < (int) route->size() - 4)
				segments.push_back(std::pair<int, int> ((int) route->size() - 4, (int) route->size() - 1));
			else
				segments.back().second = (int) route->size() - 1;
		}
		else
		{
			if (route->size() <= 7)
				segments.push_back(std::pair<int, int> (0, (int)route->size()-1));
			else
			{
				segments.push_back(std::pair<int, int> (0, min(3, (int)route->size())));
				segments.push_back(std::pair<int, int> ((int) route->size()-4, (int) route->size()-1));
			}
		}

		return segments;
	}

	set<int> MGEMMA::runGeneticOnAmbiguousSegments(const std::vector<std::pair<int, int> >& segments, std::vector<std::set<mapRepresentation::LinkKey> > * candidates)
	{
		int i;
		set<int> fixed, gaps, tGaps;

		for (i=0; i<segments.size(); i++)
		{
			tGaps = runSegment(segments[i].first, segments[i].second, candidates);

			gaps.insert(tGaps.begin(), tGaps.end());
		}

		return gaps;
	}

	std::set<int> MGEMMA::runSegment(int startPoint, int endPoint, std::vector<std::set<mapRepresentation::LinkKey> > * candidates)
	{
		bool remove;
		int i, ptr, count;
		set<int> fixed, gaps;
		mapRepresentation::LinkKey lastLink;
		time_t start, end;
		time_t sInitPop, eInitPop;


		//std::cout << "Going to run segment from " << startPoint << " to " << endPoint << std::endl;

		ptr = startPoint;

		if (startPoint > 0)
		{
			fixed.insert(0);
			fixed.insert(1);
		}


		if (endPoint < (int)route->size()-1)
		{
			fixed.insert(endPoint - ptr);
			fixed.insert(endPoint - ptr - 1);
		}

		std::vector<std::set<mapRepresentation::LinkKey> > segCandidates((candidates->begin() + startPoint), (candidates->begin() + endPoint + 1));
			
		Route subRoute(route->subRoute(startPoint, endPoint));
		stringstream ss;
		ss << subRoute.getName() << "_ambSegment_" << startPoint << "_" << endPoint;
		subRoute.setName(ss.str());

		Distances dists(map, &subRoute, &segCandidates, fixed, out);

		Population pop(map, &subRoute, &dists, &params, 0, (int)subRoute.size(), out);

		pop.printPopulationStatistics();

		time(&sInitPop);
		pop.initializePopulation(fixed);
		time(&eInitPop);

		//populationInitTime += difftime(eInitPop, sInitPop);

		if (out != NULL)
		{
			(*out) << "## Initial population: ##" << std::endl;
			pop.printGeneration();
			(*out) << std::endl;
		}

		while (pop.getGeneration() - pop.getGenerationBestFromEver() <= params.BEST_INDIVIDUAL_MATURITY && pop.getGeneration() <= 5000)
		{
			pop.nextGeneration();

			if (pop.getGeneration() % 10 == 0)
				pop.printGenerationStatistics();
		}
	
		if (out != NULL)
				(*out) << "## Final population: ##" << std::endl;

		pop.printGeneration();
		pop.printBestIndividuals();

		Individual best = pop.getBestFromEver();

		for (i=0; i<best.getSize(); i++)
			trace[ptr+i] = best.getGene(i);

		if (best.getGapDistance() > 0)
		{
				std::vector<int> segGaps(pop.getIndividualGaps(best));

				for (i=0; i<segGaps.size(); i++)
					gaps.insert(ptr+segGaps[i]);
		}

		std::set<int> beginSegs;
		std::set<int>::iterator it, it2;
		beginSegs.insert(startPoint);

		for (i=startPoint+1; i<=endPoint; i++)
			if ((trace[i-1] == INVALID_LINK && trace[i] != INVALID_LINK) || (trace[i-1] != INVALID_LINK && trace[i] == INVALID_LINK))
				beginSegs.insert(i);
		beginSegs.insert(endPoint+1);

		for (it = gaps.begin(); it != gaps.end(); it++)
			beginSegs.insert((*it)+1);

		it = beginSegs.begin();
		it2 = beginSegs.begin();
		it2++;

		for ( ; it2 != beginSegs.end(); it++, it2++)
		{
			if (*it2 - *it <= 5  && trace[*it] != INVALID_LINK)
			{
				remove = true;
				count = 1;
				lastLink = trace[*it];

				for (i=*it; i<*it2 && remove; i++)
				{
					if (fixed.find(i-ptr) != fixed.end())
						remove = false;

					if (trace[i] != lastLink)
					{
						lastLink = trace[i];
						count++;
					}
				}

				if (remove && count < 3)
				{
					for (i=*it; i<*it2 && remove; i++)
						trace[i] = INVALID_LINK;
				}
			}
		}

		return gaps;
	}

	void MGEMMA::constructOutput(std::set<int>& gaps, const std::vector<Path *>& paths, const std::vector<std::pair<int, int> >& segments)
	{
		int i, j, k, last;
		unMatchInfo temp;
		std::vector<std::pair<int, mapRepresentation::LinkKey> > completeTrace;

		for (i=0; i<trace.size(); i++)
			completeTrace.push_back(std::pair<int, mapRepresentation::LinkKey> (i, trace[i]));

		for (i=(int)paths.size()-1; i>=0; i--)
		{
			last = (int)paths[i]->path.size() - 1;

			for (j=last-1; j>=0; j--)
			{
				if (paths[i]->path[j].first >= 0)
				{
					if (trace[paths[i]->path[j].first] == paths[i]->path[j].second && trace[paths[i]->path[last].first] == paths[i]->path[last].second)
					{
						if (last - j > 1)
							completeTrace.insert((completeTrace.begin()+paths[i]->path[j].first+1), (paths[i]->path.begin()+j+1), (paths[i]->path.begin()+last));
					}

					last = j;
				}
			}
		}

		for (i=0, j=0; i<segments.size(); i++)
		{
			for ( ; completeTrace[j].first != segments[i].first; j++)
				;

			for ( ; completeTrace[j].first <= segments[i].second-1; j++)
			{
				if (completeTrace[j].first >= 0 && completeTrace[j+1].first == 1 + completeTrace[j].first && gaps.find(completeTrace[j].first) == gaps.end())
				{
					if (completeTrace[j].second != INVALID_LINK && completeTrace[j+1].second != INVALID_LINK && !map->isConnected(completeTrace[j].second, completeTrace[j+1].second))
					{
						std::vector<mapRepresentation::LinkKey> links = map->getLinksBetween(completeTrace[j].second, completeTrace[j+1].second);

						for (k=(int)links.size()-1; k>=0; k--)
							completeTrace.insert((completeTrace.begin()+j+1), std::pair<int, mapRepresentation::LinkKey> (-1, links[k]));
					}
				}
			}
		}

		for (i=0; i<completeTrace.size(); i++)
		{
			if (completeTrace[i].first >= 0 && completeTrace[i].second != INVALID_LINK)
			{
				for (j=i+1; j<completeTrace.size(); j++)
					if (completeTrace[j].second == INVALID_LINK)
					{
						j--;
						break;
					}
					else if (completeTrace[j].second != INVALID_LINK && completeTrace[j-1].first >= 0 && completeTrace[j].first >= 0 && completeTrace[j-1].second != completeTrace[j].second && !map->isConnected(completeTrace[j-1].second, completeTrace[j].second))
					{
						j--;
						break;
					}
					else if (completeTrace[j].second != INVALID_LINK && j + 1 == completeTrace.size())
						break;

					if (j >= completeTrace.size())
						j = (int)completeTrace.size()-1;

				Path newPath;
				newPath.firstMatch = completeTrace[i].first;
				newPath.lastMatch = completeTrace[j].first;
				newPath.path.insert(newPath.path.begin(), (completeTrace.begin()+i), (completeTrace.begin()+j+1));
				matchedTraces.push_back(new Path(newPath));

				i = j;
			}
		}

		if (matchedTraces.empty())
		{
			temp.start = 0;
			temp.lastMatch = -1;
			temp.lastPathIndex = -1;
			temp.end = (int)route->size() - 1;
			temp.nextMatch = -1;
			temp.nextPathIndex = -1;

			unmatchInfo.push_back(new unMatchInfo(temp));
		}
		else
		{
			for (i=0; i<matchedTraces.size(); i++)
			{
				if (i + 1 < matchedTraces.size())
				{
					if (matchedTraces[i]->path.back().first + 1 == matchedTraces[i+1]->path.front().first)
					{
						temp.start = -1;
						temp.end = -1;
						temp.lastMatch = matchedTraces[i]->path.back().second;
						temp.nextMatch = matchedTraces[i+1]->path.front().second;
						temp.lastPathIndex = i;
						temp.nextPathIndex = i+1;

						unmatchInfo.push_back(new unMatchInfo(temp));
					}
					else
					{
						temp.start = matchedTraces[i]->path.back().first + 1;	
						temp.end = matchedTraces[i+1]->path.front().first - 1;
						temp.lastMatch = matchedTraces[i]->path.back().second;
						temp.lastPathIndex = i;
						temp.end = matchedTraces[i+1]->path.front().first - 1;
						temp.nextMatch = matchedTraces[i+1]->path.front().second;
						temp.nextPathIndex = i+1;

						unmatchInfo.push_back(new unMatchInfo(temp));
					}
				}

				if (i == 0 && matchedTraces[i]->path.front().first != 0)
				{
					temp.start = 0;
					temp.lastMatch = -1;
					temp.lastPathIndex = -1;
					temp.end = matchedTraces[i]->path.front().first - 1;
					temp.nextMatch = matchedTraces[i]->path.front().second;
					temp.nextPathIndex = i;

					unmatchInfo.push_back(new unMatchInfo(temp));
				}

				if (i + 1 == matchedTraces.size() && matchedTraces[i]->path.back().first < (int)route->size() - 1)
				{
					temp.start = matchedTraces[i]->path.back().first + 1;
					temp.lastMatch = matchedTraces[i]->path.back().second;
					temp.lastPathIndex = i;
					temp.end = (int)route->size() - 1;
					temp.nextMatch = -1;
					temp.nextPathIndex = -1;

					unmatchInfo.push_back(new unMatchInfo(temp));
				}
			}

			for (i=0; i<matchedTraces.size(); i++)
			{
				Path newPath;
				newPath.firstMatch = matchedTraces[i]->firstMatch;
				newPath.lastMatch = matchedTraces[i]->lastMatch;

				for (j=0; j<matchedTraces[i]->path.size(); j++)
					if (matchedTraces[i]->path[j].first >= 0)
						newPath.path.push_back(matchedTraces[i]->path[j]);

				shortMatchedTraces.push_back(new Path(newPath));
			}
		}
	}
}
