
#include "KmlWriter.h"
#include "GPSPoint.h"
#include <vector>
#include <sstream>

#define TRACE_WIDTH 4
#define MAP_WIDTH 4
#define MAX_SKIP_LINKS 5

//const string[] KmlWriter::lineColor ={ 
//	"ffffffff", //branco
//    "ffff00ff", //magenta
//    "ff0000ff", //azul
//    "ff00ff00", //verde
//    "ffff0000", //vermelho
//}

void KmlWriter::setColor(int c){
	//	color = c;
}

int KmlWriter::getColorInt(){
	return 0;
}

string KmlWriter::getColor(int c){
	return lineColors[c];
}

string KmlWriter::getColor(){
	return lineColors[0];
}

void KmlWriter::openFolder(const string& folder_name)
{
	file << "	<Folder id=\"" << folder_name << "\">" << std::endl;
	file << "		<name>" << folder_name << "</name>" << endl
		<<  "		<visibility>1</visibility>" << endl
		<<  "		<open>0</open>" << endl;
}

void KmlWriter::closeFolder()
{
	file << "	</Folder>" << std::endl;
}

KmlWriter::KmlWriter(const string& filename)
{
	/*ofstream fileTemp(filename.c_str());
	file = fileTemp;*/

	//cout << "creating file: " << filename << endl;
	file.open(filename.c_str(), std::ios::out);
	file.setf(ios::fixed,ios::floatfield);
	file.precision(9);
	//	color = 0;
	lineColors = *(new vector<string>(5));
	lineColors[0] = "ffffffff"; //branco
	lineColors[1] = "ffff00ff"; //magenta
	lineColors[2] = "ffff0000"; //azul
	lineColors[3] = "ff00ff00"; //verde
	lineColors[4] = "ff0000ff"; //vermelho


	//	//init kml tags
	file << "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>" << endl;
	file << "<kml xmlns=\"http://earth.google.com/kml/2.0\">" << endl;
	file << "<Document>" << endl
		<< "	<open>1</open>" << std::endl;
	//	file << "<description><![CDATA[NMEA]]></description>" << endl;
	///	file << "<Style id=\"ikon\"><IconStyle><Icon><href>http://maps.google.com/mapfiles/kml/shapes/arrow.png</href></Icon><scale>1.0</scale></IconStyle></Style>" << endl;
	///file << "<Style id=\"mapNodeIkon\"><IconStyle><Icon><href>http://maps.google.com/mapfiles/kml/shapes/square.png</href></Icon><scale>0.5</scale></IconStyle></Style>" << endl;

	//open root folder tag
	//file << "<Folder id=\"MAP\">" << endl;
}


void KmlWriter::buildMap(Map& m, const string& folder_id, int c) {
	int i = 0;
//	double heading;
	//std::map<int, mLink>::iterator it;
	std::map<int, mLink>::iterator lit;
	std::map<unsigned int, mEdges>::iterator git;
//	std::set<destID, compareDestID>::iterator sit;



	file << "	<Folder id=\"" << folder_id << "\">" << std::endl
		<< "		<name>" << folder_id << "</name>" << std::endl
		//<< "		<visibility>1</visibility>" << std::endl
		<< "		<open>0</open>" << std::endl;


		file << "		<Folder id=\"NODES\">" << std::endl
		<< "			<name>Nodes</name>" << std::endl
		<< "			<visibility>0</visibility>" << std::endl;
		
	file << "			<Style id=\"mapNodeIcon\">" << endl
		<< "				<IconStyle>" << endl
		<< "					<Icon><href>http://maps.google.com/mapfiles/kml/shapes/square.png</href></Icon>"
		<< "					<scale>0.50</scale>" << endl
		<< "				</IconStyle>" << endl
		<< "			</Style>" << endl;

	// Plot info
	for (git = m.graph_begin(); git != m.graph_end(); git++)
	{
		//position or = stringKeyToPosition(git->first);
		mNode org = m.getNode(git->first);

		//      for (sit = git->second.begin(); sit != git->second.end(); sit++)
		//      {
		//          position dest = toPosition(sit->dest);

		file << "    <Placemark>" << std::endl
			<< "        <description>" << git->first << "<br/>"
			<< "xy: " << org.longitude << "," << org.latitude << "<br/>"
			<< "dop: " << org.dop << "<br/>snr: " << org.snr << "<br/>"
			<< "</description>" << std::endl
			<< "		<visibility>0</visibility>" << std::endl
			<< "		<styleUrl>#mapNodeIcon</styleUrl>" << std::endl
//			<< "        <Style><IconStyle><Icon><href>http://maps.google.com/mapfiles/kml/shapes/square.png</href></Icon><scale>0.50</scale></IconStyle></Style>" << std::endl
			//<< "        <LookAt>" << std::endl
			//<< "            <longitude>" << route->route[i].lon << "</longitude>" << std::endl
			//<< "            <latitude>" << route->route[i].lat << "</latitude>" << std::endl
			//<< "            <range>50.0</range>" << std::endl
			//<< "            <tilt>0.0</tilt>" << std::endl
			//<< "        </LookAt>" << std::endl
			<< "        <Point>" << std::endl
			<< "            <coordinates>" << org.longitude << "," << org.latitude << ",0</coordinates>" << std::endl
			<< "        </Point>" << std::endl
			<< "    </Placemark>" << std::endl;
		//        }
	}
	file << "		</Folder>" << std::endl;




	file << "		<Folder id=\"LINKS\">" << std::endl
		<< "			<name>Links</name>" << std::endl;

	for (lit = m.links_begin(); lit != m.links_end(); lit++)
	{
		mNode p1 = m.getNode(lit->second.orID);
		mNode p2 = m.getNode(lit->second.destID);
		//position p1 = stringKeyToPosition(it->second.or);
		//position p2 = stringKeyToPosition(it->second.dest);

		/*stringstream stream_or();
		stringstream stream_dest(it->second.dest);*/

		file << "    <Placemark>" << std::endl
			<< "        <name>" << "Link: " << lit->first << "</name>" << std::endl
			<< "        <description>" << lit->first << "</description>" << std::endl
			<< "        <Style>" << std::endl
			<< "            <LineStyle>" << std::endl
			<< "                <color>" << lineColors[c] << "</color>" << std::endl
			<< "                <width>" << MAP_WIDTH << "</width>" << std::endl
			<< "            </LineStyle>" << std::endl
			<< "        </Style>" << std::endl
			<< "        <LineString>" << std::endl
			<< "            <tessellate>0</tessellate>" << std::endl
			<< "            <altitudeMode>clampedToGround</altitudeMode>" << std::endl
			<< "            <coordinates>" << std::endl
			<< "                "<< p1.longitude << "," << p1.latitude << ",0" << std::endl
			<< "                " << p2.longitude << "," << p2.latitude << ",0" << std::endl
			/*<< "                " << it->second.or << ",0" << std::endl
			<< "                " << it->second.dest << ",0" << std::endl*/
			<< "            </coordinates>" << std::endl
			<< "        </LineString>" << std::endl
			<< "    </Placemark>" << std::endl;
	}
	file << "		</Folder>" << std::endl;


	file << "		<Folder id=\"MAPLINKSINFO\">" << std::endl
			<< "			<name>LinkInfo</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl;

	//file << "			<Style id=\"linkInfoIcon\">" << endl
	//	<< "				<IconStyle>" << endl
	//	<< "					<Icon><href>http://maps.google.com/mapfiles/kml/shapes/arrow.png</href></Icon>"
	//	<< "					<scale>0.40</scale>" << endl
	//	<< "				</IconStyle>" << endl
	//	<< "			</Style>" << endl;

	//int skip_links_count = 0;
	list<int> d_links (this->getLinksToDraw(m));
	list<int>::iterator dlitr;

	//for (it = m.links_begin(); it != m.links_end(); it++)
	for (dlitr = d_links.begin(); dlitr != d_links.end(); dlitr++)
	{
		mLink thisLink(m.getLink(*dlitr));
		//position pos = stringKeyToPosition(it->second.or);
		//mNode pos = m.getNode(it->second.orID);
		mNode org = m.getNode(thisLink.orID);
		mNode dest = m.getNode(thisLink.destID);

		mEdges edgesOr = m.getEdges(thisLink.orID);
		mEdges edgesDest = m.getEdges(thisLink.destID);
		//if (edgesOr.predecessors.size() == 1 && edgesOr.successors.size() == 1
		//	&& edgesDest.predecessors.size() == 1 && edgesDest.successors.size() == 1
		//	&& skip_links_count < MAX_SKIP_LINKS)
		//{
		//	skip_links_count++;
		//	continue;
		//}
		//
		//skip_links_count = 0;

		GPSPoint g(GPSPoint::convertUTMToWGS84((dest.longm + org.longm)/2,
			(dest.latm + org.latm)/2,
			GPSPoint::getZone(org.longitude), GPSPoint::getLatZone(org.latitude)));

		file << "			<Placemark>" << std::endl
			<< "				<description>" << std::endl
			<< "					<br/>Link : " << *dlitr << "<br/>"
			<< "orID: " << thisLink.orID << " destID: " << thisLink.destID << "<br/>"
			<< "Length:" << thisLink.length << "<br/>"
			<< "Heading: " << rad2deg(thisLink.heading) << "<br/>"
			<< "PassCount: " << thisLink.match_count << "<br/>"
			<< "				</description>" << std::endl
			<< "				<Style>" << std::endl

			<< "					<IconStyle>" << std::endl
			//<< "					<styleUrl>#nodeMapIcon</styleUrl>" << std::endl
			//<< "						<Icon><href>arrow.png</href></Icon>" << std::endl
			<< "						<Icon><href>http://maps.google.com/mapfiles/kml/shapes/arrow.png</href></Icon>" << std::endl
			<< "						<scale>0.40</scale>" << std::endl
			<< "						<heading>" << rad2deg(thisLink.heading)+180 << "</heading>" << std::endl
			<< "					</IconStyle>" << std::endl
			<< "				</Style>" << std::endl
			<< "				<LookAt>" << std::endl
			<< "					<longitude>" << g.lon << "</longitude>" << std::endl
			<< "					<latitude>" << g.lat << "</latitude>" << std::endl
			<< "					<range>50.0</range>" << std::endl
			<< "					<tilt>0.0</tilt>" << std::endl
			<< "				</LookAt>" << std::endl
			<< "				<Point>" << std::endl
			<< "					<coordinates>" << g.lon << "," << g.lat << ",0</coordinates>" << std::endl
			<< "				</Point>" << std::endl
			<< "			</Placemark>" << std::endl;
	}

	file << "		</Folder>" << std::endl;

	file << "   </Folder>" << std::endl;
}

void KmlWriter::buildTrace(Route& r,const string& folder_id, int c){

	stringstream GPSplacemarks;

	c = c % lineColors.size();

	//open root folder tag
	file << "	<Folder id=\"" << folder_id << "\">" << std::endl
		<< "		<name>" << folder_id << "</name>" << std::endl
		<< "		<visibility>1</visibility>" << std::endl
		<< "		<open>0</open>" << std::endl;
	//<< "<Snippet/>"<<endl;
	// //"<description>" << endl;
	//<![CDATA[<table>
	//         <tr><td><b>Distance</b> 3.4 mi </td></tr>
	//         <tr><td><b>Min Alt</b> 128.9 ft </td></tr>
	//         <tr><td><b>Max Alt</b> 321.5 ft </td></tr>
	//         <tr><td><b>Max Speed</b> 130.9 mph </td></tr>
	//         <tr><td><b>Start Time:</b> 2007-12-12T10:46:52Z  </td></tr>
	//         <tr><td><b>End Time:</b> 2007-12-12T10:55:54Z  </td></tr>
	//       </table>]]>
	//     </description>
	//     <TimeSpan>
	//       <begin>2007-12-12T10:46:52Z</begin>
	//       <end>2007-12-12T10:55:54Z</end>
	//     </TimeSpan>

	//open line placemark
	file << "		<Placemark>" << endl;
	file << "			<name>" << folder_id << "</name>" << endl;
	file << "			<Style>" << endl;
	file << "				<LineStyle>" << endl;
	file << "					<color>" << lineColors[c] << "</color>" << endl;
	file << "					<width>" << TRACE_WIDTH << "</width>" << endl;
	file << "				</LineStyle>" << endl;
	file << "			</Style>" << endl;
	file << "			<LineString>" << endl;
	file << "				<tessellate>0</tessellate>" << endl;
	file << "				<altitudeMode>clampedToGround</altitudeMode>" << endl;
	file << "				<coordinates>" << endl;

	for (int i = 0; i < r.size(); i++)
	{
		file << "					" << r.getLongitude(i) << "," << r.getLatitude(i) << ",0" << endl;
		GPSplacemarks << r.pointToKml(i) << endl;
	}
	//close line placemark
	file << "				</coordinates>" << endl;
	file << "			</LineString>" << endl;
	file << "		</Placemark>" << endl;

	//add the placemarks
	file << "		<Folder id=\"NODES\">" << endl;
	file << "			<name>Nodes</name>" << endl;
	file << GPSplacemarks.str() << endl;
	file << "		</Folder>" << endl;

	//close Trace folder
	file << "	</Folder>" << endl;
}

void KmlWriter::addMatchInfo(pair<position,position> match,double distance)
{
	//open line placemark
	file << "		<Placemark>" << endl;
	file << "			<name>match: "<< distance << "</name>" << endl;
	file << "			<Style>" << endl;
	file << "				<LineStyle>" << endl;
	file << "					<color>" << lineColors[3] << "</color>" << endl;
	file << "					<width>" << TRACE_WIDTH << "</width>" << endl;
	file << "				</LineStyle>" << endl;
	file << "			</Style>" << endl;
	file << "			<LineString>" << endl;
	file << "				<tessellate>0</tessellate>" << endl;
	file << "				<altitudeMode>clampedToGround</altitudeMode>" << endl;
	file << "				<coordinates>" << endl;
	file << "					" << match.first.longitude << "," << match.first.latitude << ",0" << endl;
	file << "					" << match.second.longitude << "," << match.second.latitude << ",0" << endl;
	file << "				</coordinates>" << endl;
	file << "			</LineString>" << endl;
	file << "		</Placemark>" << endl;
	//close line placemark

	file << "		<Placemark>" << endl
		<< "		<description>distance: "<< distance << "</description>" << endl
	<< "		<Style><IconStyle><Icon><href>http://maps.google.com/mapfiles/kml/pal3/blu-blank.png</href></Icon><scale>0.50</scale></IconStyle></Style>" << endl;
	//<LookAt>
	//	<longitude>-8.415959358215</longitude>
	//	<latitude>40.186222076416</latitude>
	//	<range>50.0</range>
	//	<tilt>0.0</tilt>
	//</LookAt>
	file << "		<Point>" << endl
		<< "			<coordinates>" << match.second.longitude << "," << match.second.latitude << ",0</coordinates>" << endl
	<< "		</Point>" << endl
	<< "	</Placemark>"<< endl;

}

void KmlWriter::buildUnmatchedTrace(Route& r,vector<unMatchInfo *> unmatchedInfo,const string& folder_id){


	file << "	<Folder id=\""<<folder_id << "\">" << endl
		<< "		<name>"<<folder_id << "</name>" << endl
		<< "		<visibility>1</visibility>" << endl
		<< "		<open>0</open>" << endl;

	vector<unMatchInfo*>::iterator itr;
	for (itr = unmatchedInfo.begin(); itr != unmatchedInfo.end(); itr++){
		if ((*itr)->start >= 0)
			for (int i = (*itr)->start; i <= (*itr)->end; i++){
				file << "		<Placemark>" << endl
					<< "		<description>"<< i << "<br/>xy: "<< r.getLongitude(i) << "," << r.getLatitude(i) << "</description>" << endl
					<< "		<Style><IconStyle><Icon><href>http://maps.google.com/mapfiles/kml/pal3/icon59.png</href></Icon><scale>0.50</scale></IconStyle></Style>" << endl;
				//<LookAt>
				//	<longitude>-8.415959358215</longitude>
				//	<latitude>40.186222076416</latitude>
				//	<range>50.0</range>
				//	<tilt>0.0</tilt>
				//</LookAt>
				file << "		<Point>" << endl
					<< "			<coordinates>" << r.getLongitude(i) << "," << r.getLatitude(i) << ",0</coordinates>" << endl
					<< "		</Point>" << endl
					<< "	</Placemark>"<< endl;

			}
	}

	//close folder
	file << "	</Folder>" << endl;

}

void KmlWriter::addPointWindow(const string& folder_id,const vector<pair<Point,double> >& pointWindow,int zone, char latZone)
{
	file << "	<Folder id=\""<<folder_id << "\">" << endl
		<< "		<name>"<<folder_id << "</name>" << endl
		<< "		<visibility>1</visibility>" << endl
		<< "		<open>0</open>" << endl;

	vector<pair<Point,double> >::const_iterator itr;
	int i = 0;
	for (itr = pointWindow.begin(); itr != pointWindow.end(); itr++){
		GPSPoint point = GPSPoint::convertUTMToWGS84(itr->first.getX(),itr->first.getY(),zone,latZone);
		file << "		<Placemark>" << endl
			<< "		<description>index: " << i
			<< "distance to link start: " << itr->second
			<< "<br/>xy: " << point.lon << " , " << point.lat << "</description>" << endl
			<< "		<Style><IconStyle><Icon><href>http://maps.google.com/mapfiles/kml/shapes/placemark_circle.png</href></Icon><scale>0.50</scale></IconStyle></Style>" << endl;
		//<LookAt>
		//	<longitude>-8.415959358215</longitude>
		//	<latitude>40.186222076416</latitude>
		//	<range>50.0</range>
		//	<tilt>0.0</tilt>
		//</LookAt>
		file << "		<Point>" << endl
			<< "			<coordinates>" << point.lon << "," << point.lat << ",0</coordinates>" << endl
			<< "		</Point>" << endl
			<< "	</Placemark>"<< endl;
		i++;

	}

	//close folder
	file << "	</Folder>" << endl;
}

void KmlWriter::addDistanceInfo(int p1_index,const Point& p1,int p2_index, const Point& p2, double distance,int zone, char latZone)
{
	GPSPoint point1(GPSPoint::convertUTMToWGS84(p1.getX(),p1.getY(),zone,latZone));
	GPSPoint point2(GPSPoint::convertUTMToWGS84(p2.getX(),p2.getY(),zone,latZone));
	//open line placemark
	file << "		<Placemark>" << endl;
	file << "			<name>distance(" << p1_index << "," << p2_index << "): "<< distance << "</name>" << endl;
	file << "			<Style>" << endl;
	file << "				<LineStyle>" << endl;
	file << "					<color>" << lineColors[3] << "</color>" << endl;
	file << "					<width>" << TRACE_WIDTH << "</width>" << endl;
	file << "				</LineStyle>" << endl;
	file << "			</Style>" << endl;
	file << "			<LineString>" << endl;
	file << "				<tessellate>0</tessellate>" << endl;
	file << "				<altitudeMode>clampedToGround</altitudeMode>" << endl;
	file << "				<coordinates>" << endl;
	file << "					" << point1.lon << "," << point1.lat << ",0" << endl;
	file << "					" << point2.lon << "," << point2.lat << ",0" << endl;
	file << "				</coordinates>" << endl;
	file << "			</LineString>" << endl;
	file << "		</Placemark>" << endl;
	//close line placemark

	file << "		<Placemark>" << endl
		<< "		<description>distance(" << p1_index << "," << p2_index << "): "<< distance <<"</description>" << endl
	<< "		<Style><IconStyle><Icon><href>http://maps.google.com/mapfiles/kml/pal3/blu-blank.png</href></Icon><scale>0.50</scale></IconStyle></Style>" << endl;
	//<LookAt>
	//	<longitude>-8.415959358215</longitude>
	//	<latitude>40.186222076416</latitude>
	//	<range>50.0</range>
	//	<tilt>0.0</tilt>
	//</LookAt>
	file << "		<Point>" << endl
		<< "			<coordinates>" << point2.lon << "," << point2.lat << ",0</coordinates>" << endl
	<< "		</Point>" << endl
	<< "	</Placemark>"<< endl;
}


void KmlWriter::closeDocument(){
	//close Folder,Document and kml
	//	file << "</Folder>" << endl;
	file << "</Document>" << endl;
	file << "</kml>" << endl;	
}

KmlWriter::~KmlWriter(void)
{
}


std::list<int> KmlWriter::getLinksToDraw(Map& map)
{
	std::list<int> ilinks, temp;
	std::vector<int> path;
	std::set<int> usedLinks;
	std::map<unsigned int, mapRepresentation::mEdges>::const_iterator it;
	std::set<unsigned int> nodes;
	std::set<int>::const_iterator sit, sit2;
	mapRepresentation::mEdges e;

	for (it = map.graph.begin(); it != map.graph.end(); it++)
	{
		if (it->second.predecessors.size() > 1 || it->second.successors.size() > 1)
		{
			e = (*it).second;

			for (sit = e.successors.begin(); sit != e.successors.end(); sit++)
			{
				sit2 = usedLinks.find(*sit);

				if (sit2 == usedLinks.end())
				{
					usedLinks.insert(*sit);

					temp = selectLinksFromPath(navigateForward(map,*sit));

					ilinks.merge(temp);
				}
			}

			for (sit = e.predecessors.begin(); sit != e.predecessors.end(); sit++)
			{
				path = navigateBackward(map,*sit);

				sit2 = usedLinks.find(path.back());

				if (sit2 == usedLinks.end())
				{
					usedLinks.insert(path.back());

					temp = selectLinksFromPath(path);

					ilinks.merge(temp);
				}
			}
		}
	}

	return ilinks;
}

std::vector<int> KmlWriter::navigateForward(Map& map,int link)
{
	std::vector<int> temp;
	mapRepresentation::mEdges e;

	temp.push_back(link);

	e = map.getEdges(map.getLink(link).destID);		

	while (e.predecessors.size() == 1 && e.successors.size() == 1)
	{
		link = *e.successors.begin();

		temp.push_back(link);

		e = map.getEdges(map.getLink(link).destID);
	}

	return temp;
}



std::vector<int> KmlWriter::navigateBackward(Map& map,int link)
{
	std::vector<int> temp;
	mapRepresentation::mEdges e;

	temp.push_back(link);

	e = map.getEdges(map.getLink(link).destID);		

	while (e.predecessors.size() == 1 && e.successors.size() == 1)
	{
		link = *e.predecessors.begin();

		temp.push_back(link);

		e = map.getEdges(map.getLink(link).orID);
	}

	return temp;
}

std::list<int> KmlWriter::selectLinksFromPath(const std::vector<int>& path)
{
	int i, delta;
	std::list<int> finalLinks;

	if (path.size() < 10)
		delta = 3;
	else if (path.size() < 20)
		delta = 4;
	else if (path.size() < 100)
		delta = 10;
	else
		delta = 30;

	for (i=0; i<path.size(); i+=delta)
		finalLinks.push_back(path[i]);

	if ((int)path.size() - (i - delta) > 5)
		finalLinks.push_back(path.back());

	return finalLinks;
}
