
#include "util.h"
#include "GPSPoint.h"
#include <sstream>


Point positionToPoint(const position& p)
{
	GPSPoint g (GPSPoint::convertWGS84ToUTM(p.latitude, p.longitude));

	return Point(g.longm, g.latm);
}

std::string toStringKey(double lat, double lon)
{
	std::stringstream ss;
	ss.precision(9);
	ss.setf(std::ios::fixed, std::ios::floatfield);

	ss << lat << "," << lon;

	return ss.str();
}

std::string positionToStringKey(const position& p)
{
	return toStringKey(p.latitude, p.longitude);
}

position stringKeyToPosition(const std::string& key)
{
	std::stringstream ss(key);
	position tmp;

	ss >> tmp.latitude;
	ss.get();
	ss >> tmp.longitude;

	return tmp;
}

double ajustHeadingToInterval(double headingToAjust, double currHeading)
{
	if (fabs(currHeading-headingToAjust) > PI)
	{
		if (currHeading > headingToAjust)
			return headingToAjust + 2*PI;
		else
			return headingToAjust - 2*PI;
	}
	else
		return headingToAjust;
}
