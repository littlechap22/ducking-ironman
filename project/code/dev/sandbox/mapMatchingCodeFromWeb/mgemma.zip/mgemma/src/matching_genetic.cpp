
#include <set>
#include <string>
#include <iostream>
#include <sstream>
#include <cmath>
#include "util.h"
#include "matching_genetic.h"
#include "geometry.h"
#include "kml.h"


namespace MapMatching{

	GenMapMatching::GenMapMatching()
	{

	}

	GenMapMatching::GenMapMatching(mapRepresentation::Map * map, Route * route, bool log)
	{
		this->map = map;
		this->route = route;
		out = NULL;

		params.D_LIMIT = 20.0;
		params.PROB_INVALID_LINK = 0.15;
		params.POP_SIZE = 200;
		params.DIRECT_PASS = 0.03;
		params.BEST_INDIVIDUAL_MATURITY = 300;

		params.TOLERANCE_LINKS = 5;
		params.TOLERANCE_SUPER_LINKS = 1;

		params.RECOMBINATION_PROB = 0.75;
		params.MUTATION_PROB = 0.005;
		params.TOURNAMENT_PROB_BEST_INDIVIDUAL = 0.60;
		
		params.W_AVG = 1.0;
		params.W_MAX = 0.8;
		params.W_MAX_MIN = 0.9;
		params.W_UNCOV = 6.0;
		params.W_GAP = 3.5;
		params.W_CONTLEN = 4.0;
		params.W_AVGDISC = 1.0;
		params.W_MAXDISC = 1.0;

		if (log)
		{
			stringstream ss;
			ss << "data" << FILE_SEPARATOR << route->getName() << "_genetic_log.txt";
			out = new std::ofstream(ss.str().c_str(), ios::ios_base::out|ios::ios_base::trunc);
		}
	}

	GenMapMatching::~GenMapMatching()
	{
		if (out != NULL)
			delete out;
	}


	void GenMapMatching::run(vector<set<int> > * forwardCandidates, vector<set<int> > * backwardCandidates, bool generateKML)
	{
		int i, j, k, begin_seg, seg_size;
		unMatchInfo un, unTemp;
		time_t start, end;
		time_t sInitPop, eInitPop;
		Path ptemp;
		vector<pair<int, int> > segments;
		vector<double> pointScores;
		vector<int> breakingPaths;
		vector<int> match(route->size());

		if (out != NULL)
		{
			(*out) << route->getOriginalFilename() << std::endl;
			(*out) << "Trace " << route->getName() << " has: " << route->size() << " points." << std::endl;
		}

		time(&start);
		dists = Distances(map, route, forwardCandidates, backwardCandidates, out);
		time(&end);

		//precalcDistsTime += difftime(end, start);

		segments = splitByAmbiguity();

		for (i=0; i<segments.size(); i++)
		{
			if (out != NULL)
				(*out) << std::endl << "Segment Match from " << segments[i].first << " to " << segments[i].second << std::endl;

			if (i==0)
			{
				begin_seg = segments[i].first;
				seg_size = segments[i].second-segments[i].first+1;
			}
			else
			{
				begin_seg = segments[i].first-1;
				seg_size = segments[i].second-segments[i].first+1+1;
			}

			Population pop(map, route, &dists, &params, begin_seg, seg_size, out);

			pop.printPopulationStatistics();

			time(&sInitPop);
			if (i==0)
				pop.initializePopulation(false);
			else
				pop.initializePopulation(true, begin_seg, match[begin_seg]);
			time(&eInitPop);

			//populationInitTime += difftime(eInitPop, sInitPop);

			if (out != NULL)
			{
				(*out) << "## Initial population: ##" << std::endl;

				pop.printGeneration();

				(*out) << std::endl;
			}

			//while (pop.getGeneration() < NUMBER_GENERATIONS)
			while (pop.getGeneration() - pop.getGenerationBestFromEver() <= 300)
			{
				pop.nextGeneration();
				//pop.printGenerationStatistics();

				if (pop.getGeneration() % 10 == 0)
					pop.printGenerationStatistics();
			}

			if (out != NULL)
				(*out) << "## Final population: ##" << std::endl;

			pop.printGeneration();

			pop.printBestIndividuals();

			Individual best = pop.getBestFromEver();

			for (k=0; k<best.getSize(); k++)
				match[begin_seg+k] = best.getGene(k);

			if (best.getGapDistance() > 0)
			{
				std::vector<int> gaps(pop.getIndividualGaps(best));

				for (k=0; k<gaps.size(); k++)
					breakingPaths.push_back(begin_seg + gaps[k]);
			}
		}

		// fix part
		int fixed = 0, removed = 0;

		for (i=1; i<(int)match.size()-1; i++)
		{
			if (match[i] == INVALID_LINK && match[i-1] != INVALID_LINK && match[i+1] != INVALID_LINK)
			{
				if (match[i-1] == match[i+1])
				{
					match[i] = match[i-1];
					fixed++;
				}
				else if (map->isConnected(match[i-1], match[i+1]))
				{
					mapRepresentation::mLink former = map->getLink(match[i-1]);
					mapRepresentation::mLink next = map->getLink(match[i+1]);

					double fDist = getNearestPointFromLink(map->getNodePoint(former.orID), map->getNodePoint(former.destID), Point(route->getLongitudeM(i), route->getLatitudeM(i))).second;
					double nDist = getNearestPointFromLink(map->getNodePoint(next.orID), map->getNodePoint(next.destID), Point(route->getLongitudeM(i), route->getLatitudeM(i))).second;

					if (fDist < nDist)
						match[i] = match[i-1];
					else
						match[i] = match[i+1];

					fixed++;					
				}
			}
		}

		if (match[0] != INVALID_LINK)
		{
			i = 1;

			while (i < match.size() && match[i] == match[0])
				i++;

			if (match[i] == INVALID_LINK)
				for (j=0; j<i; j++)
				{
					match[j] = INVALID_LINK;
					removed++;
				}
		}

		for (i=1; i<match.size(); i++)
		{
			if (match[i] != INVALID_LINK && match[i-1] == INVALID_LINK)
			{
				for (j=i+1; j<match.size() && match[j] == match[i] && match[j] != INVALID_LINK; j++)
					;

				if ((j < match.size() && match[j] == INVALID_LINK) || (j == match.size() && match[j-1] == match[i]))
				{
					if (j == match.size())
						j--;

					for ( ; j>=i; j--)
					{
						match[j] = INVALID_LINK;
						removed++;
					}
				}
			}
		}

		if (out != NULL)
		{
			(*out) << std::endl << std::endl;
			(*out) << fixed << " unmatched genes were fixed." << std::endl;
			(*out) << removed << " matched genes were removed." << std::endl;
			(*out) << std::endl << std::endl;
		}

		un.start = 0;
		un.lastMatch = -1;
		un.lastPathIndex = -1;

		bool matching = false;

		for (i=0; i<match.size(); i++)
		{
			if (match[i] > 0 && !matching)
			{
				matching = true;

				ptemp.firstMatch = i;
				ptemp.path.push_back(std::pair<int,int>(i, match[i]));				

				if (i > 0)
				{
					un.end = i-1;
					un.nextMatch = match[i];
					un.nextPathIndex = paths.size();

					unmatched.push_back(new unMatchInfo(un));					
				}
			}
			else if (match[i] > 0 && matching)
			{
				if (ptemp.path.size() == 0)
				{
					ptemp.path.push_back(std::pair<int,int>(i, match[i]));
					ptemp.firstMatch = i;
				}
				else
				{
					if (ptemp.path.back().second != match[i])
						ptemp.path.push_back(std::pair<int,int>(i, match[i]));
				}

				if (match.size() == i+1)
				{	
					ptemp.lastMatch = i;
					paths.push_back(new Path(ptemp));
				}
			}
			else if (match[i] < 0 && matching)
			{
				matching = false;
				ptemp.lastMatch = i-1;
				paths.push_back(new Path(ptemp));
				ptemp = Path();

				un.start = i;
				un.lastMatch = match[i-1];
				un.lastPathIndex = paths.size()-1;
			}
			else if (match[i] < 0 && i == 0)
			{
				un.start = i;
				un.lastMatch = -1;
				un.lastPathIndex = -1;
			}
			else if (!matching && i==match.size()-1)
			{
				un.end = i;
				un.nextMatch = -1;
				un.nextPathIndex = -1;
				unmatched.push_back(new unMatchInfo(un));
			}

			if (breakingPaths.size() > 0 && i == breakingPaths.front())
			{
				ptemp.lastMatch = i;
				paths.push_back(new Path(ptemp));
				ptemp = Path();
				ptemp.firstMatch = i+1;

				unTemp.end = -1;
				unTemp.start = -1;
				unTemp.lastMatch = match[i];
				unTemp.nextMatch = match[i+1];
				unTemp.lastPathIndex = (int)paths.size() - 1;
				unTemp.nextPathIndex = unTemp.lastPathIndex + 1;

				unmatched.push_back(new unMatchInfo(unTemp));

				breakingPaths.erase(breakingPaths.begin());
			}
		}

		if (generateKML)
		{
			kmlMatch::KMLBuilder kmlFile(map, route, match, segments, "genetic");
			kmlFile.buildKML();
		}

		if (out != NULL)
			out->close();
	}

	vector<pair<int, int> > GenMapMatching::splitByAmbiguity()
	{
		int i, link, tot_links, last_point;
		int start_segment, end_segment, end_look, count;
		double dist, link_heading, trace_heading, heading, delta_heading, score;
		vector<pair<int, int> > segments;
		vector<double> scores(route->size());

		if (out != NULL)
			(*out) << std::endl << "Splitting by Ambiguity..." << std::endl;

		for (i=0; i<route->size(); i++)
		{
			if (dists.hasNearestLink(i))
			{
				link = dists.getNearestLink(i);
				dist = dists.getDistanceFromPointToLink(i, link);
				trace_heading = route->getHeading(i);
				link_heading = ajustHeadingToInterval(map->getLink(link).heading, trace_heading);
				tot_links = dists.totalNearestLinks(i);

				heading = fabs(trace_heading - link_heading);
				delta_heading = dists.getMaxHeading(i) - dists.getMinHeading(i);

				score = (heading/PI) + (dist/MAX_DIST_LINK) + ((double)tot_links/20) + (delta_heading/PI);
			}
			else
				score = 0;

			scores[i] = score;

			if (out != NULL)
				(*out) << "Point " << i << " score: " << scores[i] << std::endl;
		}

		last_point = (int)route->size() - 1;
		start_segment = 0;
		end_segment = (int)Min(MAX_SEGMENT_NODES-1, last_point);
		end_look = (int)Min(end_segment+2, last_point);

		while (start_segment <= last_point)
		{
			for (i=end_look, count=0; i>start_segment; i--)
			{
				if (scores[i] <= SPLIT_SCORE)
					count++;
				else
					count = 0;

				if (count == 4)
				{
					if (last_point-i > 5)
						end_segment = i+1;

					break;
				}
				else if (i-start_segment < 5) //avoid small segments
					break;
			}

			segments.push_back(std::pair<int, int>(start_segment, end_segment));

			start_segment = end_segment + 1;
			end_segment = (int)Min(start_segment+MAX_SEGMENT_NODES-1, last_point);

			if (last_point - end_segment < 5) //avoid a small segment at the end
				end_segment = last_point;

			end_look = (int)Min(end_segment+2, last_point);
		}

		return segments;
	}
}
