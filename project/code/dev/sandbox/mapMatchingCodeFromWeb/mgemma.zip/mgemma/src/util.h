#ifndef __UTIL_H__
#define __UTIL_H__

#if defined(_WIN32) || defined(_WIN64)
const char FILE_SEPARATOR = '\\';
#else
const char FILE_SEPARATOR = '/';
#endif


#include <string>
#include "geometry.h"


typedef struct _position {
	double latitude;
	double longitude;

	_position(double lat=0, double lon=0)
	{
		latitude = lat;
		longitude = lon;
	};
} position;


Point positionToPoint(const position& p);

std::string toStringKey(double lat, double lon);
std::string positionToStringKey(const position& p);

position stringKeyToPosition(const std::string& key);

inline double Max(double n1, double n2) {return n1 > n2 ? n1 : n2;}
inline double Min(double n1, double n2) {return n1 < n2 ? n1 : n2;}

double ajustHeadingToInterval(double headingToAjust, double currHeading);

#endif // __UTIL_H__
