#include "GPSPoint.h"
#include <cstring>

//	Lat Lon to UTM variables

// equatorial radius
const double equatorialRadius = 6378137;

// polar radius
const double polarRadius = 6356752.314;

// flattening
const double flattening = 0.00335281066474748; // (equatorialRadius-polarRadius)/equatorialRadius;

// inverse flattening 1/flattening
const double inverseFlattening = 298.257223563; // 1/flattening;

// Mean radius
const double rm = pow(equatorialRadius * polarRadius, 1 / 2.0);

// scale factor
const double k0 = 0.9996;

// eccentricity
const double e = sqrt(1 - pow(polarRadius / equatorialRadius, 2));

const double e1sq = e * e / (1 - e * e);

const double n = (equatorialRadius - polarRadius)
/ (equatorialRadius + polarRadius);

// r curv 1
const double rho = 6368573.744;

// r curv 2
const double nu = 6389236.914;

// Calculate Meridional Arc Length
// Meridional Arc
const double S = 5103266.421;

const double A0 = 6367449.146;

const double B0 = 16038.42955;

const double C0 = 16.83261333;

const double D0 = 0.021984404;

const double E0 = 0.000312705;

// Calculation Constants
// Delta Long
const double p = -0.483084;

const double sin1 = 4.84814E-06;

// Coefficients for UTM Coordinates
const double K1 = 5101225.115;

const double K2 = 3750.291596;

const double K3 = 1.397608151;

const double K4 = 214839.3105;

const double K5 = -2.995382942;

const double A6 = -1.00541E-07;


GPSPoint::GPSPoint()
: valid(false), b(6356752.314), a(6378137)
{
	equatorialRadius = 6378137;
	polarRadius = 6356752.314;
	flattening = 0.00335281066474748;
	inverseFlattening = 298.257223563;
	rm = pow(equatorialRadius * polarRadius, 1 / 2.0);
	k0 = 0.9996;
	e = sqrt(1 - pow(polarRadius / equatorialRadius, 2));
	e1sq = e * e / (1 - e * e);
	n = (equatorialRadius - polarRadius) / (equatorialRadius + polarRadius);
	rho = 6368573.744;
	nu = 6389236.914;
	S = 5103266.421;
	A0 = 6367449.146;
	B0 = 16038.42955;
	C0 = 16.83261333;
	D0 = 0.021984404;
	E0 = 0.000312705;
	p = -0.483084;
	sin1 = 4.84814E-06;
	K1 = 5101225.115;
	K2 = 3750.291596;
	K3 = 1.397608151;
	K4 = 214839.3105;
	K5 = -2.995382942;
	A6 = -1.00541E-07;
}

GPSPoint::GPSPoint(double lat, double lon, double latm, double longm, double elev, double speed, long long time, std::string date, double azimuth, int zone, char latZone)
: valid(false), b(6356752.314), a(6378137)
{
	this->lat = lat;
	this->lon = lon;
	this->latm = latm;
	this->longm = longm;
	this->elev = elev;
	this->speed = speed;
	this->time = time;
	this->date = date;
	this->azimuth = azimuth;
	this->zone = zone;
	this->latZone = latZone;

	equatorialRadius = 6378137;
	polarRadius = 6356752.314;
	flattening = 0.00335281066474748;
	inverseFlattening = 298.257223563;
	rm = pow(equatorialRadius * polarRadius, 1 / 2.0);
	k0 = 0.9996;
	e = sqrt(1 - pow(polarRadius / equatorialRadius, 2));
	e1sq = e * e / (1 - e * e);
	n = (equatorialRadius - polarRadius) / (equatorialRadius + polarRadius);
	rho = 6368573.744;
	nu = 6389236.914;
	S = 5103266.421;
	A0 = 6367449.146;
	B0 = 16038.42955;
	C0 = 16.83261333;
	D0 = 0.021984404;
	E0 = 0.000312705;
	p = -0.483084;
	sin1 = 4.84814E-06;
	K1 = 5101225.115;
	K2 = 3750.291596;
	K3 = 1.397608151;
	K4 = 214839.3105;
	K5 = -2.995382942;
	A6 = -1.00541E-07;
}

GPSPoint::GPSPoint(const GPSPoint& g)
{
	lat = g.lat;
	lon = g.lon;
	latm = g.latm;
	longm = g.longm;
	elev = g.elev;
	speed = g.speed;
	time = g.time;
	date = g.date;
	valid = g.valid;
	azimuth = g.azimuth;
	duration = g.duration;
	zone = g.zone;
	latZone = g.latZone;
	placeDescription = g.placeDescription;
}

GPSPoint GPSPoint::convertWGS84ToUTM(double latitude, double longitude)
{
	GPSPoint g;

	g.setVariablesWGS(latitude, longitude);
	g.longm = g.getEasting();
	g.latm = g.getNorthing(latitude);
	g.zone = g.getZone(longitude);
	g.latZone = g.getLatZone(latitude);

	return g;
}

GPSPoint GPSPoint::convertUTMToWGS84(double easting, double northing, int zone, char latZone)
{
	GPSPoint g;

	char hemisphere = getHemisphere(latZone);

	if (hemisphere=='S')
	{
		northing = 10000000 - northing;
	}

	g.setVariablesUTM(easting, northing);
	g.lat = 180 * (g.phi1 - g.fact1 * (g.fact2 + g.fact3 + g.fact4)) / _PI_;

	if (zone > 0)
	{
		g.zoneCM = 6 * zone - 183.0;
	}
	else
	{
		g.zoneCM = 3.0;
	}

	g.lon = g.zoneCM - g._a3;
	if (hemisphere=='S')
	{
		g.lat= -g.lat;
	}

	return g;
}

char GPSPoint::getHemisphere(char latZone)
{
	char hemisphere = 'N';

	if (latZone>='A' && latZone<='M' )
	{
		hemisphere = 'S';
	}

	return hemisphere;
}

char GPSPoint::getLatZone(double latitude)
{
	LatZones latZones;;

	return latZones.getLatZone(latitude);
}

int GPSPoint::getZone(double longitude)
{
	double longZone = 0;

	if (longitude < 0.0)
	{
		longZone = ((180.0 + longitude) / 6) + 1;
	}
	else
	{
		longZone = (longitude / 6) + 31;
	}

	return (int)longZone;
}

double GPSPoint::degreeToRadian(double degree)
{
	return degree * _PI_ / 180;
}

double GPSPoint::radianToDegree(double radian)
{
	return radian * 180 / _PI_;
}

double GPSPoint::getEasting()
{
	return 500000 + (K4 * p + K5 * pow(p, 3));
}

double GPSPoint::getNorthing(double latitude)
{
	double northing = K1 + K2 * p * p + K3 * pow(p, 4);

	if (latitude < 0.0)
	{
		northing = 10000000 + northing;
	}

	return northing;
}

void GPSPoint::setVariablesWGS(double latitude, double longitude)
{
	double var1;

	latitude = degreeToRadian(latitude);
	rho = equatorialRadius * (1 - e * e) / pow(1 - pow(e * sin(latitude), 2), 3 / 2.0);
	nu = equatorialRadius / pow(1 - pow(e * sin(latitude), 2), (1 / 2.0));

	if (longitude < 0.0)
	{
		var1 = ((int) ((180 + longitude) / 6.0)) + 1;
	}
	else
	{
		var1 = ((int) (longitude / 6)) + 31;
	}

	double var2 = (6 * var1) - 183;
	double var3 = longitude - var2;
	p = var3 * 3600 / 10000;

	S = A0 * latitude - B0 * sin(2 * latitude) + C0 * sin(4 * latitude) - D0 * sin(6 * latitude) + E0 * sin(8 * latitude);

	K1 = S * k0;
	K2 = nu * sin(latitude) * cos(latitude) * pow(sin1, 2) * k0 * (100000000) / 2;
	K3 = ((pow(sin1, 4) * nu * sin(latitude) * pow(cos(latitude), 3)) / 24)
		* (5 - pow(tan(latitude), 2) + 9 * e1sq * pow(cos(latitude), 2) + 4
		* pow(e1sq, 2) * pow(cos(latitude), 4))
		* k0 * (10000000000000000LL);

	K4 = nu * cos(latitude) * sin1 * k0 * 10000;
	K5 = pow(sin1 * cos(latitude), 3) * (nu / 6)
		* (1 - pow(tan(latitude), 2) + e1sq * pow(cos(latitude), 2)) * k0
		* 1000000000000LL;

	A6 = (pow(p * sin1, 6) * nu * sin(latitude) * pow(cos(latitude), 5) / 720)
		* (61 - 58 * pow(tan(latitude), 2) + pow(tan(latitude), 4) + 270
		* e1sq * pow(cos(latitude), 2) - 330 * e1sq
		* pow(sin(latitude), 2)) * k0 * (1E+24);
}

void GPSPoint::setVariablesUTM(double easting, double northing)
{
	arc = northing / k0;
	mu = arc / (a * (1 - pow(e, 2) / 4.0 - 3 * pow(e, 4) / 64.0 - 5 * pow(e, 6) / 256.0));

	ei = (1 - pow((1 - e * e), (1 / 2.0))) / (1 + pow((1 - e * e), (1 / 2.0)));
	ca = 3 * ei / 2 - 27 * pow(ei, 3) / 32.0;

	cb = 21 * pow(ei, 2) / 16 - 55 * pow(ei, 4) / 32;
	cc = 151 * pow(ei, 3) / 96;
	cd = 1097 * pow(ei, 4) / 512;
	phi1 = mu + ca * sin(2 * mu) + cb * sin(4 * mu) + cc * sin(6 * mu) + cd * sin(8 * mu);

	n0 = a / pow((1 - pow((e * sin(phi1)), 2)), (1 / 2.0));

	r0 = a * (1 - e * e) / pow((1 - pow((e * sin(phi1)), 2)), (3 / 2.0));
	fact1 = n0 * tan(phi1) / r0;

	_a1 = 500000 - easting;
	dd0 = _a1 / (n0 * k0);
	fact2 = dd0 * dd0 / 2;

	t0 = pow(tan(phi1), 2);
	Q0 = e1sq * pow(cos(phi1), 2);
	fact3 = (5 + 3 * t0 + 10 * Q0 - 4 * Q0 * Q0 - 9 * e1sq) * pow(dd0, 4) / 24;
	fact4 = (61 + 90 * t0 + 298 * Q0 + 45 * t0 * t0 - 252 * e1sq - 3 * Q0 * Q0) * pow(dd0, 6) / 720;

	//
	lof1 = _a1 / (n0 * k0);
	lof2 = (1 + 2 * t0 + Q0) * pow(dd0, 3) / 6.0;
	lof3 = (5 - 2 * Q0 + 28 * t0 - 3 * pow(Q0, 2) + 8 * e1sq + 24 * pow(t0, 2)) * pow(dd0, 5) / 120;
	_a2 = (lof1 - lof2 + lof3) / cos(phi1);
	_a3 = _a2 * 180 / _PI_;
}

LatZones::LatZones()
{
	char Tletters[] = {'A', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L',
		'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Z'};

	int Tdegrees[] = { -90, -84, -72, -64, -56, -48, -40, -32, -24, -16,
		-8, 0, 8, 16, 24, 32, 40, 48, 56, 64, 72, 84 };

	char TnegLetters[] = { 'A', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K',
		'L', 'M' };

	int TnegDegrees[] = { -90, -84, -72, -64, -56, -48, -40, -32, -24,
		-16, -8 };

	char TposLetters[] = { 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W',
		'X', 'Z' };

	int TposDegrees[] = { 0, 8, 16, 24, 32, 40, 48, 56, 64, 72, 84 };

	memcpy(letters, Tletters, sizeof(Tletters));
	memcpy(degrees, Tdegrees, sizeof(Tdegrees));
	memcpy(negLetters, TnegLetters, sizeof(TnegLetters));
	memcpy(negDegrees, TnegDegrees, sizeof(TnegDegrees));
	memcpy(posLetters, TposLetters, sizeof(TposLetters));
	memcpy(posDegrees, TposDegrees, sizeof(TposDegrees));
	arrayLength = 22;
}

int LatZones::getLatZoneDegree(std::string letter)
{
	int i;
	char ltr = letter.at(0);

	for (i=0; i<arrayLength; i++)
	{
		if (letters[i] == ltr)
		{
			return degrees[i];
		}
	}

	return -100;
}

char LatZones::getLatZone(double latitude)
{
	int i, len, latIndex = -2;
	int lat = (int)latitude;

	if (lat >= 0)
	{
		len = sizeof(posLetters)/sizeof(char);

		for (i=0; i<len; i++)
		{
			if (lat == posDegrees[i])
			{
				latIndex = i;
				break;
			}

			if (lat > posDegrees[i])
			{
				continue;
			}
			else
			{
				latIndex = i - 1;
				break;
			}
		}
	}
	else
	{
		len = sizeof(negLetters)/sizeof(char);

		for (i=0; i<len; i++)
		{
			if (lat == negDegrees[i])
			{
				latIndex = i;
				break;
			}

			if (lat < negDegrees[i])
			{
				latIndex = i - 1;
				break;
			}
			else
			{
				continue;
			}
		}
	}

	if (latIndex == -1)
	{
		latIndex = 0;
	}

	if (lat >= 0)
	{
		if (latIndex == -2)
		{
			latIndex = sizeof(posLetters)/sizeof(char) - 1;
		}

		return posLetters[latIndex];
	}
	else
	{
		if (latIndex == -2)
		{
			latIndex = sizeof(negLetters)/sizeof(char) - 1;
		}

		return negLetters[latIndex];
	}
}
