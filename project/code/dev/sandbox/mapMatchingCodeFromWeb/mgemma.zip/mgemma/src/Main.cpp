#include "Main.h"

// List of possible arguments:
// -t [folder] -> folder where traces to load are saved (the default folder is data/nmea)
// -M -> generate Map Matching .kml files
// -h -> show help
// -help -> show help

int main(int argc, char* argv[])
{
	int i;
	time_t sOverall, eOverall;
	std::stringstream defaultFolder;
	std::string tracesFolder;


	time(&sOverall);

	defaultFolder << "data" << FILE_SEPARATOR << "nmea" << FILE_SEPARATOR;
	tracesFolder = defaultFolder.str();

	for (i=0; i<argc; i++)
	{
		if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "-help") == 0)
		{
			std::cout << "\t*****  M-GEMMA  *****" << std::endl << std::endl
				<< " -t [folder]  -> traces to load (the default folder is data/nmea)" << std::endl
				<< "-> select trace points from a restricted area" << std::endl
				<< " -M -> generate Map Matching .kml files" << std::endl
				<< " -h -> help" << std::endl
				<< " -help -> help" << std::endl << std::endl;

			return 0;
		}
		else if (strcmp(argv[i], "-t") == 0 && i < argc - 1)
			tracesFolder = std::string(argv[++i]);
		else if (strcmp(argv[i], "-M") == 0)
			marchalKML = geneticKML = true;
	}

	std::cout << "Looking for Trace Files..." << std::endl;
	lookForTraceFiles(tracesFolder);

	std::cout << "Loading Map..." << std::endl;
	loadMap();

	std::cout << std::endl << "Ready to run YouTrace." << std::endl << std::endl;
	run();
	std::cout << "Finished running YouTrace." << std::endl << std::endl;

	time(&eOverall);

	std::cout << std::endl << std::endl
		<< "Overall processing time: " << difftime(eOverall, sOverall) << " sec.  (~= " << difftime(eOverall, sOverall)/60 << " min.)" << std::endl
		<< std::endl << std::endl;

	return 0;
}

void lookForTraceFiles(const std::string& folder)
{
	std::cout << "Looking for NMEA files (with .txt extension) inside folder: " << folder << std::endl; 

	traceFiles = getFiles(folder);
}

void loadMap()
{
	std::stringstream path;

	path << "data" << FILE_SEPARATOR << "map.txt";

	std::cout << "Trying to load map: " << path.str() << std::endl;

	m = mapRepresentation::Map(path.str());
}

void run()
{
	int i, k;
	std::stringstream path;
	std::vector<Path *> matched;
	std::vector<unMatchInfo *> unmatchedInfo;

	path << "data" << FILE_SEPARATOR;
	std::string mapFilename = path.str() + "map.txt";

	m.saveMap(mapFilename);

	for (i=0; i<traceFiles.size(); i++)
	{
		Route route = NMEALoader(traceFiles[i]).getRoute();

		std::cout << "\tRoute #" << i << ": " << route.getName() << std::endl;

		MapMatching::MGEMMA matching(&m, &route, false);
		matching.run(geneticKML);
		matched = matching.getShortMatched();
		unmatchedInfo = matching.getUnmatchedInfo();

		std::cout << "Paths: " << std::endl;
		for (k=0; k<matched.size(); k++)
			matched[k]->printPath();

		std::cout << std::endl << std::endl << "Unmatched Info: " << std::endl;
		for (k=0; k<unmatchedInfo.size(); k++)
		{
			std::cout << "Start node: " << unmatchedInfo[k]->start << " End node: " << unmatchedInfo[k]->end 
				<< " Last Match: " << unmatchedInfo[k]->lastMatch << " Next Match: " << unmatchedInfo[k]->nextMatch
				<< " Last Path: " << unmatchedInfo[k]->lastPathIndex << " Next Path: "<< unmatchedInfo[k]->nextPathIndex
				<< std::endl;
		}

		for (k=0; k<matched.size(); k++)
			delete matched[k];

		for (k=0; k<unmatchedInfo.size(); k++)
			delete unmatchedInfo[k];
	}
}
