
#include "maps.h"
#include "GPSPoint.h"
#include "KmlWriter.h"
#include <iostream>
#include <fstream>
#include <queue>

namespace mapRepresentation {

	Map::Map()
	{
		qtree = new QuadTree(this);
		nodeID = 1;
		linkID = 1;
		superLinkID = 1;
	}

	Map::Map(const std::string &filename)
	{
		qtree = new QuadTree(this);
		nodeID = 1;
		linkID = 1;
		superLinkID = 1;
		initMap(filename);
	}

	Map::Map(const Route& route)
	{
		qtree = new QuadTree(this);
		nodeID = 1;
		linkID = 1;
		superLinkID = 1;
		initMapFromRoute(route);
	}

	Map::~Map()
	{
		delete qtree;
	}

	Map::Map(const Map &m)
	{
		graph = m.graph;
		links = m.links;
		nodes = m.nodes;
		superGraph = m.superGraph;
		superLinks = m.superLinks;
		superNodes = m.superNodes;
		nodeID = m.nodeID;
		linkID = m.linkID;
		superLinkID = m.superLinkID;
		qtree = new QuadTree(this);
	}

	const Map& Map::operator =(const Map &m)
	{
		if (this != &m)
		{
			graph = m.graph;
			links = m.links;
			nodes = m.nodes;
			superGraph = m.superGraph;
			superLinks = m.superLinks;
			superNodes = m.superNodes;
			nodeID = m.nodeID;
			linkID = m.linkID;
			superLinkID = m.superLinkID;
			qtree = new QuadTree(this);
		}
		return *this;
	}

	void Map::initMap(const std::string &filename)
	{
		unsigned int nodes, temp, i, org, dest, match_count, biggest_key = 0;
		int links, j, lkey;
		double lat, lon,snr,dop,avg_speed;
		char line[1024];
		ifstream file(filename.c_str(), ifstream::in);

		if (file.fail())
			return;

		file.getline(line, sizeof(line)-1);

		if (file.eof() || file.fail())
			return;

		sscanf(line, " %u", &nodes);

		for (i=0; i<nodes; i++)
		{
			file.getline(line, sizeof(line)-1);

			sscanf(line, " %u %lf %lf %lf %lf", &temp, &lon, &lat, &snr, &dop);

			if (temp > biggest_key)
				biggest_key = temp;

			addNode(temp, lat, lon, snr, dop);
		}

		nodeID = biggest_key + 1;

		file.getline(line, sizeof(line)-1);
		sscanf(line, " %d", &links);

		for (j=0; j<links; j++)
		{
			file.getline(line, sizeof(line)-1);

			sscanf(line, " %u %u %lf %u", &org, &dest, &avg_speed, &match_count);

			addLinkToNode(org, dest,avg_speed,match_count);
		}
	}

	void Map::initMapFromRoute(const Route& route)
	{
		cout << "initing map from route... " << endl;
		int i, size;
		rNode curr;
		unsigned int lastKey, currKey;

		size = route.size();
		curr = route.getNode(0);

		lastKey = addNodeToMap(curr.lat, curr.lon,curr.avgSnr,curr.dop);

		for (i=1; i<size; i++)
		{
			curr = route.getNode(i);

			currKey = addNodeToMap(curr.lat, curr.lon,curr.avgSnr,curr.dop);

			addLinkToNode(lastKey, currKey,curr.speed);

			lastKey = currKey;
		}
		cout << "map initiated." << endl;
	}

	void Map::saveMap(const string& filename)
	{
		std::map<unsigned int, mNode>::iterator node_it;
		std::map<int, mLink>::iterator link_it;

		ofstream file(filename.c_str());


		file.precision(9);
		file.setf(std::ios::fixed, std::ios::floatfield);

		//cout << "when saving... " << nodes.size() << " and graph " << graph.size() << endl;

		file << nodes.size() << endl;

		for (node_it = nodes.begin(); node_it != nodes.end(); node_it++)
			file << node_it->first << "  " << node_it->second.longitude << "  " << node_it->second.latitude
			<< " " << node_it->second.snr << " " << node_it->second.dop << endl;

		file << links.size() << endl;

		for (link_it = links.begin(); link_it != links.end(); link_it++)
			file << link_it->second.orID << "  " << link_it->second.destID << " " << link_it->second.avgSpeed 
			<<" " << link_it->second.match_count <<endl;

		file.close();	

	}

	void Map::saveMapForEjaki(const string& filename)
	{
		std::map<unsigned int, mNode>::iterator node_it;
		std::map<int, mLink>::iterator link_it;

		ofstream file(filename.c_str());


		file.precision(9);
		file.setf(std::ios::fixed, std::ios::floatfield);

		//cout << "when saving... " << nodes.size() << " and graph " << graph.size() << endl;

		file << nodes.size() << endl;

		for (node_it = nodes.begin(); node_it != nodes.end(); node_it++)
			file << node_it->first << "  " << node_it->second.longitude << "  " << node_it->second.latitude
			<< " " << node_it->second.longm << " " << node_it->second.latm 
			<< endl;

		file << links.size() << endl;

		for (link_it = links.begin(); link_it != links.end(); link_it++)
			file << link_it->first << " " << link_it->second.orID << "  " << link_it->second.destID 
			<< " " << link_it->second.heading << " " << link_it->second.length 
			<< " " << link_it->second.avgSpeed << " " << link_it->second.match_count 
			<<endl;

		file.close();	

	}

	void Map::saveToKml(const string &filename)
	{
		KmlWriter writer(filename);

		writer.buildMap(*this,"Map");

		writer.closeDocument();
	}

	NodeKey Map::addNodeToMap(double lat, double lon, double snr, double dop)
	{
		return addNode(nodeID++, lat, lon, snr, dop);
	}

	LinkKey Map::addLinkToNode(NodeKey startNode, NodeKey endNode, double avg_speed, unsigned int match_count)
	{
		return addLink(linkID++, startNode, endNode, avg_speed, match_count);
	}

	NodeKey Map::addNode(NodeKey key, double lat, double lon, double snr, double dop)
	{
		GPSPoint p(GPSPoint::convertWGS84ToUTM(lat, lon));

		map<NodeKey, mNode>::iterator itr = nodes.find(key);

		if (itr != nodes.end())
		{
			cout << "ERROR: trying to add a node with an existing key : " << key << endl;
		}

		mNode newNode(lat, lon, p.latm, p.longm, snr, dop);

		nodes.insert(make_pair(key, newNode));

		graph.insert(make_pair(key, mEdges()));

		superGraph.insert(make_pair(key, mSuperEdges()));

		qtree->addNode(key);

		return key;
	}

	NodeKey Map::addNodeInLink(LinkKey link, double lat, double lon, double snr, double dop)
	{
		int ptr;
		NodeKey newNode, startNode, endNode;
		LinkKey newLinkKey;
		std::list<LinkKey>::iterator list_it;
		std::map<LinkKey, mLink>::iterator link_it;
		std::map<NodeKey, mEdges>::iterator graph_it;
		std::map<NodeKey, mSuperEdges>::iterator superGraph_it;
		std::map<SuperLinkKey, mSuperLink>::iterator superLink_it;

		newNode = addNodeToMap(lat, lon, snr, dop);
		superGraph_it = superGraph.find(newNode);
		std::cout << "deleting super node: " << superGraph_it->first << std::endl;
		superGraph.erase(superGraph_it);


		newLinkKey = linkID++;
		link_it = links.find(link);

		startNode = link_it->second.orID;
		endNode = link_it->second.destID;

		Point newPoint(getNodePoint(newNode));
		Point startPoint(getNodePoint(startNode));
		Point endPoint(getNodePoint(endNode));

		link_it->second.destID = newNode;
		link_it->second.heading = calcHeading(startPoint, newPoint);
		link_it->second.length = distance2Points(startPoint, newPoint);

		mLink newLink(newNode, endNode, link_it->second.superLink, calcHeading(newPoint, endPoint), distance2Points(newPoint, endPoint), link_it->second.avgSpeed, link_it->second.match_count);
		newLink.sequenceNumber = link_it->second.sequenceNumber + 1;
		links.insert(make_pair(newLinkKey, newLink));

		graph_it = graph.find(newNode);
		graph_it->second.predecessors.insert(link_it->first);
		graph_it->second.successors.insert(newLinkKey);

		graph_it = graph.find(endNode);
		graph_it->second.predecessors.erase(link_it->first);
		graph_it->second.predecessors.insert(newLinkKey);

		superLink_it = superLinks.find(link_it->second.superLink);

		for (list_it = superLink_it->second.links.begin(); list_it != superLink_it->second.links.end(); list_it++)
		{
			if (*list_it == link_it->first)
				break;
		}

		list_it++;
		list_it = superLink_it->second.links.insert(list_it, newLinkKey);

		for (list_it++; list_it != superLink_it->second.links.end(); list_it++)
		{
			link_it = links.find(*list_it);
			link_it->second.sequenceNumber++;
		}

		return newNode;
	}

	LinkKey Map::addLink(LinkKey linkKey, NodeKey startNode, NodeKey endNode, double avg_speed, unsigned int match_count)
	{
		if (startNode == endNode)
		{
			cout << "ERROR: trying to add a link with the same start and end node." << endl;
			return -1;
		}

		//std::cout << "Adding link between points " << startNode << " and " << endNode << " with key: " << linkKey << std::endl;

		int ptr;
		//bool splitOr = false;
		//bool splitDest = false;
		list<LinkKey> temp;
		list<LinkKey>::iterator list_it;
		std::map<NodeKey, mEdges>::iterator graph_start, graph_end, graph_it;
		std::map<LinkKey, mLink>::iterator link_it;
		std::map<SuperNodeKey, mSuperEdges>::iterator superGraph_start, superGraph_end;
		std::map<SuperLinkKey, mSuperLink>::iterator superLinks_start, superLinks_end;

		Point org(getNodePoint(startNode));
		Point dest(getNodePoint(endNode));

		mLink l (startNode, endNode, -1, calcHeading(org, dest), distance2Points(org, dest), avg_speed, match_count);


		superGraph_start = superGraph.find(startNode);
		superGraph_end = superGraph.find(endNode);
		graph_start = graph.find(startNode);
		graph_end = graph.find(endNode);

		int startNodeIn = getNodeIndegree(startNode);
		int startNodeOut = getNodeOutdegree(startNode);
		int endNodeIn = getNodeIndegree(endNode);
		int endNodeOut = getNodeOutdegree(endNode);

		//std::cout << startNodeIn << "  " << startNodeOut << "  " << endNodeIn << "  " << endNodeOut << std::endl;

		if (superGraph_start == superGraph.end()) //split super link on startNode
		{
				//std::cout << "spliting or super link..." << std::endl;
				link_it = links.find(*graph_start->second.successors.begin());

				if (link_it == links.end())
					std::cout << "Link not found: " << *graph_start->second.successors.begin() << std::endl;
				
				splitSuperLink(link_it->second.superLink, startNode);

				superGraph_start = superGraph.find(startNode);
				//std::cout << "super link split in " << startNode << std::endl;
				//splitOr = true;
		}

		if (superGraph_end == superGraph.end()) //split super link on endNode
		{
			//std::cout << "spliting dest super link..." << std::endl;
			link_it = links.find(*graph_end->second.predecessors.begin());
			superLinks_end = superLinks.find(link_it->second.superLink);
			
			splitSuperLink(superLinks_end->first, endNode);		

			superGraph_end = superGraph.find(endNode);
			//std::cout << "super link split in " << endNode << std::endl;
			//splitDest = true;
		}


		if ((startNodeIn == 1 && startNodeOut == 0 && endNodeIn == 0 && endNodeOut == 1)) //merge two super links
		{
			//std::cout << "merging two super links..." << std::endl;
			superLinks_start = superLinks.find(*superGraph_start->second.predecessors.begin());
			superLinks_end = superLinks.find(*superGraph_end->second.successors.begin());

			if (superLinks_start->first == superLinks_end->first) //close a super-link
			{
				superLinks_start->second.links.push_back(linkKey);
				l.superLink = superLinks_start->first;
				l.sequenceNumber = (int)superLinks_start->second.links.size() - 1;

				superGraph_end = superGraph.find(superLinks_end->second.destNode);
				superGraph.erase(superGraph_end);

				superGraph_start = superGraph.find(superLinks_start->second.orNode);
				superGraph_start->second.predecessors.insert(superLinks_start->first);

				superLinks_start->second.destNode = superLinks_start->second.orNode;
			}
			else
			{
				temp.clear();
				temp = superLinks_start->second.links;
				temp.push_back(linkKey);

				l.superLink = superLinks_start->first;
				l.sequenceNumber = (int)temp.size()-1;

				for (list_it = superLinks_end->second.links.begin(), ptr = (int)temp.size(); list_it != superLinks_end->second.links.end(); list_it++, ptr++)
				{
					link_it = links.find(*list_it);
					link_it->second.superLink = superLinks_start->first;
					link_it->second.sequenceNumber = ptr;
				}

				temp.splice(temp.end(), superLinks_end->second.links);


				//std::cout << "deleting super node: " << startNode << std::endl;
				superGraph.erase(startNode);
				//std::cout << "deleting super node: " << endNode << std::endl;
				superGraph.erase(endNode);

				superGraph_end = superGraph.find(superLinks_end->second.destNode);
				superGraph_end->second.predecessors.erase(superLinks_end->first);
				superGraph_end->second.predecessors.insert(superLinks_start->first);

				superLinks_start->second.destNode = superLinks_end->second.destNode;
				superLinks_start->second.links = temp;
				superLinks.erase(superLinks_end);
			}
		}
		else if (startNodeIn == 1 && startNodeOut == 0) //extend left super link
		{
			//std::cout << "extending left super link..." << std::endl;
			superGraph_start = superGraph.find(startNode);
			superGraph_end = superGraph.find(endNode);

			superLinks_start = superLinks.find(*superGraph_start->second.predecessors.begin());

			if (superLinks_start == superLinks.end())
				std::cout << " Super Link " << *superGraph_start->second.predecessors.begin() << " doesn't exist." << std::endl;

			superLinks_start->second.destNode = endNode;
			superLinks_start->second.links.push_back(linkKey);
			l.superLink = superLinks_start->first;
			l.sequenceNumber = (int) superLinks_start->second.links.size() - 1;

			//std::cout << "deleting super node: " << superGraph_start->first << std::endl;
			superGraph.erase(superGraph_start);

			superGraph_end->second.predecessors.insert(superLinks_start->first);
		}
		else if (endNodeIn == 0 && endNodeOut == 1) //extend right super link
		{
			//std::cout << "extending right super link..." << std::endl;
			superGraph_start = superGraph.find(startNode);
			superGraph_end = superGraph.find(endNode);

			superLinks_end = superLinks.find(*superGraph_end->second.successors.begin());

			superLinks_end->second.orNode = startNode;
			superLinks_end->second.links.push_front(linkKey);
			l.superLink = superLinks_end->first;
			l.sequenceNumber = 0;

			for (list_it = superLinks_end->second.links.begin(), list_it++; list_it != superLinks_end->second.links.end(); list_it++)
			{
				link_it = links.find(*list_it);
				link_it->second.sequenceNumber++;
			}

			//std::cout << "deleting super node: " << superGraph_end->first << std::endl;
			superGraph.erase(superGraph_end);

			superGraph_start->second.successors.insert(superLinks_end->first);
		}
		else 
		{
			//std::cout << "adding a one-link super link..." << std::endl;
			//std::cout << startNodeIn << "  " << startNodeOut << "  " << endNodeIn << "  " << endNodeOut << std::endl;
			l.superLink = superLinkID++;
			l.sequenceNumber = 0;

			temp.clear();
			temp.push_front(linkKey);

			superLinks.insert(make_pair(l.superLink, mSuperLink(startNode, endNode, temp)));

			superGraph_start->second.successors.insert(l.superLink);
			superGraph_end->second.predecessors.insert(l.superLink);
		}

		//map part
		links.insert(make_pair(linkKey, l));

		graph_it = graph.find(startNode);
		graph_it->second.successors.insert(linkKey);

		graph_it = graph.find(endNode);
		graph_it->second.predecessors.insert(linkKey);

		return linkKey;	
	}

	void Map::mergePaths(vector<pair<int,vector<int> > > matchedLinks,int order)
	{
		vector<pair<int, vector<int> > >::iterator match_itr;
		for (match_itr = matchedLinks.begin(); match_itr != matchedLinks.end(); match_itr++)
		{
			this->mergeLinks(match_itr->first,match_itr->second,order);
		}
		for (match_itr = matchedLinks.begin(); match_itr != matchedLinks.end(); match_itr++)
		{
			vector<int>::iterator link2_itr;
			for (link2_itr = match_itr->second.begin(); link2_itr != match_itr->second.end(); link2_itr++)
			{
				this->deleteLink(*link2_itr);
			}
		}
	}

	void Map::mergeLinks(int link1ID, vector<int> matchedLinks,int order)
	{
		cout << "->Merging links " << link1ID << endl; // " " << link2ID << endl;
		//rever isto melhor
		map<int,mLink>::iterator link1_itr = this->links.find(link1ID);
		if (link1_itr == links.end())
		{
			cout << "ERROR: merging non existing link: " << link1ID << endl;
			return;
		}
		
		map<int,mLink>::iterator firstLink2_itr = links.find(matchedLinks.front());
		if (firstLink2_itr == links.end())
		{
			cout << "ERROR: first link from path2 doesn't exist: " << matchedLinks.front() << endl;
			return;
		}

		map<int,mLink>::iterator lastLink2_itr = links.find(matchedLinks.back());
		if (matchedLinks.size() > 0)
		{
			if (lastLink2_itr == links.end())
			{
				cout << "ERROR: last link from path2 doesn't exist: " << matchedLinks.back() << endl;
				return;
			}
		}
		else
		{
			lastLink2_itr = firstLink2_itr;
		}

		unsigned int firstNode1 = link1_itr->second.orID;
		unsigned int lastNode1 = link1_itr->second.destID;
		unsigned int firstNode2 = firstLink2_itr->second.orID;
		unsigned int lastNode2 = lastLink2_itr->second.destID;
		if (order < 0)
		{
			firstNode1 = link1_itr->second.destID;
			lastNode1 = link1_itr->second.orID;
			firstNode2 = firstLink2_itr->second.destID;
			lastNode2 = lastLink2_itr->second.orID;
		}

		//find average for first and last node
		if (firstNode1 != firstNode2)
		{
			this->calcAvgNode(firstNode1,link1_itr->second.match_count,firstNode2,firstLink2_itr->second.match_count);
		}
		if (lastNode1 != lastNode2)
		{
			this->calcAvgNode(lastNode1,link1_itr->second.match_count,lastNode2,lastLink2_itr->second.match_count);
		}

		//merge all the edges
		//cout << "merging all the edges from node." << endl;
		map<int,mLink>::iterator link2_itr;
		for (int i = 0; i < matchedLinks.size(); i++)
		{
			int link2ID = matchedLinks[i];
			if (link1ID == link2ID)
			{
				//cout << "link 1 and link 2 are the same: " << link1ID << endl;
				continue;
			}

			link2_itr = links.find(link2ID);
			if (link2_itr == links.end())
			{
				cout << "link 2 doesn't exist: " << link2ID << endl;
				continue;
			}

			map<unsigned int, mNode>::iterator node2_itr = nodes.find(link2_itr->second.orID);
			if (node2_itr == nodes.end())
			{
				cout << "or node from link " << link2ID << "doesn't exist : " << link2_itr->second.orID << endl;
				continue;
			}

			if (link1_itr->second.orID == link2_itr->second.orID)
			{
				cout << "node 1 on link " << link1_itr->first << " and node 2 on link " << link2_itr->first << " are the same: " << link1_itr->second.orID << endl;
				continue;
			}

			link1_itr->second.avgSpeed = (link1_itr->second.avgSpeed * link1_itr->second.match_count + link2_itr->second.avgSpeed * link2_itr->second.match_count)
				/ (link1_itr->second.match_count + link2_itr->second.match_count);
			link1_itr->second.match_count += link2_itr->second.match_count;

			//cout << "Merging edges from node: " << link2_itr->second.orID << " to link: " << link1_itr->second.orID << endl;
			this->mergeEdges(link1_itr->second.orID,link2_itr->second.orID);
		}
		map<unsigned int, mNode>::iterator node2_dest_itr = nodes.find(link2_itr->second.destID);
		if (node2_dest_itr == nodes.end())
		{
			cout << "dest node from link " << link2_itr->first << "doesn't exist : " << link2_itr->second.destID << endl;
			return;
		}
		if (link1_itr->second.destID != link2_itr->second.destID)
		{
			//cout << "Merging edges from node: " << link2_itr->second.destID << " to link: " << link1_itr->second.destID << endl;
			this->mergeEdges(link1_itr->second.destID,link2_itr->second.destID);
		}
		else
		{
			cout << "dest node from link " << link1_itr->first << " and link " << link2_itr->first << " are the same: " << link1_itr->second.destID << endl;
		}
	}


	void Map::mergeEdges(unsigned int nodeID1, unsigned int nodeID2)//,int linkBeforeID, int linkAfterID)
	{
		//cout << "Merging edges from node " << nodeID2 << " to node " << nodeID1 << endl;
		map<unsigned int,mNode>::iterator nd_itr = nodes.find(nodeID1);
		if (nd_itr == nodes.end())
		{
			cout << "Merging non existing node: " << nodeID1 << endl;
			return;
		}
		nd_itr = nodes.find(nodeID2);
		if (nd_itr == nodes.end())
		{
			cout << "Merging non existing node: " << nodeID2 << endl;
			return;
		}

		map<unsigned int, mEdges>::iterator edges1_itr = graph.find(nodeID1);
		map<unsigned int, mEdges>::iterator edges2_itr = graph.find(nodeID2);

		if (edges1_itr == graph.end() || edges2_itr == graph.end())
		{
			cout << "Nodes don't exist in graph: " << (edges1_itr == graph.end()) << " " << (edges2_itr == graph.end()) << endl;
			return;
		}

		map<unsigned int, mNode>::iterator node1_itr = nodes.find(nodeID1);
		map<unsigned int, mNode>::iterator node2_itr = nodes.find(nodeID2);

		if (node1_itr == nodes.end() || node2_itr == nodes.end())
		{
			cout << "Nodes don't exist in nodes: " << (node1_itr == nodes.end()) << " " << (node2_itr == nodes.end()) << endl;
			return;
		}

		Point nodePoint(getNodePoint(nodeID1));

		//update all predecessors and successors of node 1
		for (set<int>::iterator itr = edges1_itr->second.predecessors.begin(); itr != edges1_itr->second.predecessors.end(); itr++)
		{
			mLink& link = links[*itr];

			Point p(getNodePoint(link.orID));
			link.heading = calcHeading(p,nodePoint);
			link.length = distance2Points(p,nodePoint);
		}
		for (set<int>::iterator itr = edges1_itr->second.successors.begin(); itr != edges1_itr->second.successors.end(); itr++)
		{
			mLink& link = links[*itr];

			Point p(getNodePoint(link.destID));
			link.heading = calcHeading(nodePoint,p);
			link.length = distance2Points(nodePoint,p);
		}

		//change all predecessors links from node 2 to node 1
		//cout << "change all predecessors links from node " <<  nodeID2 << " to node " << nodeID1 << endl;
		set<int> predecessors(edges2_itr->second.predecessors);
		for (set<int>::iterator itr = predecessors.begin(); itr != predecessors.end(); itr++)
		{
			//cout << "\tpredecessor of node " << nodeID2 << ": " << *itr << endl;

			map<int, mLink>::iterator link_itr = links.find(*itr);
			if (link_itr != links.end())
			{
				//i'm not sure
				if (link_itr->second.orID == nodeID1)
				{
					cout << "\t\tor ID is nodeID1 deleting link: " << *itr << endl;
					this->deleteLink(link_itr->first);
					continue;
				}
				this->updateLink(link_itr->first,link_itr->second.orID, nodeID1);
			}
			else
			{
				//cout << "\tlink: " << *itr << " not found" << endl;
				edges2_itr->second.predecessors.erase(*itr);
			}
		}

		//change all successors links from node 2 to node 1
		//cout << "change all successors links from node " <<  nodeID2 << " to node " << nodeID1 << endl;

		//node2 may be deleted in the way
		node2_itr = nodes.find(nodeID2);
		if (node2_itr != nodes.end())
		{
			set<int> successors( edges2_itr->second.successors);
			for (set<int>::iterator itr = successors.begin(); itr != successors.end(); itr++)
			{
				//cout << "\tsuccessor of node " << nodeID2 << ": " << *itr << endl;

				map<int, mLink>::iterator link_itr = links.find(*itr);
				if (link_itr != links.end())
				{
					//i'm not sure
					if (link_itr->second.destID == nodeID1)
					{
						//cout << "\t\tdest ID is nodeID1 deleting link: " << *itr << endl;
						this->deleteLink(*itr);
						continue;
					}
					this->updateLink(link_itr->first,nodeID1, link_itr->second.destID);
				}
				else
				{
					//cout << "\tlink: " << *itr << " not found." << endl;
					edges2_itr->second.successors.erase(*itr);
				}
			}
		}
		//else
		//{
		//	cout << "node 2: " << nodeID2 << " doesn't exists anymore." << endl; 
		//}
	}

	void Map::updateLink(int linkID, unsigned int newOrID, unsigned int newDestID)
	{
		//HUGO
		mNode tNode;
		map<NodeKey, mNode>::iterator node_it;
		map<int, mLink>::iterator link_it = links.find(linkID);
		//std::cout << "Updating link: " << linkID << std::endl;

		if (link_it != links.end())
		{
			mLink temp = link_it->second;

			if (temp.orID == newOrID && temp.destID == newDestID)
			{
				cout << "link " << linkID << " is being updated to the same nodes." << endl;
				return;
			}

			if (link_it->second.orID == newOrID)
				tNode = nodes[newOrID];
			else if (link_it->second.destID == newDestID)
				tNode = nodes[newDestID];

			deleteLink(linkID);

			if (nodes.find(newOrID) == nodes.end())
				addNode(newOrID, tNode.latitude, tNode.longitude, tNode.snr, tNode.dop);
			else if (nodes.find(newDestID) == nodes.end())
				addNode(newDestID, tNode.latitude, tNode.longitude, tNode.snr, tNode.dop);


			addLink(linkID, newOrID, newDestID, temp.avgSpeed, temp.match_count);
		}
		else
		{
			cout << "ERROR: Link " << linkID << " not found." << std::endl;
		}

		//std::cout << "Updating ended." << std::endl;

		//NUNO
		//map<int, mLink>::iterator link_itr = links.find(linkID);
		//if (link_itr != links.end())
		//{
		//	unsigned int oldOrID = link_itr->second.orID;
		//	unsigned int oldDestID = link_itr->second.destID;

		//	if (oldOrID == newOrID && oldDestID == newDestID)
		//	{
		//		cout << "link " << linkID << " is being updated to the same nodes." << endl;
		//		return;
		//	}

		//	map<unsigned int, mNode>::iterator newOr_itr = nodes.find(newOrID);
		//	if (newOr_itr == nodes.end())
		//	{
		//		cout << "ERROR: new or node doesn't exist " << newOrID << endl;
		//		return;
		//	}

		//	map<unsigned int, mNode>::iterator newDest_itr = nodes.find(newDestID);
		//	map<unsigned int, mEdges>::iterator newDestEdges = graph.find(newDestID);
		//	if (newDest_itr == nodes.end())
		//	{
		//		cout << "ERROR: new dest node doesn't exist " << newDestID << endl;
		//		return;
		//	}

		//	Point newOrPoint(newOr_itr->second.longm, newOr_itr->second.latm);
		//	Point newDestPoint(newDest_itr->second.longm, newDest_itr->second.latm);

		//	link_itr->second.destID = newDestID;
		//	link_itr->second.orID = newOrID;
		//	link_itr->second.heading = calcHeading(newOrPoint,newDestPoint);
		//	link_itr->second.length = distance2Points(newOrPoint,newDestPoint);


		//	if (newOrID != oldOrID)
		//	{
		//		//cout << "changing or of link: " << link_itr->first << " from node " << oldOrID << " to node " << newOrID << endl;
		//		map<unsigned int, mEdges>::iterator newOrEdges = graph.find(newOrID);
		//		map<unsigned int, mEdges>::iterator oldOrEdges = graph.find(oldOrID);
		//		if (newOrEdges != graph.end() && oldOrEdges != graph.end())
		//		{
		//			oldOrEdges->second.successors.erase(linkID);
		//			newOrEdges->second.successors.insert(linkID);

		//			if (oldOrEdges->second.successors.size() == 0 && oldOrEdges->second.predecessors.size() == 0)
		//			{
		//				this->deleteNode(oldOrID);
		//			}
		//		}
		//	}

		//	if (newDestID != oldDestID)
		//	{
		//		//cout << "changing dest of link: " << link_itr->first << " from node " << oldDestID << " to node " << newDestID << endl;
		//		map<unsigned int, mEdges>::iterator newDestEdges = graph.find(newDestID);
		//		map<unsigned int, mEdges>::iterator oldDestEdges = graph.find(oldDestID);
		//		if (newDestEdges != graph.end() && oldDestEdges != graph.end())
		//		{
		//			oldDestEdges->second.predecessors.erase(linkID);
		//			newDestEdges->second.predecessors.insert(linkID);

		//			if (oldDestEdges->second.successors.size() == 0 && oldDestEdges->second.predecessors.size() == 0)
		//			{
		//				this->deleteNode(oldDestID);
		//			}
		//		}

		//	}
		//}
		//else
		//{
		//	cout << "link " << linkID << " not found for update or and dest." << endl;
		//}
	}

	//isto assim nao esta muito bem
	mNode Map::calcAvgNode(mNode node1,int link1Count,mNode node2, int link2Count)
	{
		double avgLonm = (node1.longm * link1Count + node2.longm * link2Count) / (link1Count + link2Count);
		double avgLatm = (node1.latm * link1Count + node2.latm * link2Count) / (link1Count + link2Count);
		double dop = (node1.dop * link1Count +  node2.dop * link2Count) / (link1Count + link2Count);
		double snr = (node1.snr * link1Count +  node2.snr * link2Count) / (link1Count + link2Count);
		
		GPSPoint p (GPSPoint::convertUTMToWGS84(avgLonm,avgLatm,GPSPoint::getZone(node1.longitude),GPSPoint::getLatZone(node1.latitude)));

		mNode avgNode(p.lat,p.lon,avgLatm,avgLonm,snr,dop);
		return avgNode;
	}

	void Map::calcAvgNode(unsigned int node1ID,int link1Count, unsigned int node2ID, int link2Count)
	{
		map<unsigned int, mNode>::iterator node1_itr = nodes.find(node1ID);
		if (node1_itr == nodes.end())
		{
			cout << "ERROR: node from path 1 doesn't exist: " << node1ID << endl;
			return;
		}
		if (node1ID != node2ID)
		{
			map<unsigned int, mNode>::iterator node2_itr = nodes.find(node2ID);
			if (node2_itr == nodes.end())
			{
				cout << "ERROR: node from path 2 doesn't exist: " << node2ID << endl;
				return;
			}

			//this->updateNode(node1_itr,calcAvgNode(node1_itr->second,link1Count,node2_itr->second,link2Count));
			
			position olLocation = getNodePosition(node1_itr->first);
			node1_itr->second = calcAvgNode(node1_itr->second,link1Count,node2_itr->second,link2Count);
			
			qtree->updateNodeLocation(node1_itr->first, olLocation);
		}
		else
		{
			cout << "node from path1 and path2 are the same: " << node1ID << endl;
		}
	}


	void Map::deleteLink(LinkKey linkKey)
	{
		//std::cout << "Trying to delete link: " << linkKey << std::endl;
		NodeKey startNode, endNode;
		SuperLinkKey superLink;
		map<LinkKey, mLink>::iterator link_it;
		map<NodeKey, mEdges>::iterator graph_it;

		link_it = links.find(linkKey);

		if (link_it == links.end())
		{
			std::cout << "ERROR: Link " << linkKey << " not found." << std::endl;
			return;
		}

		//std::cout << " with or in " << link_it->second.orID << " and dest in " << link_it->second.destID << " from super-link: " << link_it->second.superLink << std::endl;

		if (link_it != links.end())
		{
			startNode = link_it->second.orID;
			endNode = link_it->second.destID;
			superLink = link_it->second.superLink;
			links.erase(linkKey);

			graph_it = graph.find(startNode);
			graph_it->second.successors.erase(linkKey);
			
			graph_it = graph.find(endNode);

			if (graph_it->second.predecessors.find(linkKey) == graph_it->second.predecessors.end())
				std::cout << "link " << linkKey << " should exist here." << std::endl;

			graph_it->second.predecessors.erase(linkKey);


			deleteLinkFromSuperLink(superLink, linkKey);


			if (getNodeDegree(startNode) == 0)
				deleteNode(startNode);

			if (getNodeDegree(endNode) == 0)
				deleteNode(endNode);
		}
	}

	void Map::deleteNode(NodeKey nodeKey)
	{
		//std::cout << "Trying to delete node with key: " << nodeKey << std::endl;

		map<unsigned int,mNode>::iterator itr = nodes.find(nodeKey);
		if (itr != nodes.end())
		{
			position oldPos(itr->second.latitude, itr->second.longitude);
			nodes.erase(nodeKey);
			graph.erase(nodeKey);
			superGraph.erase(nodeKey);

			this->qtree->removeNode(nodeKey, oldPos);
			//std::cout << "Node " << nodeKey << " deleted." << std::endl;
		}
	}

	unsigned int Map::updateNode(unsigned int key, mNode updatedNode)
	{
		position olLocation = getNodePosition(key);

		nodes[key] = updatedNode;
		qtree->updateNodeLocation(key, olLocation);

		set<int>::iterator itr;
		for (itr = graph[key].predecessors.begin(); itr != graph[key].predecessors.end(); itr++)
		{
			map<int, mLink>::iterator linkItr = links.find(*itr);
			Point org(getNodePoint(linkItr->second.orID));
			Point dest(getNodePoint(linkItr->second.destID));

			linkItr->second.heading = calcHeading(org,dest);
			linkItr->second.length = distance2Points(org.getX(),org.getY(),dest.getX(),dest.getY());
		}

		for (itr = graph[key].successors.begin(); itr != graph[key].successors.end(); itr++)
		{
			map<int, mLink>::iterator linkItr = links.find(*itr);
			Point org(getNodePoint(linkItr->second.orID));
			Point dest(getNodePoint(linkItr->second.destID));

			linkItr->second.heading = calcHeading(org,dest);
			linkItr->second.length = distance2Points(org.getX(),org.getY(),dest.getX(),dest.getY());
		}
		return key;
	}

	//void Map::addMatchCount(int link,unsigned int count)
	void Map::updateLinkStats(int link,double speed, unsigned int count)
	{
		std::map<LinkKey, mLink>::iterator it = links.find(link);

		if (it != links.end())
		{
			it->second.avgSpeed = (it->second.avgSpeed * it->second.match_count + speed * count) / (it->second.match_count + count);
			it->second.match_count += count;
		}
		else
			cout << "ERROR: non existing link " << link << "." << endl;


		/*mLink& link_ref = links[link];

		link_ref.avgSpeed = (link_ref.avgSpeed * link_ref.match_count + speed * count) / (link_ref.match_count + count);
		link_ref.match_count += count;*/
	}
	
	void Map::buildSuperMap()
	{
		int i, counter;
		SuperLinkKey sLinkKey;
		LinkKey tLink;
		NodeKey endNode;
		std::map<NodeKey, mEdges>::iterator graph_it;
		std::vector<NodeKey> starterNodes;
		std::set<LinkKey>::iterator edges_it;
		std::list<LinkKey> tList;

		superLinks.clear();
		superNodes.clear();
		superGraph.clear();

		for (graph_it = graph.begin(); graph_it != graph.end(); graph_it++)
		{
			if (!(getNodeIndegree(graph_it->first) == 1 && getNodeOutdegree(graph_it->first) == 1))
				superGraph.insert(make_pair(graph_it->first, mSuperEdges()));

			if (isSourceNode(graph_it->first) || isJunction(graph_it->first))
				starterNodes.push_back(graph_it->first);
		}

		//std::cout << "We got " << starterNodes.size() << " nodes to process." << std::endl;

		for (i=0; i<starterNodes.size(); i++)
		{
			for (edges_it = graph[starterNodes[i]].successors.begin(); edges_it != graph[starterNodes[i]].successors.end(); edges_it++)
			{
				counter = 0;
				tList.clear();
				sLinkKey = superLinkID++;

				tLink = *edges_it;
				tList.push_back(tLink);
				links[tLink].superLink = sLinkKey;
				links[tLink].sequenceNumber = counter++;

				if (graph[links[tLink].destID].predecessors.size() == 1 && graph[links[tLink].destID].successors.size() == 1)
				{
					tLink = *graph[links[tLink].destID].successors.begin();

					while (graph[links[tLink].destID].successors.size() == 1 && graph[links[tLink].destID].predecessors.size() == 1)
					{
						tList.push_back(tLink);
						links[tLink].superLink = sLinkKey;
						links[tLink].sequenceNumber = counter++;

						tLink = *graph[links[tLink].destID].successors.begin();
					}

					tList.push_back(tLink);
					links[tLink].superLink = sLinkKey;
					links[tLink].sequenceNumber = counter++;
				}

				endNode = links[tLink].destID;

				mSuperLink newSuperLink(starterNodes[i], endNode, tList);
				superLinks.insert(make_pair(sLinkKey, newSuperLink));

				superGraph[starterNodes[i]].successors.insert(sLinkKey);
				superGraph[endNode].predecessors.insert(sLinkKey);
			}
		}
	}

	int Map::getNodeDegree(NodeKey node)
	{
		std::map<NodeKey, mEdges>::iterator it = graph.find(node);

		if (it == graph.end())
		{
			std::cout << "ERROR: There's no node in the map with key: " << node << std::endl;
			return -1;
		}

		return (it->second.predecessors.size() + it->second.successors.size());
	}

	int Map::getNodeIndegree(NodeKey node)
	{
		std::map<NodeKey, mEdges>::iterator it = graph.find(node);

		if (it == graph.end())
		{
			std::cout << "ERROR: There's no node in the map with key: " << node << std::endl;
			return -1;
		}

		return it->second.predecessors.size();
	}

	int Map::getNodeOutdegree(NodeKey node)
	{
		std::map<NodeKey, mEdges>::iterator it = graph.find(node);

		if (it == graph.end())
		{
			std::cout << "ERROR: There's no node in the map with key: " << node << std::endl;
			return -1;
		}

		return it->second.successors.size();
	}

	SuperLinkKey Map::getSuperLinkKey(LinkKey link)
	{
		std::map<LinkKey, mLink>::iterator it = links.find(link);

		if (it == links.end())
		{
			std::cout << "ERROR: There's no link in the map with key: " << link << std::endl;
			return -1;
		}

		return it->second.superLink;
	}

	int Map::getSequenceNumber(LinkKey link)
	{
		std::map<LinkKey, mLink>::iterator it = links.find(link);

		if (it == links.end())
		{
			std::cout << "ERROR: There's no link in the map with key: " << link << std::endl;
			return -1;
		}

		return it->second.sequenceNumber;
	}

	void Map::splitSuperLink(SuperLinkKey superLink, NodeKey splitNode)
	{
		int ptr;
		std::list<LinkKey> temp;
		std::list<LinkKey>::iterator list_it;
		std::map<LinkKey, mLink>::iterator link_it;
		std::map<NodeKey, mSuperEdges>::iterator superGraph_it;
		std::map<SuperLinkKey, mSuperLink>::iterator superLink_it = superLinks.find(superLink);

		if (superLink_it == superLinks.end())
			std::cout << "Invalid Link: " << superLink << std::endl;

		if (superLink_it->second.orNode == superLink_it->second.destNode) // a closed super link
		{
			if (splitNode == superLink_it->second.orNode) // alreday split on the right node
				return;

			if (getNodeIndegree(superLink_it->second.orNode) == 1 && getNodeOutdegree(superLink_it->second.orNode) == 1) //commute super node
			{
				superGraph_it = superGraph.find(superLink_it->second.orNode);
				superGraph.erase(superGraph_it);

				superGraph_it = superGraph.insert(make_pair(splitNode, mSuperEdges())).first;
				superGraph_it->second.predecessors.insert(superLink_it->first);
				superGraph_it->second.successors.insert(superLink_it->first);

				superLink_it->second.destNode = splitNode;
				superLink_it->second.orNode = splitNode;

				for (list_it = superLink_it->second.links.begin(); list_it != superLink_it->second.links.end(); list_it++)
				{
					link_it = links.find(*list_it);

					if (link_it->second.orID == splitNode)
						break;					
				}

				superLink_it->second.links.insert(superLink_it->second.links.end(), superLink_it->second.links.begin(), list_it);
				superLink_it->second.links.erase(superLink_it->second.links.begin(), list_it);


				for (list_it = superLink_it->second.links.begin(), ptr = 0; list_it != superLink_it->second.links.end(); list_it++, ptr++)
				{
					link_it = links.find(*list_it);
					link_it->second.sequenceNumber = ptr;									
				}
			}
			else
			{
				for (list_it = superLink_it->second.links.begin(); list_it != superLink_it->second.links.end(); list_it++)
				{
					link_it = links.find(*list_it);

					if (link_it->second.orID == splitNode)
						break;								
				}

				temp.clear();
				temp.insert(temp.end(), list_it, superLink_it->second.links.end());
				superLink_it->second.links.erase(list_it, superLink_it->second.links.end());

				NodeKey endNode = superLink_it->second.destNode;

				superGraph_it = superGraph.find(superLink_it->second.destNode);
				superGraph_it->second.predecessors.erase(superLink_it->first);
				superLink_it->second.destNode = splitNode;

				superGraph_it = superGraph.insert(make_pair(splitNode, mSuperEdges())).first;
				superGraph_it->second.predecessors.insert(superLink_it->first);

				superLink_it = superLinks.insert(make_pair(superLinkID++, mSuperLink(splitNode, endNode, temp))).first;

				superGraph_it->second.successors.insert(superLink_it->first);
				superGraph_it = superGraph.find(endNode);
				superGraph_it->second.predecessors.insert(superLink_it->first);

				for (list_it = superLink_it->second.links.begin(), ptr = 0; list_it != superLink_it->second.links.end(); list_it++, ptr++)
				{
					link_it = links.find(*list_it);
					link_it->second.sequenceNumber = ptr;	
					link_it->second.superLink = superLink_it->first;
				}
			}
		}
		else
		{
			for (list_it = superLink_it->second.links.begin(); list_it != superLink_it->second.links.end(); list_it++)
			{
				link_it = links.find(*list_it);

				if (link_it->second.orID == splitNode)
					break;					
			}

			NodeKey destNode = superLink_it->second.destNode;
			LinkKey firstSuperLink = superLink_it->first;

			temp.insert(temp.end(), list_it, superLink_it->second.links.end());
			superLink_it->second.links.erase(list_it, superLink_it->second.links.end());
			superLink_it->second.destNode = splitNode;

			superLink_it = superLinks.insert(make_pair(superLinkID++, mSuperLink(splitNode, destNode, temp))).first;

			for (list_it = superLink_it->second.links.begin(), ptr = 0; list_it != superLink_it->second.links.end(); list_it++, ptr++)
			{
				link_it = links.find(*list_it);
				link_it->second.superLink = superLink_it->first;
				link_it->second.sequenceNumber = ptr;
			}

			superGraph_it = superGraph.insert(make_pair(splitNode, mSuperEdges())).first;
			superGraph_it->second.predecessors.insert(firstSuperLink);
			superGraph_it->second.successors.insert(superLink_it->first);

			superGraph_it = superGraph.find(destNode);
			superGraph_it->second.predecessors.erase(firstSuperLink);
			superGraph_it->second.predecessors.insert(superLink_it->first);
		}
	}

	void Map::deleteLinkFromSuperLink(SuperLinkKey superLinkKey, LinkKey linkKey)
	{
		int ptr;
		NodeKey newStart, newEnd;
		std::list<LinkKey> newPart;
		std::list<LinkKey>::iterator list_it, next_it;
		std::map<LinkKey, mLink>::iterator link_it;
		std::map<SuperLinkKey, mSuperLink>::iterator superLink_it;
		std::map<NodeKey, mSuperEdges>::iterator superGraph_it;


		superLink_it = superLinks.find(superLinkKey);

		if (superLink_it->second.orNode == superLink_it->second.destNode && getNodeIndegree(superLink_it->second.orNode) == 1 && getNodeOutdegree(superLink_it->second.orNode) == 1)
		{
			//std::cout << "Opening a close super link." << std::endl;

			for (list_it = superLink_it->second.links.begin(); list_it != superLink_it->second.links.end(); list_it++)
			{
				link_it = links.find(*list_it);

				if (link_it->first == linkKey)
					break;					
			}

			next_it = list_it;
			next_it++;
			newPart.insert(newPart.end(), next_it, superLink_it->second.links.end());
			newPart.insert(newPart.end(), superLink_it->second.links.begin(), list_it);

			superLink_it->second.links = newPart;
			superLink_it->second.orNode = links.find(superLink_it->second.links.front())->second.orID;
			superLink_it->second.destNode = links.find(superLink_it->second.links.back())->second.destID;

			superLinks.erase(superLink_it->second.destNode);

			superGraph_it = superGraph.insert(make_pair(superLink_it->second.orNode, mSuperEdges())).first;
			superGraph_it->second.successors.insert(superLink_it->first);

			superGraph_it = superGraph.insert(make_pair(superLink_it->second.destNode, mSuperEdges())).first;
			superGraph_it->second.predecessors.insert(superLink_it->first);

			for (list_it = superLink_it->second.links.begin(), ptr = 0; list_it != superLink_it->second.links.end(); list_it++, ptr++)
			{
				link_it = links.find(*list_it);
				link_it->second.sequenceNumber = ptr;									
			}
		}
		else if (superLink_it->second.links.size() == 1)
		{
			//std::cout << "Deleting super link. Size = 1." << std::endl;
			superGraph_it = superGraph.find(superLink_it->second.orNode);

			if (superGraph_it == superGraph.end())
				std::cout << "ERROR: super node not found: " << superLink_it->second.orNode << " super-link: " << superLink_it->first << " and link: " << linkKey << " dest: " << superLink_it->second.destNode << " and inside link: " << superLink_it->second.links.front() << std::endl;

			superGraph_it->second.successors.erase(superLink_it->first);

			if (getNodeIndegree(superLink_it->second.orNode) == 1 && getNodeOutdegree(superLink_it->second.orNode) == 1)
				mergeSuperLinks(superLink_it->second.orNode);

			superGraph_it = superGraph.find(superLink_it->second.destNode);
			superGraph_it->second.predecessors.erase(superLink_it->first);

			if (getNodeIndegree(superLink_it->second.destNode) == 1 && getNodeOutdegree(superLink_it->second.destNode) == 1)
				mergeSuperLinks(superLink_it->second.destNode);

			superLinks.erase(superLink_it);
		}
		else if (superLink_it->second.links.front() == linkKey) //remove first link from a super link
		{
			//std::cout << "Deleting first link from super link." << std::endl;
			superGraph_it = superGraph.find(superLink_it->second.orNode);
			superGraph_it->second.successors.erase(superLinkKey);

			if (getNodeIndegree(superLink_it->second.orNode) == 1 && getNodeOutdegree(superLink_it->second.orNode) == 1)
				mergeSuperLinks(superLink_it->second.orNode);

			superLink_it->second.links.pop_front();
			newStart = links.find(superLink_it->second.links.front())->second.orID;
			superLink_it->second.orNode = newStart;

			for (list_it = superLink_it->second.links.begin(); list_it != superLink_it->second.links.end(); list_it++)
			{
				link_it = links.find(*list_it);
				link_it->second.sequenceNumber--;
			}

			superGraph_it = superGraph.insert(make_pair(newStart, mSuperEdges())).first;
			superGraph_it->second.successors.insert(superLinkKey);
		}
		else if (superLink_it->second.links.back() == linkKey) //remove last link from a super link
		{
			//std::cout << "Deleting last link from super link." << std::endl;
			superGraph_it = superGraph.find(superLink_it->second.destNode);
			superGraph_it->second.predecessors.erase(superLinkKey);

			if (getNodeIndegree(superLink_it->second.destNode) == 1 && getNodeOutdegree(superLink_it->second.destNode) == 1)
				mergeSuperLinks(superLink_it->second.destNode);

			superLink_it->second.links.pop_back();
			newEnd = links.find(superLink_it->second.links.back())->second.destID;
			superLink_it->second.destNode = newEnd;

			superGraph_it = superGraph.insert(make_pair(newEnd, mSuperEdges())).first;
			superGraph_it->second.predecessors.insert(superLinkKey);
		}
		else
		{
			//std::cout << "Deleting link from the middle of a super link. (" << linkKey << ")" << std::endl;
			for (list_it = superLink_it->second.links.begin(); list_it != superLink_it->second.links.end(); list_it++)
			{
				if (*list_it == linkKey)
					break;
			}

			//std::cout << " Original super link size: " << superLink_it->second.links.size();

			list_it++;
			newPart.insert(newPart.end(), list_it, superLink_it->second.links.end());
			list_it--;
			superLink_it->second.links.erase(list_it, superLink_it->second.links.end());
			NodeKey oldEndFirstLink = superLink_it->second.destNode;

			//std::cout << "  first part size: " << superLink_it->second.links.size() << " and second part " << newPart.size() << std::endl;
			
			link_it = links.find(superLink_it->second.links.back());
			newEnd = link_it->second.destID;
			superLink_it->second.destNode = newEnd;

			link_it = links.find(newPart.front());
			newStart = link_it->second.orID;

			mSuperLink newSuperLink(newStart, oldEndFirstLink, newPart);
			superLink_it = superLinks.insert(make_pair(superLinkID++, newSuperLink)).first;

			superGraph_it = superGraph.insert(make_pair(newEnd, mSuperEdges())).first;
			superGraph_it->second.predecessors.insert(superLinkKey);

			superGraph_it = superGraph.insert(make_pair(newStart, mSuperEdges())).first;
			superGraph_it->second.successors.insert(superLink_it->first);

			superGraph_it = superGraph.find(oldEndFirstLink);
			superGraph_it->second.predecessors.erase(superLinkKey);
			superGraph_it->second.predecessors.insert(superLink_it->first);

			for (list_it = superLink_it->second.links.begin(), ptr = 0; list_it != superLink_it->second.links.end(); list_it++, ptr++)
			{
				link_it = links.find(*list_it);
				link_it->second.superLink = superLink_it->first;
				link_it->second.sequenceNumber = ptr;
			}
		}
	}

	void Map::mergeSuperLinks(NodeKey node)
	{
		int ptr;
		std::list<LinkKey>::iterator list_it;
		std::map<LinkKey, mLink>::iterator link_it;
		std::map<NodeKey, mSuperEdges>::iterator superGraph_it;
		std::map<SuperLinkKey, mSuperLink>::iterator superLink_first, superLink_second;

		//std::cout << "Trying to merge two super links at point: " << node << std::endl;

		if (getNodeIndegree(node) == 1 && getNodeOutdegree(node) == 1)
		{
			superGraph_it = superGraph.find(node);

			superLink_first = superLinks.find(*superGraph_it->second.predecessors.begin());
			superLink_second = superLinks.find(*superGraph_it->second.successors.begin());

			if (superLink_first->first == superLink_second->first) //a close super link
				return;

			ptr = (int) superLink_first->second.links.size();

			for (list_it = superLink_second->second.links.begin(); list_it != superLink_second->second.links.end(); list_it++, ptr++)
			{
				link_it = links.find(*list_it);
				link_it->second.superLink = superLink_first->first;
				link_it->second.sequenceNumber = ptr;
			}

			superGraph.erase(superGraph_it);

			superGraph_it = superGraph.find(superLink_second->second.destNode);
			superGraph_it->second.predecessors.erase(superLink_second->first);
			superGraph_it->second.predecessors.insert(superLink_first->first);


			superLink_first->second.links.splice(superLink_first->second.links.end(), superLink_second->second.links);
			superLink_first->second.destNode = superLink_second->second.destNode;

			superLinks.erase(superLink_second);
		}
	}

	bool Map::areMirrored(LinkKey first, LinkKey second)
	{
		if (first == INVALID_LINK || second == INVALID_LINK)
			return false;

		std::map<LinkKey, mLink>::iterator it1 = links.find(first);
		std::map<LinkKey, mLink>::iterator it2 = links.find(second);

		if (it1 == links.end() || it2 == links.end())
			return false;

		return (it1->second.orID == it2->second.destID && it1->second.destID == it2->second.orID);
	}

	bool Map::isConnected(int first, int second)
	{
		if (first == INVALID_LINK || second == INVALID_LINK)
			return false;

		std::map<LinkKey, mLink>::iterator it1 = links.find(first);
		std::map<LinkKey, mLink>::iterator it2 = links.find(second);

		if (it1 == links.end() || it2 == links.end())
			return false;

		return (it1->second.destID == it2->second.orID);
	}

	bool Map::belongSameSuperLink(LinkKey first, LinkKey second)
	{
		if (first == INVALID_LINK || second == INVALID_LINK)
			return false;

		std::map<LinkKey, mLink>::iterator it1 = links.find(first);
		std::map<LinkKey, mLink>::iterator it2 = links.find(second);

		if (it1 == links.end() || it2 == links.end())
			return false;

		return (it1->second.superLink == it2->second.superLink);
	}

	std::vector<LinkKey> Map::getLinksBetween(LinkKey from, LinkKey dest)
	{
		std::vector<LinkKey> res, temp;
		std::queue<std::vector<LinkKey> > stack;
		std::set<int>::iterator it;
		bool exit = false;

		if (from == dest || isConnected(from, dest))
			return res;		

		stack.push(std::vector<LinkKey>(1, from));

		while (!stack.empty() && !exit)
		{
			temp = stack.front();
			stack.pop();

			for (it = graph[links[temp.back()].destID].successors.begin(); it != graph[links[temp.back()].destID].successors.end(); it++)
			{
				if (*it != dest)
				{
					std::vector<LinkKey> newPath = temp;
					newPath.push_back(*it);
					stack.push(newPath);
				}
				else
				{
					if (temp.front() == from)
						temp.erase(temp.begin());

						res = temp;
						exit = true;
						break;
				}
			}
		}

		return res;
	}

	std::pair<bool, std::vector<int> > Map::isAchievableWithoutAmbiguity(int from, int to, int skipLinks)
	{
		int curLink = from;
		int skipedLinks = 0;
		bool res = false;
		std::vector<int> linksSkiped;
		std::set<int> * temp;

		if (from == to)
			res = true;

		while (skipedLinks <= skipLinks && !res)
		{
			//temp = &graph[links[curLink].dest];
			temp = &graph[links[curLink].destID].successors;

			if (temp->size() == 1)
			{
				curLink = *temp->begin();

				if (curLink == to)
					res = true;
				else
					linksSkiped.push_back(curLink);

				skipedLinks++;
			}
			else
				break;
		}

		if (!res)
			linksSkiped.clear();

		return std::pair<bool, vector<int> >(res, linksSkiped);
	}

	std::pair<bool, std::vector<int> > Map::isAchievableWithAmbiguity(int from, int to, int skipLinks)
	{
		std::queue<vector<int> > stack;
		std::vector<int> temp;
		std::set<int>::iterator it;
		bool res = false;

		if (from == to)
			return std::pair<bool, vector<int> >(true, vector<int>());

		//for (it = graph[links[from].dest].begin(); it != graph[links[from].dest].end() && !res; it++)
		for (it = graph[links[from].destID].successors.begin(); it != graph[links[from].destID].successors.end() && !res; it++)
		{
			if (*it == to)
				res = true;
			else
				stack.push(std::vector<int>(1, *it));
		}

		if (res)
			return std::pair<bool, vector<int> >(true, vector<int>());

		while (!stack.empty() && !res)
		{
			temp = stack.front();
			stack.pop();

			//for (it = graph[links[temp.back()].dest].begin(); it != graph[links[temp.back()].dest].end(); it++)
			for (it = graph[links[temp.back()].destID].successors.begin(); it != graph[links[temp.back()].destID].successors.end(); it++)
			{
				if (*it == to && temp.size() <= skipLinks)
					return pair<bool, vector<int> >(true, temp);
				else if (temp.size() < skipLinks)
				{
					std::vector<int> npath(temp);
					npath.push_back(*it);
					stack.push(npath);
				}
			}
		}

		return std::pair<bool, std::vector<int> >(false, std::vector<int>());
	}

	std::set<int> Map::getAllAchievableLinks(int from, int depth)
	{
		std::set<int> lin;
		std::pair<int, int> temp;
		std::queue<pair<int, int> > stack;
		std::set<int>::iterator it;

		if (depth <= 0)
			return lin;

		stack.push(pair<int, int>(from, 0));

		while (!stack.empty())
		{
			temp = stack.front();
			stack.pop();

			for (it = graph[links[temp.first].destID].successors.begin(); it != graph[links[temp.first].destID].successors.end(); it++)
			{
				lin.insert(*it);

				if (temp.second < depth-1)
					stack.push(pair<int, int>(*it, temp.second+1));
			}
		}

		return lin;
	}

	std::set<int> Map::getAllFormerLinks(int from, int depth)
	{
		std::set<int> lin;
		std::pair<int, int> temp;
		std::queue<pair<int, int> > stack;
		std::set<int>::iterator it;

		if (depth <= 0)
			return lin;

		stack.push(pair<int, int>(from, 0));

		while (!stack.empty())
		{
			temp = stack.front();
			stack.pop();

			for (it = graph[links[temp.first].orID].predecessors.begin(); it != graph[links[temp.first].orID].predecessors.end(); it++)
			{
				lin.insert(*it);

				if (temp.second < depth-1)
					stack.push(pair<int, int>(*it, temp.second+1));
			}
		}

		return lin;
	}

	
	std::vector<int> Map::getLinksUntilNextJunction(int link, int maxDepth)
	{
		int depth = 0;
		int tLink = link;
		std::vector<int> path;
		std::set<int> temp;

		while (depth < maxDepth)
		{
			temp = graph[links[tLink].destID].successors;

			if (temp.size() != 1)
				break;

			tLink = *temp.begin();
			path.push_back(tLink);
			depth++;
		}

		return path;
	}
		
	std::vector<int> Map::getLinksUntilPreviousJunction(int link, int maxDepth)	
	{
		int depth = 0;
		int tLink = link;
		std::vector<int> path;
		std::set<int> temp;

		while (depth < maxDepth)
		{
			temp = graph[links[tLink].orID].predecessors;

			if (temp.size() != 1)
				break;

			tLink = *temp.begin();
			path.push_back(tLink);
			depth++;
		}

		return path;
	}
	
	std::set<SuperLinkKey> Map::getAllAchievableSuperLinks(SuperLinkKey from, int depth, int lengthIntermediateSuperLinks)
	{
		std::set<SuperLinkKey> lin;
		std::pair<SuperLinkKey, int> temp;
		std::queue<pair<SuperLinkKey, int> > stack;
		std::set<SuperLinkKey>::iterator it;

		if (depth <= 0)
			return lin;

		stack.push(pair<SuperLinkKey, int>(from, 0));

		while (!stack.empty())
		{
			temp = stack.front();
			stack.pop();

			for (it = superGraph[superLinks[temp.first].destNode].successors.begin(); it != superGraph[superLinks[temp.first].destNode].successors.end(); it++)
			{
				lin.insert(*it);

				if (temp.second < depth-1 &&  superLinks[*it].links.size() <= lengthIntermediateSuperLinks)
					stack.push(pair<SuperLinkKey, int>(*it, temp.second+1));
			}
		}

		return lin;
	}

	vector<unsigned int> Map::getNearestPoints(double latitude, double longitude, double maxDistance)
	{
		int i;
		vector<pair<unsigned int, double> > ppoints = getNearestPointsAndDistances(latitude, longitude, maxDistance);
		vector<unsigned int> points(ppoints.size());

		for (i=0; i<ppoints.size(); i++)
			points[i] = ppoints[i].first;

		return points;
	}

	vector<pair<unsigned int, double> > Map::getNearestPointsAndDistances(double latitude, double longitude, double maxDistance)
	{
		return qtree->findPointsLessThan(latitude, longitude, maxDistance);
	}

	vector<int> Map::getNearestLinks(double latitude, double longitude, double maxDistance)
	{
		int i;
		vector<pair<int, double> > plinks = getNearestLinksAndDistances(latitude, longitude, maxDistance);
		vector<int> nlinks(plinks.size());

		for (i=0; i<plinks.size(); i++)
			nlinks[i] = plinks[i].first;

		return nlinks;
	}

	vector<pair<int, double> > Map::getNearestLinksAndDistances(double latitude, double longitude, double maxDistance)
	{
		int i;
		mEdges edges;
		mLink link;
		vector<pair<unsigned int, double> > points = qtree->findPointsLessThan(latitude, longitude, 10*maxDistance);
		vector<pair<int, double> > closeLinks;
		std::pair<Point, double> res;
		set<int> connectedLinks;
		set<int>::iterator it;

		for (i=0; i<points.size(); i++)
		{
			edges = getEdges(points[i].first);

			connectedLinks.insert(edges.successors.begin(), edges.successors.end());
			connectedLinks.insert(edges.predecessors.begin(), edges.predecessors.end());
		}

		GPSPoint ptm(GPSPoint::convertWGS84ToUTM(latitude, longitude));
		Point point(ptm.longm, ptm.latm);

		for (it = connectedLinks.begin(); it != connectedLinks.end(); it++)
		{
			link = getLink(*it);

			res = getNearestPointFromLink(getNodePoint(link.orID), getNodePoint(link.destID), point);

			if (res.second <= maxDistance)
				closeLinks.push_back(pair<int, double>(*it, res.second));
		}

		return closeLinks;	
	}

	Point Map::getNodePoint(unsigned int node)
	{
		mNode temp = getNode(node);

		return Point(temp.longm, temp.latm);
	}
	position Map::getNodePosition(unsigned int node)
	{
		mNode temp = getNode(node);

		return position(temp.latitude, temp.longitude);	
	}

	void Map::validateMap()
	{
		bool error = false;
		std::cout << "Validating map..." << std::endl;

		std::cout << "Nodes: " << nodes.size() << "  graph: " << graph.size() << "  super-nodes: " << superGraph.size() << std::endl;

		int count = 0;
		std::map<NodeKey, mEdges>::iterator graph_it;
		std::map<NodeKey, mSuperEdges>::iterator superGraph_it;

		for (graph_it = graph.begin(); graph_it != graph.end(); graph_it++)
		{
			superGraph_it = superGraph.find(graph_it->first);

			if (graph_it->second.predecessors.size() == 1 && graph_it->second.successors.size() == 1)
			{
				if (superGraph_it != superGraph.end())
					std::cout << "This node " << graph_it->first << " shouldn't be a super-node." << std::endl, error = true;
			}
			else
			{
				if (superGraph_it != superGraph.end())
					count++;
			}
		}

		if (count != superGraph.size())
			std::cout << "Both layers are inconsistent." << std::endl, error = true;

		std::map<LinkKey, mLink>::iterator link_it;
		std::map<SuperLinkKey, mSuperLink>::iterator superLink_it;

		for (link_it = links.begin(); link_it != links.end(); link_it++)
		{
			superLink_it = superLinks.find(link_it->second.superLink);

			if (superLink_it == superLinks.end())
				std::cout << "Super-Link " << link_it->second.superLink << " not found." << std::endl, error = true;
		}

		if (error)
			std::cout << "ERROR: Validating map." << std::endl;
	}

	void Map::showGraph()
	{
		/*map<string, set<destID, compareDestID> >::iterator graph_it;
		set<destID, compareDestID> * ptr;
		set<destID, compareDestID>::iterator it;

		std::cout << std::endl << "The Graph" << std::endl;

		for (graph_it = graph.begin(); graph_it != graph.end(); graph_it++)
		{
		ptr = &graph_it->second;

		for (it = ptr->begin(); it != ptr->end(); it++)
		std::cout << graph_it->first << "  -->  " << it->dest << std::endl;
		}*/

		map<unsigned int, mNode>::iterator nit;
		map<unsigned int, mEdges>::iterator eit;
		map<int, mLink>::iterator lit;
		set<int>::iterator sit;

		std::cout << endl << endl << "Node's Location : " << nodes.size() << endl;

		for (nit = nodes.begin(); nit != nodes.end(); nit++)
			cout << "ID: " << nit->first << "   Lat: " << nit->second.latitude << "  Lon: " << nit->second.longitude << endl;

		cout << endl << "Graph connections: " << graph.size() << endl;

		for (eit = graph.begin(); eit != graph.end(); eit++)
		{
			cout << "ID: " << eit->first << "  Forward links: ";

			for (sit = eit->second.successors.begin(); sit != eit->second.successors.end(); sit++)
				cout << *sit << " ";

			cout << " Backward links: ";

			for (sit = eit->second.predecessors.begin(); sit != eit->second.predecessors.end(); sit++)
				cout << *sit << " ";

			cout << endl;
		}

		cout << endl << "Link information: " << links.size() << endl;

		for (lit = links.begin(); lit != links.end(); lit++)
			std::cout << "ID: " << lit->first << "  Or: " << lit->second.orID << "  Dest: " << lit->second.destID << std::endl;

		std::cout << std::endl << std::endl;
	}

	void Map::mapInfo()
	{
		cout << qtree->getQuadTreeStatistics();

		/*std::string s = qtree->getQuadTreeKML();

		std::ofstream fout("data/QuadTree.kml", std::ios::out);
		fout << s;
		fout.close();*/
	}
}
