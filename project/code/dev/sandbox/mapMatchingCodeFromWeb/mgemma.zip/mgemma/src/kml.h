#ifndef __KML_H__
#define __KML_H__


#include "maps.h"
#include "route.h"
#include <fstream>
#include <vector>
#include <list>


namespace kmlMatch {

	class KMLBuilder
	{
	public:
		KMLBuilder(mapRepresentation::Map * m, const std::string& filename);
		KMLBuilder(mapRepresentation::Map * m, Route * r, const std::vector<int>& match, const std::vector<pair<int, int> >& segments, const string& partialName);
		KMLBuilder(Route * r, vector<Route> * vecRoute, const std::string& filename);
		KMLBuilder(const KMLBuilder& k);
		const KMLBuilder& operator=(const KMLBuilder& k);

		void buildKML();

	private:
		mapRepresentation::Map * map;
		Route * route;
		string partialName;
		std::vector<int> match;
		std::vector<pair<int, int> > segments;


		KMLBuilder();

		void buildMap(std::ofstream& fout);
		void buildLightMap(std::ofstream& fout);
		void buildTrace(std::ofstream& fout);
		void buildMatched(std::ofstream& fout);
		void buildUnmatched(std::ofstream& fout);
		void buildSegments(std::ofstream& fout);

		std::string builLinkInfo(int linkID);
		std::set<int> getLinksToDraw();
		std::vector<int> navigateForward(int link);
		std::vector<int> navigateBackward(int link);
		std::vector<int> selectLinksFromPath(const std::vector<int>& path);
	};
}

#endif // __KML_H__
