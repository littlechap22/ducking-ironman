#ifndef __GEOMETRY_H__
#define __GEOMETRY_H__


#include <iostream>
#include <cmath>


#define PI (acos(-1.0))


class Point
{
public:
	Point();
	Point(double x, double y);
	Point(const Point& p);
	const Point& operator=(const Point& p);
	const Point& operator+(const Point& p);
	const Point& operator-(const Point& p);

	inline double getX() const {return x;}
	inline double getY() const {return y;}

	inline void setX(double p) {x = p;}
	inline void setY(double p) {y = p;}

private:
	double x;
	double y;
};


class Vector
{
public:
	Vector();
	Vector(double x, double y);
	Vector(double xA, double yA, double xB, double yB);
	Vector(const Vector& v);
	const Vector& operator= (const Vector& v);

	inline double getX() const {return x;}
	inline double getY() const {return y;}

	double dotProduct(const Vector& v);
	double norm();
	double getAngle(Vector v);
	double getDegreeAngle(Vector v);

private:
	double x;
	double y;
};

double distance2Points(double x1, double y1, double x2, double y2);
double distance2Points(const Point& a, const Point& b);

std::pair<bool, Point> getPointProjection(const Point& pA, const Point& pB, const Point& pT);
std::pair<Point, double> getNearestPointFromLink(const Point& pA, const Point& pB, const Point& pT);

double calcHeading(Point start, Point end);

double diffRadHeading(double head1, double head2);

double deg2rad(double degree);
double rad2deg(double radian);

#endif // __GEOMETRY_H__
