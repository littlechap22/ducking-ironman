#ifndef __GPSPOINT_H__
#define __GPSPOINT_H__

#include <cmath>
#include <string>

#define _PI_ (4.0*atan(1.0))

/* Class created with source code from http://www.chineselinuxuniversity.net/articles/5800.shtml */

/*//	Lat Lon to UTM variables

// equatorial radius
const double equatorialRadius = 6378137;

// polar radius
const double polarRadius = 6356752.314;

// flattening
const double flattening = 0.00335281066474748; // (equatorialRadius-polarRadius)/equatorialRadius;

// inverse flattening 1/flattening
const double inverseFlattening = 298.257223563; // 1/flattening;

// Mean radius
const double rm = pow(equatorialRadius * polarRadius, 1 / 2.0);

// scale factor
const double k0 = 0.9996;

// eccentricity
const double e = sqrt(1 - pow(polarRadius / equatorialRadius, 2));

const double e1sq = e * e / (1 - e * e);

const double n = (equatorialRadius - polarRadius)
/ (equatorialRadius + polarRadius);

// r curv 1
const double rho = 6368573.744;

// r curv 2
const double nu = 6389236.914;

// Calculate Meridional Arc Length
// Meridional Arc
const double S = 5103266.421;

const double A0 = 6367449.146;

const double B0 = 16038.42955;

const double C0 = 16.83261333;

const double D0 = 0.021984404;

const double E0 = 0.000312705;

// Calculation Constants
// Delta Long
const double p = -0.483084;

const double sin1 = 4.84814E-06;

// Coefficients for UTM Coordinates
const double K1 = 5101225.115;

const double K2 = 3750.291596;

const double K3 = 1.397608151;

const double K4 = 214839.3105;

const double K5 = -2.995382942;

const double A6 = -1.00541E-07;*/


class GPSPoint
{
public:
	double lat, lon, latm, longm, elev, speed;
	long long time;
	std::string date;
	bool valid;
	double azimuth;
	long duration;
	int zone;
	char latZone;
	std::string placeDescription;


	GPSPoint();
	GPSPoint(double lat, double lon, double latm, double longm, double elev, double speed, long long time, std::string date, double azimuth, int zone, char latZone);
	GPSPoint(const GPSPoint& g);

	static GPSPoint convertWGS84ToUTM(double latitude, double longitude);
	static GPSPoint convertUTMToWGS84(double easting, double northing, int zone, char latZone);
	static char getHemisphere(char latZone);

	static char getLatZone(double latitude);
	static int getZone(double longitude);
	double degreeToRadian(double degree);
	double radianToDegree(double radian);

protected:
	double getEasting();
	double getNorthing(double latitude);
	void setVariablesWGS(double latitude, double longitude);
	void setVariablesUTM(double easting, double northing);

private:
	//UTM to LAT LON variables
	double arc,mu,ei,ca,cb,cc,cd,n0,r0,_a1,dd0,t0,Q0,lof1,lof2,lof3,_a2,phi1,fact1,fact2,fact3,fact4,zoneCM;
	double _a3,b,a;

	//	Lat Lon to UTM variables
	// equatorial radius
	double equatorialRadius;

	// polar radius
	double polarRadius;

	// flattening
	double flattening; // (equatorialRadius-polarRadius)/equatorialRadius;

	// inverse flattening 1/flattening
	double inverseFlattening;

	// Mean radius
	double rm;

	// scale factor
	double k0;

	// eccentricity
	double e;
	double e1sq;
	double n;
	// r curv 1
	double rho;
	// r curv 2
	double nu;

	// Calculate Meridional Arc Length
	// Meridional Arc
	double S;
	double A0;
	double B0;
	double C0;
	double D0;
	double E0;

	// Calculation Constants
	// Delta Long
	double p;
	double sin1;

	// Coefficients for UTM Coordinates
	double K1;
	double K2;
	double K3;
	double K4;
	double K5;
	double A6;
};

class LatZones
{
public:
	LatZones();

	int getLatZoneDegree(std::string letter);
	char getLatZone(double latitude);

private:
	char letters[22];
	int degrees[22];
	char negLetters[11];
	int negDegrees[11];
	char posLetters[11];
	int posDegrees[11];
	int arrayLength;

	/*char letters [] = {'A', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L',
	'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Z'};

	int degrees[] = { -90, -84, -72, -64, -56, -48, -40, -32, -24, -16,
	-8, 0, 8, 16, 24, 32, 40, 48, 56, 64, 72, 84 };

	char negLetters[] = { 'A', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K',
	'L', 'M' };

	int negDegrees[] = { -90, -84, -72, -64, -56, -48, -40, -32, -24,
	-16, -8 };

	char posLetters[] = { 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W',
	'X', 'Z' };

	int posDegrees[] = { 0, 8, 16, 24, 32, 40, 48, 56, 64, 72, 84 };

	int arrayLength = 22;*/
};

#endif // __GPSPOINT_H__
