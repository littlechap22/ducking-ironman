#ifndef __MATCHING_MARCHAL_H__
#define __MATCHING_MARCHAL_H__

#include "util.h"
#include "maps.h"
#include "route.h"
#include "path.h"
#include <set>
#include <sstream>


namespace MapMatching {

#define N 35
#define INITIAL_MIN_DISTANCE 20.0
#define DIF_MIN_SCORE 20.0
#define MATCH_TOLERANCE_LINKS 3
#define DELTA_HEADING 110.0
#define MAX_ACCEPTABLE_SCORE 45.0

	typedef int routePoint;

	class MarPath {

	public:
		MarPath();
		MarPath(const std::pair<routePoint, mapRepresentation::LinkKey>& m);
		MarPath(const MarPath &p);
		const MarPath& operator=(const MarPath &p);
		//inline bool operator<(const MarPath& p) const {return avgScore < p.avgScore;}
		inline bool operator<(const MarPath& p) const {return (fabs(avgScore - p.avgScore) < 0.000001) ? path.size() < p.path.size() : avgScore < p.avgScore;}


		void addLinkCandidate(const std::pair<routePoint, mapRepresentation::LinkKey>& c);
		void updateScore(double s);
		int countDistinctMatchedLinks() const;
		MarPath reversedPath();
		void printPath() const;


		std::vector<std::pair<routePoint, mapRepresentation::LinkKey> > path;
		int countTracePoints;
		double score;
		double lastScore;
		double avgScore;
	};

	class MarchalBMatching {

	public:
		MarchalBMatching(mapRepresentation::Map * map, Route * route);
		~MarchalBMatching();

		void run(bool forwardMatching=true, bool generateKML=false);

		vector<Path *> getMatched();
		vector<Path *> getShortMatched();
		vector<unMatchInfo *> getUnmatchedInfo();
		inline vector<std::set<int> > getCandidates() const {return candidates;}


	private:
		MarchalBMatching();
		MarchalBMatching(const MarchalBMatching& m);
		const MarchalBMatching& operator=(const MarchalBMatching& m);

		mapRepresentation::Map * map;
		Route * route;
		bool matchingForwards;
		int routePtr;

		std::multiset<MarPath> paths;
		std::vector<std::set<mapRepresentation::LinkKey> > candidates;
		std::vector<MarPath> finalPaths;
		std::vector<Path *> matchedTraces;
		std::vector<Path *> shortMatchedTraces;
		std::vector<unMatchInfo *> unmatchInfo;


		inline int reversedRouteIndex(int n) {return (int)route->size() - n - 1;}
		void findNearestLinks();
		void continueMatching();
		double score(int linkID, const Point &pos, double distance);
		void addNewPaths(std::multiset<MarPath>& s, const MarPath& p, int maxDepth);
		std::multiset<MarPath> filterCandidates(std::multiset<MarPath>& paths);
		void saveBestPaths(multiset<MarPath>& s);
		void prepateOutput();
		Path getPath(const MarPath& p, bool unmatchedLinks=true);		
		void generateMatchKML();
		void showPaths(std::multiset<MarPath>& paths);
	};
}

#endif // __MATCHING_MARCHAL_H__
