#ifndef __MATCHING_GENETIC_UTIL_H__
#define __MATCHING_GENETIC_UTIL_H__

#include <ctime>
#include <sstream>
#include <fstream>
#include "maps.h"
#include "route.h"


namespace MapMatching {

#define MAX_DIST_LINK 20.0

#define MAX_DELTA_HEADING 45.0
#define DELTA_HEADING_POINT_RADIO 3

	typedef struct _params {
		double D_LIMIT;
		double PROB_INVALID_LINK;
		int POP_SIZE;
		double DIRECT_PASS;
		int BEST_INDIVIDUAL_MATURITY;

		int TOLERANCE_LINKS;
		int TOLERANCE_SUPER_LINKS;

		double RECOMBINATION_PROB;
		double MUTATION_PROB;
		double TOURNAMENT_PROB_BEST_INDIVIDUAL;

		double W_AVG;
		double W_MAX;
		double W_MAX_MIN; 
		double W_UNCOV;
		double W_GAP;
		double W_CONTLEN;
		double W_AVGDISC;
		double W_MAXDISC;
	} geneticParameters;


	class Distances
	{
	public:
		Distances();
		Distances(mapRepresentation::Map * m, Route * r, vector<set<int> > * forwardPossibleLinks, vector<set<int> > * backwardPossibleLinks, std::ofstream * outputLog);
		Distances(mapRepresentation::Map * m, Route * r, std::vector<std::set<mapRepresentation::LinkKey> > * candidates, const std::set<int>& fixedGenes, std::ofstream * outputLog);
		~Distances();
		const Distances& operator=(const Distances& d);

		inline double getTraceDistance(int startPoint, int endPoint) const {return cumulativeTraceDists[endPoint] - cumulativeTraceDists[startPoint];}
		inline double getTraceTotalDistance() const {return cumulativeTraceDists.back();}
		vector<int> getValidLinks(int point) const;
		inline bool hasDistanceFromPointToLink(int point, int link) const {return dists[point]->find(link) != dists[point]->end();}
		double getDistanceFromPointToLink(int point, int link);
		inline int totalNearestLinks(int point) const {return dists[point]->size();}
		inline bool hasNearestLink(int point) const {return !dists[point]->empty();}	
		int getNearestLink(int point);
		double getDistanceBetweenLinks(int first, int second);
		double getMinHeading(int point) const {return minHeading[point];}
		double getMaxHeading(int point) const {return maxHeading[point];}


		void printTraceDistances();
		void printLinkDistances();
		void printDistances();


	private:
		mapRepresentation::Map * map;
		Route * route;
		std::ofstream * out;
		vector<double> cumulativeTraceDists;
		vector<std::map<int, double> *> dists;
		std::map<string, double> distLinks;
		vector<double> minHeading;
		vector<double> maxHeading;


		void calculateHeadingIntervals();
		void calculateTraceLinkDistances();
		void calculateNearLinkDistances(vector<set<int> > * forwardPossibleLinks, vector<set<int> > * backwardPossibleLinks);
		void calculateNearLinkDistances(vector<set<mapRepresentation::LinkKey> > * candidates, const std::set<int>& fixedGenes);
		void filterCandidatesByHeading(vector<vector<pair<mapRepresentation::LinkKey, double> > >& candidates, const std::set<int>& fixedGenes);
		void filterCandidatesBySuperLink(const vector<vector<pair<mapRepresentation::LinkKey, double> > >& candidates, const std::set<int>& fixedGenes);
	};

	class Individual
	{
	public:
		Individual(int n = 0);
		~Individual();
		Individual(const Individual& i);
		const Individual& operator=(const Individual& i);

		inline int getGene(int pos) const {return chromo[pos];}
		inline int getSize() const {return size;}
		inline double getAvgDistance() const {return avgDist;}
		inline double getMaxMinDistance() const {return maxMinDist;}
		inline double getMaxDistance() const {return maxDist;}
		inline double getUncoveredDistance() const {return uncoveredDist;}
		inline double getGapDistance() const {return gapDist;}
		inline double getContinuityLength() const {return continuityLength;}
		inline double getSmallsDistance() const {return smallsDist;}
		inline double getInfDistance() const {return infDist;}
		inline double getAvgDiscDistance() const {return avgDisc;}
		inline double getMaxDiscDistance() const {return maxDisc;}
		inline double getScore() const {return score;}
		inline double getInvScore() const {return invScore;}

		inline void setGene(int pos, int value) {chromo[pos] = value;}
		inline void setAvgDistance(double dist) {avgDist = dist;}
		inline void setMaxMinDistance(double dist) {maxMinDist = dist;}
		inline void setMaxDistance(double dist) {maxDist = dist;}
		inline void setUncoveredDistance(double dist) {uncoveredDist = dist;}
		inline void setGapDistance(double dist) {gapDist = dist;}
		inline void setContinuityLength(double length) {continuityLength = length;}
		inline void setSmallsDistance(double dist) {smallsDist = dist;}
		inline void setInfDistance(double dist) {infDist = dist;}
		inline void setAvgDiscDistance(double dist) {avgDisc = dist;}
		inline void setMaxDiscDistance(double dist) {maxDisc = dist;}
		inline void setScore(double value) {score = value;}
		inline void setInvScore(double value) {invScore = value;}

		inline void addToUncoveredDistance(double dist) {uncoveredDist += dist;}
		inline void addToGapDistance(double dist) {gapDist += dist;}
		inline void addToContinuityLength(double length) {continuityLength += length;}
		inline void addToSmallsDistance(double dist) {smallsDist += dist;}
		inline void addToInfDistance(double dist) {infDist += dist;}

		std::string toString();

	private:
		int * chromo;
		int size;
		double avgDist;
		double maxMinDist;
		double maxDist;
		double uncoveredDist;
		double gapDist;
		double continuityLength;
		double smallsDist;
		double infDist;
		double avgDisc;
		double maxDisc;
		double score;
		double invScore;
	};

	template <typename T>
	class Selection
	{
	public:
		virtual Selection<T> * newObject() const =0;
		virtual T getSelected() =0;
		virtual std::string toString() =0;
	};

	template <typename T>
	class RouletteWheelNode
	{
	public:
		RouletteWheelNode(double v, T o) {val = v; obj = o;}

		inline double getValue() const {return val;}
		inline T getObject() const {return obj;}

		bool operator< (const RouletteWheelNode<T>& r1) const {
			return ((val < r1.val) || (fabs(val-r1.val) < 0.00000001));
		}

	private:
		double val;
		T obj;
	};

	template <typename T>
	class RouletteWheel
		: public Selection<T>
	{
	public:
		RouletteWheel(std::vector<std::pair<double, T> > elems, double total);
		RouletteWheel(std::vector<std::pair<double, T> > elems);

		Selection<T> * newObject() const {return new RouletteWheel<T>(*this);}

		T getSelected();
		std::string toString();

	private:
		std::set<RouletteWheelNode<T> > r;
	};

	template <typename T>
	class Tournament
		: public Selection<T>
	{
	public:
		Tournament(std::vector<std::pair<double, T> > elems, double probBestIndividual, int levels=1)
		{elements = elems; this->probBestIndividual = probBestIndividual; tournamentSize = levels;}

		Selection<T> * newObject() const {return new Tournament<T>(*this);}

		T getSelected();
		std::string toString();

	private:
		int tournamentSize;
		double probBestIndividual;
		std::vector<std::pair<double, T> > elements;
	};


	class Population
	{
	public:
		Population();
		Population(mapRepresentation::Map * m, Route * r, Distances * d, geneticParameters * p, int routePtr, int indSize, std::ofstream * outputLog);
		~Population();
		Population(const Population& p);
		const Population& operator=(const Population& p);

		void initializePopulation(bool fixedGene=false, int gene=-1, int allele=INVALID_LINK);
		void initializePopulation(set<int>& fixedGenes);
		void crossOver();
		void mutation();
		void fitness(bool all);
		void nextGeneration();

		inline int getGeneration() const {return generation;}
		inline Individual getBestFromEver() const {return  bests[best_from_ever-1];}
		inline int getGenerationBestFromEver() const {return best_from_ever;}
		inline Individual getBestFromLastGeneration() const {return bests.back();}
		std::vector<int> getIndividualGaps(const Individual& ind);

		void printGeneration();
		void printGenerationStatistics();
		void printPopulationStatistics();
		void printBestIndividuals();

	private:
		mapRepresentation::Map * map;
		Route * route;
		Distances * dists;
		geneticParameters * params;
		std::ofstream * out;
		int popSize;
		int routePtr;
		int indSize;
		double segment_length;
		int direct_individuals;
		int generation;
		double total_scores;
		double inv_total_scores;
		int best_from_ever;
		double diff_scores;
		double max_diff;
		double min_diff;
		double best_diff;
		double worst_diff;
		std::vector<Individual> population;
		std::vector<Individual> newPopulation;
		std::vector<Selection<int> *> selection;
		std::vector<Individual> bests;
		std::map<mapRepresentation::SuperLinkKey, set<mapRepresentation::SuperLinkKey> > achiveableSuperLinks;

		bool isAchiveableLink(int orLink, int destLink);
	};


	struct compareScore {
		bool operator() (const Individual * ind1, const Individual * ind2) const {
			return ind1->getScore() < ind2->getScore();
		}
	};


	class RankedPopulation
	{
	public:
		RankedPopulation(vector<Individual> * pop);

		bool hasNext();
		Individual * next();

	private:
		multiset<Individual *, compareScore> rank;
		multiset<Individual *, compareScore>::iterator it;
	};
}

#endif // __MATCHING_GENETIC_UTIL_H__
