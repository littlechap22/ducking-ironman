#ifndef __MAIN_H__
#define __MAIN_H__

#include <iostream>
#include <sstream>
#include <vector>
#include <ctime>
#include "util.h"
#include "file_lister.h"
#include "NMEALoader.h"
#include "route.h"
#include "maps.h"
#include "path.h"
#include "MGEMMA.h"
#include "kml.h"


std::vector<std::string> traceFiles;
mapRepresentation::Map m;

bool marchalKML = false;
bool geneticKML = false;



void lookForTraceFiles(const std::string& folder);
void loadMap();
void run();

#endif // __MAIN_H__
