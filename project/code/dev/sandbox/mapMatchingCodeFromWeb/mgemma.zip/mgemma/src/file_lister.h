#ifndef __FILE_LISTER_H__
#define __FILE_LISTER_H__

#if defined(unix) || defined(__unix) || defined(__unix__) || defined (macintosh) || defined (__MACH__) || defined (__APPLE__)
#define FILE_LISTER_POSIX
#elif defined(_WIN32) || defined(_WIN64)
#define FILE_LISTER_WINDOWS
#else
#define FILE_LISTER_NOT_SUPPORTED
#endif

#include <vector>
#include <string>

std::vector<std::string> getFiles(const std::string& path);

#endif // __FILE_LISTER_H__
