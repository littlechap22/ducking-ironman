
#include "route.h"
#include "GPSPoint.h"
#include "geometry.h"
#include "util.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <ctime>
#include <cstdio>

#define ARROW_SCALE 0.5


Route::Route()
{

}

Route::Route(const vector<rNode>& nodes, string name, string originalFilename)
{
	this->route = nodes;
	this->originalFilename = originalFilename;
	this->name = name;
}

Route::Route(const Route &r)
{
	route = r.route;
	originalFilename = r.originalFilename;
	name = r.name;
}

const Route& Route::operator=(const Route &r)
{
	if (this != &r)
	{
		route = r.route;
		originalFilename = r.originalFilename;
		name = r.name;
	}

	return *this;
}

void Route::addNode(rNode node, bool calcMeasurements)
{
	//if true calc speed and heading, if not use readings from gps(in the node)
	if (calcMeasurements)
	{
		if (route.size() > 0)
		{
			double time = node.arrivalTime - route.back().leaveTime;

			if (time <= 0)
				time = 0.5;

			node.speed = distance2Points(node.lonm, node.latm, route.back().lonm, route.back().latm) / time;
			node.heading = calcHeading(Point(route.back().lonm, route.back().latm), Point(node.lonm, node.latm));
		}
		else
		{
			node.speed = 0;
			node.heading = 0;
		}

		if (route.size() == 1)
		{
			route.back().heading = node.heading;
			route.back().speed = node.speed;
		}
	}

	route.push_back(node);
}
Route Route::subRoute(int firstPoint, int lastPoint)
{
	Route sub;

	if (firstPoint < 0 || lastPoint >= (int)route.size() || lastPoint - firstPoint < 0)
		return sub;

	sub.originalFilename = this->originalFilename;
	sub.name = this->name;
	sub.route.assign(route.begin()+firstPoint, route.begin()+lastPoint+1);

	return sub;
}

void Route::merge(const Route& nRoute, bool ajustMeasurements)
{
	int lastPoint = (int)route.size()-1;

	if (nRoute.size() > 0)
	{
		route.insert(route.end(), nRoute.route.begin(), nRoute.route.end());

		if (ajustMeasurements)
		{
			route[lastPoint+1].speed = distance2Points(route[lastPoint].lonm, route[lastPoint].latm, route[lastPoint+1].lonm, route[lastPoint+1].latm) / 
				(1.0 * ((unsigned int)route[lastPoint+1].arrivalTime - route[lastPoint].leaveTime));
			route[lastPoint+1].heading = calcHeading(getPoint(lastPoint), getPoint(lastPoint+1));
		}
	}
}

Route Route::reversedRoute() const
{
	int i;
	Route rev;
	stringstream newName;
	std::vector<rNode> nodes;

	rev.originalFilename = originalFilename;
	newName << "reversed_" << name;
	rev.name = newName.str();

	for (i=(int)route.size()-1; i>=0; i--)
		nodes.push_back(route[i]);

	for (i=1; i<nodes.size(); i++)
	{
		nodes[i].heading = calcHeading(Point(nodes[i-1].lonm, nodes[i-1].latm), Point(nodes[i].lonm, nodes[i].latm));

		if (i == 1)
			nodes[0].heading = nodes[1].heading;
	}

	rev.route = nodes;

	return rev;
}

void Route::setOriginalFilename(const string& name, bool replaceName)
{
	originalFilename = name;

	if (replaceName)
	{
		if (name.size() == 0)
			setName(name);
		else
		{
			int begin = name.find_last_of("/\\");
			int end = name.find_last_of(".");

			if (begin == std::string::npos)
				begin = 0;
			else
				begin++;

			if (end == std::string::npos)
				end = (int)name.size();

			setName(name.substr(begin, end-begin));
		}
	}
}

double Route::getTotalLength() const
{
	int i;
	double sum = 0;

	for (i=0; i<(int)route.size()-1; i++)
		sum += distance2Points(route[i].lonm, route[i].latm, route[i+1].lonm, route[i+1].latm);

	return sum;
}

string Route::pointToKml(int n)
{
	stringstream streamKml;
	time_t aTime, lTime;

	aTime = (time_t) route[n].arrivalTime;
	lTime = (time_t) route[n].leaveTime;

	streamKml.setf(ios::fixed,ios::floatfield);
	streamKml.precision(9);

	streamKml << "<Placemark>" << endl;
	streamKml << "<description>" << n << "<br/>" << "lon,lat: " << route[n].lon << "," << route[n].lat << "<br/>"
		<< "xy: " << route[n].lonm << "," << route[n].latm << "<br/>";
	streamKml << "Heading: " << rad2deg(route[n].heading) << "<br/>"<<"Speed: " << route[n].speed << "m/s<br/>";
	streamKml << "HDOP: "<< route[n].dop << "<br/>Arrival Time: "<< ctime(&aTime) << "<br/>";
	streamKml << "Leave Time: " << ctime(&lTime) << "<br/>Validity: "
		<< route[n].validity << "<br/>AverageSNR: " << route[n].avgSnr << "<br/>";

	//for (unsigned int i = 0; i < route[n].usedSats.size(); i++)
	//{
	//	streamKml << "\tsat: " << route[n].usedSats[i].prn << " elev: " << route[n].usedSats[i].elev
	//		<< " azimuth: " << route[n].usedSats[i].azimuth << " snr: " << route[n].usedSats[i].snr << "<br/>";
	//}

	//for (unsigned int i = 0; i < route[n].usedSats.size(); i++)
	//{
	//	streamKml << "\tusedSat: "<< route[n].usedSats[i];
	//}

	streamKml << "</description><br/>" <<endl;
	streamKml << "<Style><IconStyle><Icon><href>http://maps.google.com/mapfiles/kml/shapes/arrow.png</href></Icon>";
	streamKml << "<scale>" << ARROW_SCALE << "</scale>" 
		<< "<heading>" << rad2deg(route[n].heading)+180 << "</heading></IconStyle></Style>" << endl;

	streamKml << "<LookAt>" << endl;
	streamKml << "<longitude>" << route[n].lon << "</longitude>" << endl;
	streamKml << "<latitude>" << route[n].lat << "</latitude>" << endl;
	streamKml << "<heading>" << rad2deg(route[n].heading) << "</heading>" << endl;
	streamKml << "<range>50.0</range>" << endl; // ??????????
	streamKml << "<tilt>0.0</tilt>" << endl;    // ??????????
	streamKml << "</LookAt>" << endl;
	streamKml << "<Point>" << endl;
	streamKml << "<coordinates>" << route[n].lon << "," << route[n].lat << ",0</coordinates>" << endl;
	streamKml << "</Point>" << endl;

	streamKml << "</Placemark>" << endl;

	return streamKml.str();
}


void Route::printRoute()
{
	vector<rNode>::iterator it;	

	cout.precision(9);
	cout.setf(ios::fixed,ios::floatfield);

	cout << endl << "### ROUTE with ### " << route.size() << " points." << endl;

	for (it = route.begin(); it != route.end(); it++)	
		cout << it->lat << "   " << it->lon << endl;

	cout << endl;
}
