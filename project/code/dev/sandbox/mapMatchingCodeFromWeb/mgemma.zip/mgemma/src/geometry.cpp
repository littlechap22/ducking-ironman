
#include "geometry.h"


Point::Point()
{
	x = 0;
	y = 0;
}

Point::Point(double x, double y)
{
	this->x = x;
	this->y = y;
}

Point::Point(const Point &p)
{
	x = p.x;
	y = p.y;
}

const Point& Point::operator =(const Point& p)
{
	if (this != &p)
	{
		x = p.x;
		y = p.y;
	}

	return *this;
}

const Point& Point::operator +(const Point& p)
{
	x += p.x;
	y += p.y;

	return *this;
}

const Point& Point::operator -(const Point& p)
{
	x -= p.x;
	y -= p.y;

	return *this;
}


Vector::Vector()
{
	x = 0; 	
	y = 0;
}

Vector::Vector(double x, double y)
{
	this->x = x;
	this->y = y;
}

Vector::Vector(double xA, double yA, double xB, double yB)
{
	x = xB - xA;
	y = yB - yA;
}

Vector::Vector(const Vector &v)
{
	x = v.x;
	y = v.y;
}

const Vector& Vector::operator =(const Vector &v)
{
	if (this != &v)
	{
		x = v.x;
		y = v.y;
	}

	return *this;
}

double Vector::dotProduct(const Vector &v)
{
	return x * v.x + y * v.y;
}

double Vector::norm()
{
	return sqrt(x*x + y*y);
}

double Vector::getAngle(Vector v)
{
	return acos(dotProduct(v) / (norm() * v.norm()));
}

double Vector::getDegreeAngle(Vector v)
{
	return getAngle(v) * ((double)180 / PI);
}


double distance2Points(double x1, double y1, double x2, double y2)
{
	Vector ab(x1, y1, x2, y2);

	return ab.norm();
}

double distance2Points(const Point& a, const Point& b)
{
	return distance2Points(a.getX(), a.getY(), b.getX(), b.getY());
}

std::pair<bool, Point> getPointProjection(const Point& pA, const Point& pB, const Point& pT)
{	
	double m, ml, b, bl, xI, yI;
	bool xIn = false, yIn = false;

	if (fabs(pB.getX() - pA.getX()) < 1e-12) //recta vertical
	{
		xI = pA.getX();
		yI = pT.getY();
	}
	else if (fabs(pB.getY() - pA.getY()) < 1e-12) //recta horizontal
	{
		yI = pA.getY();
		xI = pT.getX();
	}
	else	//restantes casos (e normais)
	{
		m = (pB.getY() - pA.getY()) / (pB.getX() - pA.getX());
		ml = (double) -1.0 / m;

		b = pA.getY() - m * pA.getX();
		bl = pT.getY() - ml * pT.getX();

		xI = (bl - b) / (m - ml);
		yI = m * xI + b;
	}


	if (pB.getY() > pA.getY())
	{
		if (yI >= pA.getY() && yI <= pB.getY())
			yIn = true;
	}
	else
	{
		if (yI >= pB.getY() && yI <= pA.getY())
			yIn = true;
	}

	if (pB.getX() > pA.getX())
	{
		if (xI >= pA.getX() && xI <= pB.getX())
			xIn = true;
	}
	else
	{
		if (xI >= pB.getX() && xI <= pA.getX())
			xIn = true;
	}

	//if (xIn && yIn)
	//	return std::pair<bool, Point>(true, Point(xI, yI));
	//else
	//	return std::pair<bool, Point>(false, Point());

	//para ja da-me jeito ser assim (NUNO)
	return std::pair<bool,Point>(xIn && yIn,Point(xI, yI));
}

std::pair<Point, double> getNearestPointFromLink(const Point& pA, const Point& pB, const Point& pT)
{
	double dist, a, b;
	std::pair<bool, Point> res;

	res = getPointProjection(pA, pB, pT);

	if (res.first)
	{
		dist = distance2Points(pT, res.second);

		return std::pair<Point, double>(res.second, dist);
	}
	else
	{
		a = distance2Points(pT, pA);
		b = distance2Points(pT, pB);

		if (a < b)
			return std::pair<Point, double>(pA, a);
		else
			return std::pair<Point, double>(pB, b);
	}
}

double calcHeading(Point start, Point end)
{
	/*double head;
	double difLat = end.getY() - start.getY();
	double difLon = end.getX() - start.getX();

	if (difLat != 0)
	{
        head = atan(difLon/difLat);

        if (difLat < 0)
			head = head + PI;
	}
	else
	{
        if (difLon > 0)
            head = PI / 2;
        else
		{
            if (difLon < 0)
                head = 3 * (PI /2);
            else
                head = 0;
		}
	}

	return head;*/

	double heading;
	Vector a(0, 1), b(end.getX()-start.getX(), end.getY()-start.getY()), c(-1, 0);

	heading = a.getAngle(b);

	if (b.dotProduct(c) > 0)
		heading = (2*PI) - heading;

	return heading;
}

double diffRadHeading(double head1, double head2)
{
	double diff;

	if (head1 > head2)
		diff = head1 - head2;
	else
		diff = head2 - head1;

	if (diff >= PI)
		diff = 2.0*PI - diff;

	return diff;
}

double deg2rad(double degree)
{
	return degree * ((double)PI / 180);
}

double rad2deg(double radian)
{
	return radian * ((double)180.0 / PI);
}
