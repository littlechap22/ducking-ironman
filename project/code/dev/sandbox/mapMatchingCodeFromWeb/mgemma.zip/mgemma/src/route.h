#ifndef __ROUTE_H__
#define __ROUTE_H__


#include "geometry.h"
#include "util.h"
#include <map>
#include <vector>
#include <cmath>

using namespace std;

typedef struct _node {
	unsigned int arrivalTime;
	unsigned int leaveTime; 
	double lat, lon;
	double latm, lonm;
	double heading;
	double speed;
	double dop;
	double avgSnr;
	bool validity;
	//vector<satInfo> usedSats;

	_node()
	{
		arrivalTime = 0;
		leaveTime = 0;
		lat = lon = 0;
		latm = lonm = 0;
		heading = 0;
		speed = 0;
		dop = 0;
		avgSnr = 0;
	}
} rNode;

inline double getLatSpeed(rNode n) { return n.speed * cos(n.heading);}
inline double getLonSpeed(rNode n) { return n.speed * sin(n.heading);}

class Route
{
public:
	Route();
	Route(const vector<rNode>& nodes, string name="", string originalFilename="");
	Route(const Route &r);
	const Route& operator=(const Route &r);


	void addNode(rNode, bool calcMeasurements=true);
	Route subRoute(int firstPoint, int lastPoint);
	void merge(const Route& nRoute, bool ajustMeasurements=true);
	Route reversedRoute() const;

	inline void setRoute(const vector<rNode>& nroute) {route = nroute;}
	void setOriginalFilename(const string& name, bool replaceName=true);
	inline void setName(const string& newName) {name = newName;}

	inline unsigned int size() const {return route.size();}

	inline rNode getNode(int n) const {return route[n];}
	inline unsigned int getArrivalTime(int n) const {return route[n].arrivalTime;}
	inline unsigned int getLeaveTime(int n) const {return route[n].leaveTime;}
	inline double getLatitude(int n) const {return route[n].lat;}
	inline double getLongitude(int n) const {return route[n].lon;}
	inline double getLatitudeM(int n) const {return route[n].latm;}
	inline double getLongitudeM(int n) const {return route[n].lonm;}
	inline position getPosition(int n) const {return position(route[n].lat, route[n].lon);}
	inline Point getPoint(int n) const {return Point(route[n].lonm, route[n].latm);}
	inline double getHeading(int n) const {return route[n].heading;}
	inline double getSpeed(int n) const {return route[n].speed;}
	inline double getDop(int n) const {return route[n].dop;}
	inline double getAvgSnr(int n) const {return route[n].avgSnr;}
//	inline vector<satInfo> getSatInfo(int n) const {return route[n].usedSats;}
	inline vector<rNode> getRoute() const {return route;}
	inline string getOriginalFilename() const {return originalFilename;}
	inline string getName() const {return name;}

	double getTotalLength() const;

	string pointToKml(int n);
	void printRoute();

private:
	vector<rNode> route;
	string originalFilename;
	string name;
};

#endif // __ROUTE_H__
