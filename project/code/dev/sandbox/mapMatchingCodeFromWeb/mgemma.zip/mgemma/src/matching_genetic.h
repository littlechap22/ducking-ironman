#ifndef __MATCHING_GENETIC_H__
#define __MATCHING_GENETIC_H__


#include <map>
#include <vector>
#include <fstream>
#include <ctime>
#include "maps.h"
#include "route.h"
#include "path.h"
#include "matching_genetic_util.h"


namespace MapMatching {

#define MAX_SEGMENT_NODES 50
#define SPLIT_SCORE 0.9

	class GenMapMatching
	{
	public:
		GenMapMatching();
		GenMapMatching(mapRepresentation::Map * map, Route * route, bool log=false);
		~GenMapMatching();

		void run(vector<set<int> > * forwardCandidates=NULL, vector<set<int> > * backwardCandidates=NULL, bool generateKML=false);
		inline vector<Path *> getMatched() const {return paths;}
		inline vector<unMatchInfo *> getUnmatchedInfo() const {return unmatched;}
		void buildKMLfile(string filename = "matchOutput.kml");

	private:
		mapRepresentation::Map * map;
		Route * route;
		std::ofstream * out;

		Distances dists;
		geneticParameters params;
		vector<Path *> paths;
		vector<unMatchInfo *> unmatched;

		vector<pair<int, int> > splitByAmbiguity();
	};
}

#endif // __MATCHING_GENETIC_H__
