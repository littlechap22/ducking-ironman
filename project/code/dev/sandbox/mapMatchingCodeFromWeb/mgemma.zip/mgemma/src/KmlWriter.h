#ifndef __KMLWRITER_H__
#define __KMLWRITER_H__


#include "maps.h"
#include "route.h"
#include "path.h"
#include "util.h"
#include <fstream>
#include <list>


using namespace std;
using namespace mapRepresentation;

class KmlWriter
{
public:

	ofstream file;
	KmlWriter(const string& filename);
	~KmlWriter(void);
	//const KmlWriter& operator =(const KmlWriter& k);

	void addPointWindow(const string& folder_id,const vector<pair<Point,double> >& pointWindow,int zone, char latZone);
	void addDistanceInfo(int p1_index,const Point& p1,int p2_index, const Point& p2, double distance,int zone, char latZone);

	void buildMap(Map& m, const string& folder_id, int color = 0);
	void buildTrace(Route& r,const string& folder_id, int c = 1);
	void buildUnmatchedTrace(Route& r,vector<unMatchInfo *> unmatchedInfo,const string& folder_id);
	void addMatchInfo(pair<position,position> match,double distance);

	void openFolder(const string& folder_name);
	void closeFolder();

	void closeDocument();
	void setColor(int c);
	int getColorInt();
	string getColor(int c);
	string getColor();

private:
	vector<string> lineColors;
	//	int color;


	std::list<int> selectLinksFromPath(const std::vector<int>& path);
	std::list<int> getLinksToDraw(Map& map);
	std::vector<int> navigateForward(Map& map,int link);
	std::vector<int> navigateBackward(Map& map,int link);
};

#endif // __KMLWRITER_H__
