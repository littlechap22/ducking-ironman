#ifndef __PATH_H__
#define __PATH_H__


#include <vector>
#include <iostream>

typedef struct _unmatchinfo {
	int start, end;
	int lastMatch, nextMatch;
	int lastPathIndex, nextPathIndex;

	_unmatchinfo(){};

	_unmatchinfo(int _start, int _end, int _lastMatch, int _nextMatch, int _lastPathIndex, int _nextPathIndex)
	{
		start = _start;
		end = _end;
		lastMatch = _lastMatch;
		nextMatch = _nextMatch;
		lastPathIndex = _lastPathIndex;
		nextPathIndex = _nextPathIndex;
	};
} unMatchInfo;

class Path
{
public:
	Path();
	~Path();
	Path(const Path &p);
	const Path& operator=(const Path &p);

	void printPath();


	std::vector<std::pair<int,int> > path;
	double score;
	double avgScore;
	double pathLength;
	int firstMatch;
	int lastMatch;

	int connectBefore;
	int connectAfter;
};

struct comparePathsByPath {
	bool operator() (const Path p1, const Path p2) const {
		
		if (p1.path.size() == p2.path.size())
		{
			int i = 0;

			while (i < p1.path.size() && p1.path[i].second == p2.path[i].second)
				i++;

			if (i == p1.path.size())
				return p1.score < p2.score;
			else
				return p1.path[i].second < p2.path[i].second;
		}
		else
			return p1.path.size() < p2.path.size();
	}
};

struct comparePathsByScore {
	bool operator() (const Path p1, const Path p2) const {
		return p1.avgScore < p2.avgScore;
	}
};

#endif // __PATH_H__
