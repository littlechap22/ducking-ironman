
#include "quadtree.h"
#include "GPSPoint.h"
#include <sstream>
#include <typeinfo>

namespace mapRepresentation {

	void QuadLeafNode::removeMapNode(unsigned int node)
	{
		vector<unsigned int>::iterator it;

		for (it = mapNodes.begin(); it != mapNodes.end(); it++)
			if (*it == node)
			{
				mapNodes.erase(it);
				break;
			}
	}


	QuadInnerNode::~QuadInnerNode()
	{
		for (int i=0; i<4; i++)
			if (nodes[i] != NULL)
				delete nodes[i];
	}


	QuadTree::QuadTree(Map * map)
	{
		root = new QuadLeafNode(position(0, 0), 180, 90);
		m = map;

		std::map<unsigned int, mNode>::iterator it;

		for (it = m->nodes_begin(); it != m->nodes_end(); it++)
			addNode(it->first);
	}

	void QuadTree::addNode(unsigned int key)
	{
		int i, j;
		QuadLeafNode * leaf;
		QuadInnerNode * parent;

		position pos = m->getNodePosition(key);
		std::pair<QuadLeafNode *, QuadInnerNode *> res = findQuadrant(pos.latitude, pos.longitude);
		
		leaf = res.first;
		leaf->addMapNode(key);

		if (leaf->size() > MAX_NODES)
		{
			parent = res.second;
			std::vector<unsigned int> tempNodes = leaf->getNodes();

			QuadInnerNode * newInNode = new QuadInnerNode(leaf->getCenter(), leaf->getHalfWidth(), leaf->getHalfHeight());

			if (parent == NULL) //root
				root = newInNode;
			else
			{
				for (i=0; i<4; i++)
					if (parent->getChild(i) == leaf)
						break;

				parent->setChild(newInNode, i);	
			}

			delete leaf;

			double nWidth = newInNode->getHalfWidth() / 2;
			double nHeight = newInNode->getHalfHeight() / 2;
			double cLat = newInNode->getCenter().latitude;
			double cLon = newInNode->getCenter().longitude;

			newInNode->setNW(new QuadLeafNode(position(cLat+nHeight, cLon-nWidth), nWidth, nHeight));
			newInNode->setNE(new QuadLeafNode(position(cLat+nHeight, cLon+nWidth), nWidth, nHeight));
			newInNode->setSW(new QuadLeafNode(position(cLat-nHeight, cLon-nWidth), nWidth, nHeight));
			newInNode->setSE(new QuadLeafNode(position(cLat-nHeight, cLon+nWidth), nWidth, nHeight));

			for (i=0; i<tempNodes.size(); i++)
				addNode(tempNodes[i]);
		}
	}

	void QuadTree::removeNode(unsigned int key, position oldLocation)
	{
		QuadLeafNode * leaf = getQuadLeafNode(findQuadrant(oldLocation.latitude, oldLocation.longitude).first);

		leaf->removeMapNode(key);
	}

	void QuadTree::updateNodeLocation(unsigned key, position oldLocation)
	{
		QuadLeafNode * leaf = getQuadLeafNode(findQuadrant(oldLocation.latitude, oldLocation.longitude).first);

		position newLocation = m->getNodePosition(key);

		if (!isInside(leaf->getCenter(), leaf->getHalfWidth(), leaf->getHalfHeight(), newLocation.latitude, newLocation.longitude))
		{
			leaf->removeMapNode(key);

			addNode(key);
		}
	}

	std::vector<std::pair<unsigned int, double> > QuadTree::findPointsLessThan(double lat, double lon, double maxDist)
	{
		std::vector<std::pair<unsigned int, double> > nodes;

		GPSPoint p(GPSPoint::convertWGS84ToUTM(lat, lon));

		Point pp(p.longm, p.latm);

		findPoints(&nodes, root, position(lat, lon), pp, maxDist);

		return nodes;
	}

	bool QuadTree::isInside(const position& center, double width, double height, double lat, double lon)
	{
		double topLat = center.latitude + height;
		double leftLon = center.longitude - width;
		double botLat = center.latitude - height;
		double rightLon = center.longitude + width;

		if (topLat >= lat && lat >= botLat && leftLon <= lon && lon <= rightLon)
			return true;

		return false;
	}

	pair<QuadLeafNode *, QuadInnerNode *> QuadTree::findQuadrant(double lat, double lon)
	{
		int i;
		bool looking;
		QuadNode * current, * temp, * parent;
		QuadInnerNode * inNode;
		QuadLeafNode * leafNode;

		if (root == NULL)
			return pair<QuadLeafNode *, QuadInnerNode *>(NULL, NULL);
		else if (!isInside(root->getCenter(), root->getHalfWidth(), root->getHalfHeight(), lat, lon))
		{
			std::cout << "ERROR: Point outside the whole map." << std::endl;
			return pair<QuadLeafNode *, QuadInnerNode *>(NULL, NULL);
		}

		parent = NULL;
		current = root;
		looking = true;

		while (looking)
		{
			if (isLeafNode(current))
			{
				looking = false;
				leafNode = getQuadLeafNode(current);
				inNode = getQuadInnerNode(parent);
			}
			else
			{
				inNode = getQuadInnerNode(current);

				for (i=0; i<4; i++)
				{
					temp = inNode->getChild(i);

					if (isInside(temp->getCenter(), temp->getHalfWidth(), temp->getHalfHeight(), lat, lon))
					{
						parent = current;
						current = temp;
						break;
					}
				}
			}
		}

		return pair<QuadLeafNode *, QuadInnerNode *>(leafNode, inNode);
	}

	void QuadTree::findPoints(std::vector<std::pair<unsigned int, double> > * results, QuadNode * node, const position& pos, const Point& ppos, double dist)
	{
		int i;
		bool testLeafNodes = false;

		if (isLeafNode(node) && getQuadLeafNode(node)->size() == 0)	
			return;

		if (isInside(node->getCenter(), node->getHalfWidth(), node->getHalfHeight(), pos.latitude, pos.longitude))
		{
			if (isLeafNode(node))
				testLeafNodes = true;
			else
			{
				QuadInnerNode * temp = getQuadInnerNode(node);

				for (i=0; i<4; i++)
					findPoints(results, temp->getChild(i), pos, ppos, dist);
			}
		}
		else
		{
			position cpos = node->getCenter();
			position tpos;

			if (cpos.latitude-pos.latitude < 0)
				tpos.latitude = cpos.latitude + node->getHalfHeight();
			else
				tpos.latitude = cpos.latitude - node->getHalfHeight();

			if (cpos.longitude-pos.longitude < 0)
				tpos.longitude = cpos.longitude + node->getHalfWidth();
			else
				tpos.longitude = cpos.longitude - node->getHalfWidth();

			if (fabs(cpos.longitude-pos.longitude) <= node->getHalfWidth()) //same column
				tpos.longitude = pos.longitude;
			else if (fabs(cpos.latitude-pos.latitude) <= node->getHalfHeight()) //same row
				tpos.latitude = pos.latitude;

			GPSPoint tposm (GPSPoint::convertWGS84ToUTM(tpos.latitude, tpos.longitude));

			double max = distance2Points(tposm.longm, tposm.latm, ppos.getX(), ppos.getY());

			if (max <= dist)
			{
				if (isLeafNode(node))
					testLeafNodes = true;
				else
				{
					QuadInnerNode * temp = getQuadInnerNode(node);

					for (i=0; i<4; i++)
						findPoints(results, temp->getChild(i), pos, ppos, dist);
				}
			}
		}

		if (testLeafNodes)
		{
			QuadLeafNode * leaf = getQuadLeafNode(node);
			vector<unsigned int> nodes = leaf->getNodes();
			Point tp;
			double tdist;

			for (i=0; i<nodes.size(); i++)
			{
				tp = m->getNodePoint(nodes[i]);

				tdist = distance2Points(tp, ppos);

				//cout << "Distance from (" << tp.getX() << " , " << tp.getY() << ") m. to (" << ppos.getX() << " , " << ppos.getY() << ") m. = " << tdist << "  (should be <= " << dist << ")" << endl;

				if (tdist <= dist)
					results->push_back(pair<unsigned int, double>(nodes[i], tdist));
			}
		}
	}

	bool QuadTree::isLeafNode(QuadNode * node) const
	{
		return typeid(*node) == typeid(QuadLeafNode);
	}

	QuadLeafNode * QuadTree::getQuadLeafNode(QuadNode * node) const
	{
		QuadLeafNode * leafNode = dynamic_cast<QuadLeafNode *>(node);

		if (leafNode == 0)
			return NULL;

		return leafNode;
	}

	QuadInnerNode * QuadTree::getQuadInnerNode(QuadNode * node) const
	{
		QuadInnerNode * innerNode = dynamic_cast<QuadInnerNode *>(node);

		if (innerNode == 0)
			return NULL;

		return innerNode;
	}

	std::string QuadTree::getQuadTreeStatistics()
	{
		countQuadInnerNode = 0;
		countQuadLeafNode = 0;
		maxNodesInLeaf = 0;
		maxDepth = 0;
		maxWidth = 0;
		maxHeight = 0;
		minWidth = 1000.0;
		minHeight = 1000.0;

		navigateThroughAllNodes(root, 0);

		ostringstream oss(ostringstream::out);
		oss.precision(9);
		oss.setf(ios::floatfield);

		oss << std::endl << "  ### QuadTree Statistics ###" << std::endl;
		oss << "Inner Nodes: " << countQuadInnerNode << "     LeafNodes: " << countQuadLeafNode << "     Max Depth: " << maxDepth << std::endl;
		oss << "Max Nodes in a LeafNode: " << maxNodesInLeaf << "     Max Nodes allowed in a LeafNode: " << MAX_NODES << std::endl;
		oss << (double)m->nodes.size()/countQuadLeafNode << " nodes/QuadLeafNode     Total Nodes: " << m->nodes.size() << std::endl;
		oss << "Max Width: " << maxWidth << "�  Max Height: " << maxHeight << "�" << endl;
		oss << "Min Width: " << minWidth << "�  Min Height: " << minHeight << "�" << std::endl;
		oss << "  ###########################" << std::endl << std::endl;

		return oss.str();
	}

	std::string QuadTree::getQuadTreeKML()
	{
		std::ostringstream oss (ostringstream::out);
		oss.precision(12);
		oss.setf(ios::fixed, ios::floatfield);


		std::ostringstream mNodes (ostringstream::out);
		std::ostringstream leafBorders (ostringstream::out);
		std::ostringstream leafDiagonals(ostringstream::out);
		std::ostringstream centerSpots (ostringstream::out);

		mNodes.precision(12);
		leafBorders.precision(12);
		leafDiagonals.precision(12);
		centerSpots.precision(12);

		mNodes.setf(ios::fixed, ios::floatfield);
		leafBorders.setf(ios::fixed, ios::floatfield);
		leafDiagonals.setf(ios::fixed, ios::floatfield);
		centerSpots.setf(ios::fixed, ios::floatfield);

		mNodes << "		<Folder id=\"MAPNODES\">" << std::endl
			<< "			<name>Nodes</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl
			<< "			<Style id=\"nodeMapIcon\">" << std::endl
			<< "				<IconStyle>" << std::endl
			<< "					<Icon><href>http://maps.google.com/mapfiles/kml/shapes/square.png</href></Icon>" << std::endl
			<< "					<scale>0.40</scale>" << std::endl
			<< "				</IconStyle>" << std::endl
			<< "			</Style>" << std::endl;

		leafBorders << "		<Folder id=\"QUADBORDERS\">" << std::endl
			<< "			<name>Leaf Borders</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl;

		leafDiagonals << "		<Folder id=\"QUADDIAGONALS\">" << std::endl
			<< "			<name>Leaf Diagonals</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl;

		centerSpots << "		<Folder id=\"CENTERSPOTS\">" << std::endl
			<< "			<name>Center LeafNodes</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl
			<< "			<Style id=\"centerLeafIcon\">" << std::endl
			<< "				<IconStyle>" << std::endl
			<< "					<Icon><href>http://maps.google.com/mapfiles/kml/shapes/placemark_circle.png</href></Icon>" << std::endl
			<< "					<scale>0.80</scale>" << std::endl
			<< "				</IconStyle>" << std::endl
			<< "			</Style>" << std::endl;


		gatherKMLinformation(root, 0, mNodes, leafBorders, leafDiagonals, centerSpots);

		mNodes << "		</Folder>" << std::endl;
		leafBorders << "		</Folder>" << std::endl;
		leafDiagonals << "		</Folder>" << std::endl;
		centerSpots << "		</Folder>" << std::endl;


		oss << "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>" << std::endl
			<< "<kml xmlns=\"http://earth.google.com/kml/2.0\">" << std::endl
			<< "<Document>" << std::endl;

		oss << mNodes.str()
			<< leafBorders.str()
			<< leafDiagonals.str()
			<< centerSpots.str();

		oss << "</Document>" << std::endl
			<< "</kml>" << std::endl;

		return oss.str();
	}

	void QuadTree::navigateThroughAllNodes(QuadNode * node, int depth)
	{
		if (!isLeafNode(node))
		{
			QuadInnerNode * inNode = getQuadInnerNode(node);

			countQuadInnerNode++;

			for (int i=0; i<4; i++)
				navigateThroughAllNodes(inNode->getChild(i), depth+1);
		}
		else
		{
			QuadLeafNode * leaf = getQuadLeafNode(node);

			countQuadLeafNode++;

			if (depth > maxDepth)
				maxDepth = depth;

			if (leaf->size() > maxNodesInLeaf)
				maxNodesInLeaf = leaf->size();

			if (leaf->getWidth() > maxWidth)
			{
				maxWidth = leaf->getWidth();
				maxHeight = leaf->getHeight();
			}

			if (leaf->getWidth() < minWidth)
			{
				minWidth = leaf->getWidth();
				minHeight = leaf->getHeight();
			}
		}
	}

	void QuadTree::gatherKMLinformation(QuadNode * node, int depth, std::ostringstream& mNodes, std::ostringstream& leafBorders, std::ostringstream& leafDiagonals, std::ostringstream& centerSpots)
	{
		int i;

		if (isLeafNode(node))
		{
			QuadLeafNode * leaf = getQuadLeafNode(node);
			std::vector<unsigned int> nodes = leaf->getNodes();
			position cent = leaf->getCenter();
			position pos;

			for (i=0; i<nodes.size(); i++)
			{
				pos = m->getNodePosition(nodes[i]);

				mNodes << "			<Placemark>" << std::endl
					<< "				<description>" << std::endl
					<< "					ID: " << nodes[i] << "<br/>" << std::endl 
					<< "					xy: " << pos.longitude << "," << pos.latitude << std::endl
					<< "				</description>" << std::endl
					<< "				<styleUrl>#nodeMapIcon</styleUrl>" << std::endl
					<< "				<LookAt>" << std::endl
					<< "					<longitude>" << pos.longitude << "</longitude>" << std::endl
					<< "					<latitude>" << pos.latitude << "</latitude>" << std::endl
					<< "					<range>50.0</range>" << std::endl
					<< "					<tilt>0.0</tilt>" << std::endl
					<< "				</LookAt>" << std::endl
					<< "				<Point>" << std::endl
					<< "					<coordinates>" << pos.longitude << "," << pos.latitude << ",0</coordinates>" << std::endl
					<< "				</Point>" << std::endl
					<< "			</Placemark>" << std::endl;
			}

			leafBorders << "			<Placemark>" << std::endl
				<< "				<Style>" << std::endl
				<< "					<LineStyle>" << std::endl
				<< "						<color>ff" << "000000" << "</color>" << std::endl
				<< "						<width>3</width>" << std::endl
				<< "					</LineStyle>" << std::endl
				<< "				</Style>" << std::endl
				<< "				<LineString>" << std::endl
				<< "					<tessellate>1</tessellate>" << std::endl
				<< "					<altitudeMode>clampedToGround</altitudeMode>" << std::endl
				<< "					<coordinates>" << std::endl
				<< "						" << cent.longitude-leaf->getHalfWidth() << "," << cent.latitude+leaf->getHalfHeight() << ",0" << std::endl
				<< "						" << cent.longitude+leaf->getHalfWidth() << "," << cent.latitude+leaf->getHalfHeight() << ",0" << std::endl
				<< "						" << cent.longitude+leaf->getHalfWidth() << "," << cent.latitude-leaf->getHalfHeight() << ",0" << std::endl
				<< "						" << cent.longitude-leaf->getHalfWidth() << "," << cent.latitude-leaf->getHalfHeight() << ",0" << std::endl
				<< "					</coordinates>" << std::endl
				<< "				</LineString>" << std::endl
				<< "			</Placemark>" << std::endl;

			leafDiagonals << "			<Placemark>" << std::endl
				<< "				<Style>" << std::endl
				<< "					<LineStyle>" << std::endl
				<< "						<color>ff" << "0000ff" << "</color>" << std::endl
				<< "						<width>1</width>" << std::endl
				<< "					</LineStyle>" << std::endl
				<< "				</Style>" << std::endl
				<< "				<LineString>" << std::endl
				<< "					<tessellate>1</tessellate>" << std::endl
				<< "					<altitudeMode>clampedToGround</altitudeMode>" << std::endl
				<< "					<coordinates>" << std::endl
				<< "						" << cent.longitude+leaf->getHalfWidth() << "," << cent.latitude+leaf->getHalfHeight() << ",0" << std::endl
				<< "						" << cent.longitude-leaf->getHalfWidth() << "," << cent.latitude-leaf->getHalfHeight() << ",0" << std::endl
				<< "					</coordinates>" << std::endl
				<< "				</LineString>" << std::endl
				<< "			</Placemark>" << std::endl
				<< "			<Placemark>" << std::endl
				<< "				<Style>" << std::endl
				<< "					<LineStyle>" << std::endl
				<< "						<color>ff" << "0000ff" << "</color>" << std::endl
				<< "						<width>1</width>" << std::endl
				<< "					</LineStyle>" << std::endl
				<< "				</Style>" << std::endl
				<< "				<LineString>" << std::endl
				<< "					<tessellate>1</tessellate>" << std::endl
				<< "					<altitudeMode>clampedToGround</altitudeMode>" << std::endl
				<< "					<coordinates>" << std::endl
				<< "						" << cent.longitude-leaf->getHalfWidth() << "," << cent.latitude+leaf->getHalfHeight() << ",0" << std::endl
				<< "						" << cent.longitude+leaf->getHalfWidth() << "," << cent.latitude-leaf->getHalfHeight() << ",0" << std::endl
				<< "					</coordinates>" << std::endl
				<< "				</LineString>" << std::endl
				<< "			</Placemark>" << std::endl;

			centerSpots << "			<Placemark>" << std::endl
				<< "				<description>" << std::endl
				<< "					xy: " << cent.longitude << "," << cent.latitude << "<br/>" << std::endl
				<< "					Depth: " << depth << "<br/>" << std::endl
				<< "					Nodes: " << leaf->size() << "<br/>" << std::endl
				<< "					Width: " << leaf->getWidth() << " �<br/>" << std::endl
				<< "					Height: " << leaf->getHeight() << " �" << std::endl
				<< "				</description>" << std::endl
				<< "				<styleUrl>#centerLeafIcon</styleUrl>" << std::endl
				<< "				<LookAt>" << std::endl
				<< "					<longitude>" << cent.longitude << "</longitude>" << std::endl
				<< "					<latitude>" << cent.latitude << "</latitude>" << std::endl
				<< "					<range>50.0</range>" << std::endl
				<< "					<tilt>0.0</tilt>" << std::endl
				<< "				</LookAt>" << std::endl
				<< "				<Point>" << std::endl
				<< "					<coordinates>" << cent.longitude << "," << cent.latitude << ",0</coordinates>" << std::endl
				<< "				</Point>" << std::endl
				<< "			</Placemark>" << std::endl;
		}
		else
		{
			QuadInnerNode * inNode = getQuadInnerNode(node);

			for (i=0; i<4; i++)
				gatherKMLinformation(inNode->getChild(i), depth+1, mNodes, leafBorders, leafDiagonals, centerSpots);
		}
	}
}
