
#include "matching_marchal.h"
#include "kml.h"
#include <iostream>
#include <sstream>


namespace MapMatching {

	MarPath::MarPath()
	{
		countTracePoints = 0;
		score = 0;
		lastScore = 0;
		avgScore = 0;
	}

	MarPath::MarPath(const std::pair<routePoint, mapRepresentation::LinkKey>& m)
	{
		countTracePoints = 0;
		score = 0;
		lastScore = 0;
		avgScore = 0;

		addLinkCandidate(m);
	}

	MarPath::MarPath(const MarPath &p)
	{
		path = p.path;
		countTracePoints = p.countTracePoints;
		score = p.score;
		lastScore = p.lastScore;
		avgScore = p.avgScore;
	}

	const MarPath& MarPath::operator=(const MarPath &p)
	{
		if (this != &p)
		{
			path = p.path;
			countTracePoints = p.countTracePoints;
			score = p.score;
			lastScore = p.lastScore;
			avgScore = p.avgScore;
		}
		return *this;
	}

	void MarPath::addLinkCandidate(const std::pair<routePoint, mapRepresentation::LinkKey>& c)
	{
		if (c.first >= 0)
			countTracePoints++;

		path.push_back(c);
	}

	void MarPath::updateScore(double s)
	{
		score += s;
		lastScore = s;
		avgScore = score / countTracePoints;
	}

	int MarPath::countDistinctMatchedLinks() const
	{
		unsigned int i, count;
		mapRepresentation::LinkKey last;

		if (path.empty())
			return 0;

		last = path.front().second;
		count = 1;

		for (i=1; i<path.size(); i++)
			if (path[i].first >= 0 && last != path[i].second)
			{
				count++;
				last = path[i].second;
			}

			return count;
	}

	MarPath MarPath::reversedPath()
	{
		int i;
		MarPath rPath(*this);
		rPath.path.clear();

		for (i = (int)path.size() - 1; i >= 0; i--)
			rPath.path.push_back(path[i]);

		return rPath;
	}

	void MarPath::printPath() const
	{
		std::cout << "Path size: " << path.size() << " Matched trace points: " << countTracePoints << " score: " << score << " avgScore: " << avgScore << "  ";

		for (unsigned int i = 0; i < path.size(); i++)
			std::cout << "(" << path[i].first << ", " << path[i].second << ") ";

		std::cout << std::endl;
	}


	MarchalBMatching::MarchalBMatching(mapRepresentation::Map * map, Route * route)
	{
		this->map = map;
		this->route = route;
		matchingForwards = true;
		routePtr = 0;
	}

	MarchalBMatching::~MarchalBMatching()
	{
		int i;

		for (i=0; i<matchedTraces.size(); i++)
			delete matchedTraces[i];

		for (i=0; i<shortMatchedTraces.size(); i++)
			delete shortMatchedTraces[i];

		for (i=0; i<unmatchInfo.size(); i++)
			delete unmatchInfo[i];
	}

	void MarchalBMatching::run(bool forwardMatching, bool generateKML)
	{
		int i;
		routePtr = 0;

		matchingForwards = forwardMatching;

		paths.clear();
		finalPaths.clear();
		matchedTraces.clear();
		shortMatchedTraces.clear();
		unmatchInfo.clear();
		candidates.clear();
		candidates.resize(route->size());
		routePtr = 0;

		while (routePtr < route->size())
		{
			findNearestLinks();

			if (routePtr < route->size())
				continueMatching();
		}

		// reverse paths when running backwards
		if (!matchingForwards)
		{
			std::vector<MarPath> revPaths;

			for (i = (int)finalPaths.size() - 1; i >= 0; i--)
				revPaths.push_back(finalPaths[i].reversedPath());

			finalPaths = revPaths;
		}

		if (generateKML)
			generateMatchKML();
	}

	vector<Path *> MarchalBMatching::getMatched()
	{
		if (matchedTraces.empty() && unmatchInfo.empty())
			prepateOutput();

		std::vector<Path *> matched(matchedTraces.size());

		for (int i = 0; i < matchedTraces.size(); i++)
			matched[i] = new Path(*matchedTraces[i]);

		return matched;
	}

	vector<Path *> MarchalBMatching::getShortMatched()
	{
		if (matchedTraces.empty() && unmatchInfo.empty())
			prepateOutput();

		std::vector<Path *> matched(shortMatchedTraces.size());

		for (int i = 0; i < shortMatchedTraces.size(); i++)
			matched[i] = new Path(*shortMatchedTraces[i]);

		return matched;
	}

	vector<unMatchInfo *> MarchalBMatching::getUnmatchedInfo()
	{
		if (matchedTraces.empty() && unmatchInfo.empty())
			prepateOutput();

		std::vector<unMatchInfo *> unMatch(unmatchInfo.size());

		for (int i = 0; i < unmatchInfo.size(); i++)
			unMatch[i] = new unMatchInfo(*unmatchInfo[i]);

		return unMatch;
	}

	void MarchalBMatching::findNearestLinks()
	{
		unsigned int i;
		int ptr;
		double pHeading;
		std::vector<std::pair<int, double> > closeLinks;
		std::multiset<MarPath> initPaths;

		paths.clear();

		while (paths.empty() && routePtr < route->size())
		{
			if (matchingForwards)
				ptr = routePtr;
			else
				ptr = reversedRouteIndex(routePtr);

			initPaths.clear();
			closeLinks = map->getNearestLinksAndDistances(route->getLatitude(ptr), route->getLongitude(ptr), INITIAL_MIN_DISTANCE);
			pHeading = route->getHeading(ptr);

			for (i=0; i<closeLinks.size(); i++)
			{
				if (fabs(pHeading - ajustHeadingToInterval(map->getLink(closeLinks[i].first).heading, pHeading)) <= deg2rad(DELTA_HEADING))
				{
					MarPath np(std::pair<routePoint, mapRepresentation::LinkKey>(ptr, closeLinks[i].first));
					initPaths.insert(np);
				}

				//add link to candidates
				candidates[ptr].insert(closeLinks[i].first);
			}

			if (initPaths.empty()) //move to next point
				routePtr++;
			else
				paths = initPaths;
		}
	}

	void MarchalBMatching::continueMatching()
	{
		bool matching;
		int ptr;
		double tempScore, minDifScore;
		Point p;
		MarPath best;
		mapRepresentation::mLink l;
		std::multiset<MarPath> newPaths;
		std::multiset<MarPath>::iterator pit;
		std::pair<Point, double> res;

		matching = true;

		while (matching)
		{		
			minDifScore = 100000000;
			newPaths.clear();

			if (matchingForwards)
				ptr = routePtr;
			else
				ptr = reversedRouteIndex(routePtr);

			p = route->getPoint(ptr);

			for (pit = paths.begin(); pit != paths.end(); pit++)
			{
				MarPath temp(*pit);
				tempScore = temp.score;

				l = map->getLink(temp.path.back().second);
				res = getNearestPointFromLink(map->getNodePoint(l.orID), map->getNodePoint(l.destID), p);
				temp.updateScore(score(temp.path.back().second, p, res.second));

				if (temp.score - tempScore < minDifScore)
					minDifScore = temp.score - tempScore;

				newPaths.insert(temp);
			}

			if (minDifScore > DIF_MIN_SCORE || routePtr + 1 == route->size()) //break matching
			{
				if (routePtr + 1 == route->size() && minDifScore <= DIF_MIN_SCORE)
					best = *newPaths.begin();

				if (best.countDistinctMatchedLinks() > 3 || best.countTracePoints > 6) //ignore small matches
					finalPaths.push_back(best);

				if (routePtr + 1 == route->size() || best.path.empty()) //move to next point
					routePtr++;

				matching = false;
			}
			else
			{
				newPaths = filterCandidates(newPaths);
				saveBestPaths(newPaths);
				best = *paths.begin();

				routePtr++;

				if (matchingForwards)
					ptr = routePtr;
				else
					ptr = reversedRouteIndex(routePtr);

				newPaths.clear();

				for (pit = paths.begin(); pit != paths.end(); pit++)
				{					
					MarPath mp(*pit);
					mp.addLinkCandidate(std::pair<routePoint, mapRepresentation::LinkKey>(ptr, mp.path.back().second));
					newPaths.insert(mp);

					addNewPaths(newPaths, MarPath(*pit), MATCH_TOLERANCE_LINKS+1);
				}

				paths.clear();
				paths.insert(newPaths.begin(), newPaths.end());
			}
		}
	}

	double MarchalBMatching::score(int linkID, const Point &pos, double distance)
	{
		return distance;
	}

	void MarchalBMatching::addNewPaths(std::multiset<MarPath>& s, const MarPath& p, int maxDepth)
	{
		int ptr;
		std::set<mapRepresentation::LinkKey> edges;
		std::set<mapRepresentation::LinkKey>::iterator it;
		mapRepresentation::mLink l = map->getLink(p.path.back().second);

		if (matchingForwards)
		{
			ptr = routePtr;
			edges = map->getSuccessorEdges(l.destID);
		}
		else
		{
			ptr = reversedRouteIndex(routePtr);
			edges = map->getPredecessorEdges(l.orID);
		}

		for (it = edges.begin(); it != edges.end(); it++)
		{
			if (!map->areMirrored(p.path.back().second, *it))
			{
				MarPath newPath(p);
				newPath.addLinkCandidate(std::pair<routePoint, mapRepresentation::LinkKey>(ptr, *it));
				s.insert(newPath);

				//add link to candidates
				candidates[ptr].insert(*it);

				if (maxDepth > 1)
				{
					MarPath newestPath(p);
					newestPath.addLinkCandidate(std::pair<routePoint, mapRepresentation::LinkKey>(-1, *it));

					addNewPaths(s, newestPath, maxDepth-1);
				}
			}
		}
	}

	std::multiset<MarPath> MarchalBMatching::filterCandidates(std::multiset<MarPath>& paths)
	{
		mapRepresentation::SuperLinkKey k;
		std::multiset<MarPath> cleared;
		std::multiset<MarPath>::iterator it = paths.begin();
		std::map<mapRepresentation::SuperLinkKey, MarPath> filtered;
		std::map<mapRepresentation::SuperLinkKey, MarPath>::iterator fit;

		/*if (it->path.size() <= 3)
		{
			cleared = paths;
			return cleared;
		}*/

		for ( ; it != paths.end(); it++)
		{
			if (it->lastScore < MAX_ACCEPTABLE_SCORE)
			{
				k = map->getSuperLinkKey(it->path.back().second);
				fit = filtered.find(k);

				if (fit == filtered.end())
					filtered.insert(make_pair(k, *it));
				else if (it->avgScore < fit->second.avgScore)
					fit->second = *it;
			}
		}

		for (fit = filtered.begin(); fit != filtered.end(); fit++)
			cleared.insert(fit->second);

		return cleared;
	}

	void MarchalBMatching::saveBestPaths(multiset<MarPath>& s)
	{
		int i;
		std::multiset<MarPath>::iterator it;

		paths.clear();

		for (i=0, it=s.begin(); i<N && it!=s.end(); i++, it++)
			paths.insert(MarPath(*it));
	}

	void MarchalBMatching::prepateOutput()
	{
		int i;
		Path tPath;
		unMatchInfo temp;

		if (finalPaths.empty())
		{
			temp.start = 0;
			temp.lastMatch = -1;
			temp.lastPathIndex = -1;
			temp.end = (int)route->size() - 1;
			temp.nextMatch = -1;
			temp.nextPathIndex = -1;

			unmatchInfo.push_back(new unMatchInfo(temp));
		}
		else
		{
			//std::vector<Path> matchedPaths, shortMatchedPaths;

			for (i=0; i<finalPaths.size(); i++)
			{
				matchedTraces.push_back(new Path(getPath(finalPaths[i], true)));
				shortMatchedTraces.push_back(new Path(getPath(finalPaths[i], false)));
			}

			/*for (i=0; i<finalPaths.size(); i++)
			{
				tPath = getPath(finalPaths[i]);
				all.push_back(Path(tPath));
			}*/	

			//compressed = all;

			for (i=0; i<matchedTraces.size(); i++)
			{
				if (i + 1 < matchedTraces.size())
				{
					if (matchedTraces[i]->path.back().first + 1 == matchedTraces[i+1]->path.front().first)
					{
						temp.start = -1;
						temp.end = -1;
						temp.lastMatch = matchedTraces[i]->path.back().second;
						temp.nextMatch = matchedTraces[i+1]->path.front().second;
						temp.lastPathIndex = i;
						temp.nextPathIndex = i+1;

						unmatchInfo.push_back(new unMatchInfo(temp));
					}
					else
					{
						temp.start = matchedTraces[i]->path.back().first + 1;	
						temp.end = matchedTraces[i+1]->path.front().first - 1;
						temp.lastMatch = matchedTraces[i]->path.back().second;
						temp.lastPathIndex = i;
						temp.end = matchedTraces[i+1]->path.front().first - 1;
						temp.nextMatch = matchedTraces[i+1]->path.front().second;
						temp.nextPathIndex = i+1;

						unmatchInfo.push_back(new unMatchInfo(temp));
					}
				}

				if (i == 0 && matchedTraces[i]->path.front().first != 0)
				{
					temp.start = 0;
					temp.lastMatch = -1;
					temp.lastPathIndex = -1;
					temp.end = matchedTraces[i]->path.front().first - 1;
					temp.nextMatch = matchedTraces[i]->path.front().second;
					temp.nextPathIndex = i;

					unmatchInfo.push_back(new unMatchInfo(temp));
				}

				if (i + 1 == matchedTraces.size() && matchedTraces[i]->path.back().first < (int)route->size() - 1)
				{
					temp.start = matchedTraces[i]->path.back().first + 1;
					temp.lastMatch = matchedTraces[i]->path.back().second;
					temp.lastPathIndex = i;
					temp.end = (int)route->size() - 1;
					temp.nextMatch = -1;
					temp.nextPathIndex = -1;

					unmatchInfo.push_back(new unMatchInfo(temp));
				}
			}	

			//for (i=0; i<compressed.size(); i++)
			//	shortMatchedTraces.push_back(new Path(compressed[i]));
		}
	}

	Path MarchalBMatching::getPath(const MarPath& p, bool unmatchedLinks)
	{
		int i;
		Path newPath;

		for (i=0; i<p.path.size(); i++)
			if (unmatchedLinks || (!unmatchedLinks && p.path[i].first >= 0))
				newPath.path.push_back(p.path[i]);

		newPath.firstMatch = newPath.path.front().first;
		newPath.lastMatch = newPath.path.back().first;

		return newPath;
	}

	void MarchalBMatching::generateMatchKML()
	{
		unsigned int i, j;
		vector<int> matched(route->size(), INVALID_LINK);
		std::string name;

		for (i=0; i<finalPaths.size(); i++)
			for (j=0; j<finalPaths[i].path.size(); j++)
				if (finalPaths[i].path[j].first >= 0 && matched[finalPaths[i].path[j].first] == INVALID_LINK)
					matched[finalPaths[i].path[j].first] = finalPaths[i].path[j].second;

		if (matchingForwards)
			name = "marchal";
		else
			name = "marchal_back";

		kmlMatch::KMLBuilder kmlFile(map, route, matched, std::vector<pair<int, int> >(0), name);
		kmlFile.buildKML();
	}

	void MarchalBMatching::showPaths(std::multiset<MarPath>& paths)
	{
		std::multiset<MarPath>::iterator it;

		std::cout << "   ### [PATHS] ###" << std::endl;

		for (it = paths.begin(); it != paths.end(); it++)
			it->printPath();

		std::cout << "   ### [/PATHS] ###" << std::endl << std::endl;
	}
}
