#ifndef __QUADTREE_H__
#define __QUADTREE_H__


#include "maps.h"
#include "util.h"
#include <vector>

namespace mapRepresentation {

#define MAX_NODES 10

#define NW 0
#define NE 1
#define SW 2
#define SE 3

	class Map;
	
	class QuadNode
	{
	public:
		QuadNode(const position& pos, double hWidth, double hHeight)
		{center = pos; h_width = hWidth; h_height = hHeight;}

		virtual ~QuadNode() {};

		inline position getCenter() const {return center;}
		inline double getHalfWidth() const {return h_width;}
		inline double getWidth() const {return 2*h_width;}
		inline double getHalfHeight() const {return h_height;}
		inline double getHeight() const {return 2*h_height;}

	protected:
		position center;
		double h_width;
		double h_height;

	private:
		QuadNode();
	};

	class QuadLeafNode : public QuadNode
	{
	public:
		QuadLeafNode(const position& pos, double hWidth, double hHeight)
			: QuadNode(pos, hWidth, hHeight) {}

		QuadLeafNode(const position& pos, double hWidth, double hHeight, const std::vector<unsigned int>& nodes)
			: QuadNode(pos, hWidth, hHeight) {mapNodes = nodes;}

		inline void addMapNode(unsigned int node) {mapNodes.push_back(node);}
		void removeMapNode(unsigned int node);

		inline std::vector<unsigned int> getNodes() const {return mapNodes;}
		inline int size() const {return (int)mapNodes.size();}

	private:
		QuadLeafNode();

		std::vector<unsigned int> mapNodes;
	};

	class QuadInnerNode : public QuadNode
	{
	public:
		QuadInnerNode(const position& pos, double hWidth, double hHeight)
			: QuadNode(pos, hWidth, hHeight) {nodes[NW] = nodes[NE] = nodes[SW] = nodes[SE] = NULL;}

		QuadInnerNode(const position& pos, double hWidth, double hHeight, QuadNode * nodeNW, QuadNode * nodeNE, QuadNode * nodeSW, QuadNode * nodeSE)
			: QuadNode(pos, hWidth, hHeight) {nodes[NW] = nodeNW; nodes[NE] = nodeNE; nodes[SW] = nodeSW; nodes[SE] = nodeSE;}

		~QuadInnerNode();

		inline QuadNode * getNW() const {return nodes[NW];}
		inline QuadNode * getNE() const {return nodes[NE];}
		inline QuadNode * getSW() const {return nodes[SW];}
		inline QuadNode * getSE() const {return nodes[SE];}
		inline QuadNode * getChild(int child) const {return nodes[child];}

		void setNW(QuadNode * node) {nodes[NW] = node;}
		void setNE(QuadNode * node) {nodes[NE] = node;}
		void setSW(QuadNode * node) {nodes[SW] = node;}
		void setSE(QuadNode * node) {nodes[SE] = node;}
		void setChild(QuadNode * node, int child) {nodes[child] = node;}

	private:
		QuadInnerNode();

		QuadNode * nodes[4];
	};

	class QuadTree
	{
	public:
		QuadTree(Map * m);

		void addNode(unsigned int key);
		void removeNode(unsigned int key, position oldLocation);
		void updateNodeLocation(unsigned key, position oldLocation);

		std::vector<std::pair<unsigned int, double> > findPointsLessThan(double lat, double lon, double maxDist);

		std::string getQuadTreeStatistics();
		std::string getQuadTreeKML();

	private:	
		QuadTree();

		Map * m;
		QuadNode * root;
		int countQuadInnerNode;
		int countQuadLeafNode;
		int maxNodesInLeaf;
		int maxDepth;
		double maxWidth;
		double maxHeight;
		double minWidth;
		double minHeight;

		bool isInside(const position& center, double width, double height, double lat, double lon);
		std::pair<QuadLeafNode *, QuadInnerNode *> findQuadrant(double lat, double lon);
		void findPoints(std::vector<std::pair<unsigned int, double> > * results, QuadNode * node, const position& pos, const Point& ppos, double dist);

		bool isLeafNode(QuadNode * node) const;
		QuadLeafNode * getQuadLeafNode(QuadNode * node) const;
		QuadInnerNode * getQuadInnerNode(QuadNode * node) const;

		void navigateThroughAllNodes(QuadNode * node, int depth);
		void gatherKMLinformation(QuadNode * node, int depth, std::ostringstream& mNodes, std::ostringstream& leafBorders, std::ostringstream& leafDiagonals, std::ostringstream& centerSpots);
	};
}

#endif // __QUADTREE_H__
