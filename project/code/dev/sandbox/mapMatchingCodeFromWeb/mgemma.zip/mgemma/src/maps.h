#ifndef __MAPS_H__
#define __MAPS_H__


#include "quadtree.h"
#include "route.h"
#include "util.h"
#include "geometry.h"
#include <string>
#include <map>
#include <set>
#include <list>

namespace mapRepresentation {

	class QuadTree;

#define INVALID_LINK -1

	typedef unsigned int SuperNodeKey;
	typedef int SuperLinkKey;
	typedef unsigned int NodeKey;
	typedef int LinkKey;


	typedef struct _mSuperLink {
		SuperNodeKey orNode;
		SuperNodeKey destNode;
		std::list<LinkKey> links;

		_mSuperLink(){};

		_mSuperLink(SuperNodeKey orN, SuperNodeKey destN, std::list<LinkKey> lis)
		{
			orNode = orN;
			destNode = destN;
			links = lis;
		};
	} mSuperLink;

		
	typedef struct _mSuperEdges {
		std::set<SuperLinkKey> predecessors;	
		std::set<SuperLinkKey> successors;
	} mSuperEdges;


	typedef struct _mEdges {
		//set<edge, compareEdges> predecessors;	
		//set<edge, compareEdges> successors;
		std::set<int> predecessors;	
		std::set<int> successors;
	} mEdges;

	typedef struct _mLink {
		unsigned int orID;
		unsigned int destID;
		SuperLinkKey superLink;
		int sequenceNumber;
		double heading;
		double length;

		double avgSpeed;
		//aqui ou no node?
		unsigned int match_count;
		//double strength;
		//double snr;
		//double dop;

		_mLink(){match_count=0; sequenceNumber = -1;}

		_mLink(unsigned int org, unsigned int dest, SuperLinkKey slk,  double head, double len,double avgs, unsigned int count)
		{
			orID = org;
			destID = dest;
			superLink = slk;
			sequenceNumber = -1;
			heading = head;
			length = len;
			match_count = count;
			avgSpeed = avgs;
		};
	} mLink;

	typedef struct _mNode {
		double latitude;
		double longitude;
		double latm;
		double longm;

		////aqui ou no link?
		//unsigned int pass_count;
		double snr;
		double dop;


		_mNode():snr(0),dop(50){};

		_mNode(double lat, double lon, double latM, double longM,double sn, double dp)
		{
			latitude = lat;
			longitude = lon;
			latm = latM;
			longm = longM;
			snr = sn;
			dop = dp;
		};
	} mNode;

	//typedef struct _mSuperNode
	//{
	//	unsigned int node;
	//}mSuperNode;

	//typedef struct _mSuperLink
	//{
	//	vector<int> links;
	//	unsigned int startNodeID;
	//	unsigned int endNodeID;
	//	double length;
	//	double avgSpeed;
	//} mSuperLink;

	//typedef struct _mSuperEdges
	//{
	//	std::set<int> predecessors;	
	//	std::set<int> successors;
	//}mSuperEdges;


	class Map
	{
	public:
		Map();
		Map(const string& filename);
		Map(const Route& route);
		~Map();
		Map(const Map &m);
		const Map& operator=(const Map &m);

	public:
		std::map<SuperNodeKey, mSuperEdges> superGraph;
		std::map<SuperNodeKey, NodeKey> superNodes;
		std::map<SuperLinkKey, mSuperLink> superLinks;


		std::map<unsigned int, mEdges> graph;
		std::map<unsigned int, mNode> nodes;
		//std::map<int, mLink> links;
		std::map<LinkKey, mLink> links;

		//std::map<unsigned int, mEdges> superGraph;
		//std::map<unsigned int, mSuperNode> superNodes;
		//std::map<int, mSuperLink> superLinks;

	public:

		inline mNode getNode(unsigned int key) { 
			map<unsigned int,mNode>::iterator itr = nodes.find(key);
			if (itr != nodes.end())
				return itr->second;
			cout << "ERROR: non existing node. (" << key << ")" << endl;
			return mNode();
			//return nodes[key]; 
		}
		inline mLink getLink(int key) {
			map<int,mLink>::iterator itr = links.find(key);
			if (itr != links.end())
				return itr->second;
			cout << "ERROR: non existing link. (" << key << ")" << endl;
			return mLink();
		//	return links[key];
		}
		inline mEdges getEdges(unsigned int key) {
			map<unsigned int,mEdges>::iterator itr = graph.find(key);
			if (itr != graph.end())
				return itr->second;
			cout << "ERROR: non existing graph node " << key << "." << endl;
			return mEdges();
			//return graph[key];
		}

		inline std::set<int> getPredecessorEdges(unsigned int key) {
			map<unsigned int,mEdges>::iterator itr = graph.find(key);
			if (itr != graph.end())
				return itr->second.predecessors;
			cout << "ERROR: non existing graph node " << key << "." << endl;
			return set<int>();
			//return graph[key];
		}

		inline std::set<int> getSuccessorEdges(unsigned int key) {
			map<unsigned int,mEdges>::iterator itr = graph.find(key);
			if (itr != graph.end())
				return itr->second.successors;
			cout << "ERROR: non existing graph node " << key << "." << endl;
			return set<int>();
			//return graph[key];
		}

		inline double getLinkLength(int key) {
			map<int,mLink>::iterator itr = links.find(key);
			if (itr != links.end())
				return itr->second.length;
			cout << "ERROR: non existing link " << key << "." << endl;
			return -1;
		}

		inline map<int, mLink>::iterator links_begin() { return links.begin(); }
		inline map<int, mLink>::iterator links_end() { return links.end(); }
		inline std::map<unsigned int, mEdges>::iterator graph_begin() { return graph.begin(); }
		inline std::map<unsigned int, mEdges>::iterator graph_end() { return graph.end(); }
		inline std::map<unsigned int, mNode>::iterator nodes_begin() {return nodes.begin();}
		inline std::map<unsigned int, mNode>::iterator nodes_end() {return nodes.end();}



		NodeKey addNodeToMap(double lat, double lon, double snr, double dop);
		NodeKey addNodeInLink(LinkKey link, double lat, double lon, double snr, double dop);
		LinkKey addLinkToNode(NodeKey startNode, NodeKey endNode, double avg_speed, unsigned int match_count=1);

		void mergePaths(vector<pair<int,vector<int> > > matchedLinks,int order);
		

		unsigned int updateNode(unsigned int key, mNode updatedNode);
		
		
		void updateLinkStats(int link,double speed,unsigned int count = 1);

		
		//
		void buildSuperMap();

		int getNodeDegree(NodeKey node);
		int getNodeIndegree(NodeKey node);
		int getNodeOutdegree(NodeKey node);

		inline bool isAnIsland(NodeKey node) {return getNodeDegree(node) == 0;}
		inline bool isJunction(NodeKey node) {return getNodeIndegree(node) > 1 || getNodeOutdegree(node) > 1;}
		inline bool isSourceNode(NodeKey node) {return getNodeIndegree(node) == 0 && getNodeOutdegree(node) >= 0;}
		inline bool isSinkNode(NodeKey node) {return getNodeIndegree(node) >= 0 && getNodeOutdegree(node) == 0;}

		SuperLinkKey getSuperLinkKey(LinkKey link);
		int getSequenceNumber(LinkKey link); 

		//


		bool areMirrored(LinkKey first, LinkKey second);
		bool isConnected(int first, int second);
		bool belongSameSuperLink(LinkKey first, LinkKey second);
		std::vector<LinkKey> getLinksBetween(LinkKey from, LinkKey dest);
		std::pair<bool, std::vector<int> > isAchievableWithoutAmbiguity(int from, int to, int skipLinks);
		std::pair<bool, std::vector<int> > isAchievableWithAmbiguity(int from, int to, int skipLinks);
		std::set<int> getAllAchievableLinks(int from, int depth);
		std::set<int> getAllFormerLinks(int from, int depth);
		std::vector<int> getLinksUntilNextJunction(int link, int maxDepth);
		std::vector<int> getLinksUntilPreviousJunction(int link, int maxDepth);

		//
		std::set<SuperLinkKey> getAllAchievableSuperLinks(SuperLinkKey from, int depth, int lengthIntermediateSuperLinks);

		vector<unsigned int> getNearestPoints(double latitude, double longitude, double maxDistance);
		vector<pair<unsigned int, double> > getNearestPointsAndDistances(double latitude, double longitude, double maxDistance);
		vector<int> getNearestLinks(double latitude, double longitude, double maxDistance);
		vector<pair<int, double> > getNearestLinksAndDistances(double latitude, double longitude, double maxDistance);

		Point getNodePoint(unsigned int node);
		position getNodePosition(unsigned int node);	

		void validateMap();
		void showGraph();
		void mapInfo();

		void saveMap(const string& filename);
		void saveMapForEjaki(const string& filename);
		void saveToKml(const string &filename);


	private:
		unsigned int nodeID;
		int linkID;
		int superLinkID;
		QuadTree * qtree;

		void initMap(const string& filename);
		void initMapFromRoute(const Route& route);

		NodeKey addNode(NodeKey key, double lat, double lon, double snr, double dop);
		LinkKey addLink(LinkKey linkKey, NodeKey startNode, NodeKey endNode, double avg_speed, unsigned int match_count=1);

		void mergeLinks(int link1ID, vector<int> matchedLinks,int order);
		void mergeEdges(unsigned int nodeID1, unsigned int nodeID2);
		void calcAvgNode(unsigned int node1ID,int link1Count, unsigned int node2ID, int link2Count);
		mNode calcAvgNode(mNode node1,int link1Count,mNode node2, int link2Count);
		void updateLink(int linkID, unsigned int newOrID, unsigned int newDestID);

		void deleteLink(LinkKey linkKey);
		void deleteNode(NodeKey nodeKey);
		void splitSuperLink(SuperLinkKey superLink, NodeKey splitNode);
		void deleteLinkFromSuperLink(SuperLinkKey superLinkKey, LinkKey linkKey);
		void mergeSuperLinks(NodeKey node);
	};
}

#endif // __MAPS_H__
