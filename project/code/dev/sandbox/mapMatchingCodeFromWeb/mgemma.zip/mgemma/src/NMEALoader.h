#ifndef __NMEALOADER_H__
#define __NMEALOADER_H__


#include "route.h"
#include <ctime>
#include <map>



class NMEATag
{
protected:
	int line_number;
	NMEATag(int line_numb)
	{
		this->line_number = line_numb;
	}
public:
	inline int getLineNumber() const { return line_number; }
	//inline NMEATag() {}
	//static NMEATag& parseNMEAString(string nmea);
	//static const int RMC = 0;
	//virtual int GetTagType()=0;
	//virtual NMEATag parseString(string nmeastring)=0;
};

class RMCTag : public NMEATag
{
private:
	unsigned int	m_Time;
	unsigned int    m_Date;
	bool		m_Validity;
	double		m_Latitude;
	double		m_Longitude;
	double		m_Speed;
	double		m_Azimuth;

	void parseRMCString(vector<string> nmeaTokens);
public:
	//inline RMCTag(const RMCTag& rmcTag)
	//{
	//	this->m_Azimuth = rmcTag.m_Azimuth;
	//	this->m_Date = rmcTag.m_Date;
	//	this->m_Latitude = rmcTag.m_Latitude;
	//	this->m_Longitude = rmcTag.m_Longitude;
	//	this->m_Speed = rmcTag.m_Speed;
	//	this->m_Time = rmcTag.m_Time;
	//	this->m_Validity = rmcTag.m_Validity;
	//}
	inline RMCTag() : NMEATag(0)
	{
		Reset();
	}
	inline RMCTag(vector<string> nmeaTokens,int line_number) : NMEATag(line_number)
	{ 
		Reset();
		parseRMCString(nmeaTokens); 
	}
	//getters
	inline unsigned int GetDateTime() const
	{
		unsigned int date = m_Date;
		unsigned int time = m_Time;
		struct tm * stime;
		time_t rawtime;

		
		::time (&rawtime);
		stime = gmtime (&rawtime);
		stime->tm_isdst = 0;

		stime->tm_year = 2000 + (date %100) - 1900;
		date /= 100;
		stime->tm_mon = (date % 100) - 1;
		date /=100;
		stime->tm_mday = (date % 100);

		time /= 1000;
		stime->tm_sec = time % 100;
		time /= 100;
		stime->tm_min = time % 100;
		time /= 100;
		stime->tm_hour = time % 100;

		return (unsigned int)mktime(stime);
	}
	inline unsigned int	GetTime() const		{	return m_Time; }
	inline unsigned int GetDate() const        {   return m_Date; }
	inline bool			GetValidity() const	{	return m_Validity; }
	inline double		GetLatitude() const	{	return m_Latitude; }
	inline double		GetLongitude() const	{	return m_Longitude; }
	inline double		GetSpeed() const		{	return m_Speed; }
	inline double		GetAzimuth() const		{	return m_Azimuth; }
private:
	// setters
	inline void		SetTime(unsigned int v)	{	m_Time=v; }
	inline void     SetDate(unsigned int v) {   m_Date=v; }
	inline void		SetValidity(bool v)	{	m_Validity=v; }
	inline void		SetLatitude(double v)	{	m_Latitude=v; }
	inline void		SetLongitude(double v)	{	m_Longitude=v; }
	inline void		SetSpeed(double v)	{	m_Speed=v; }
	inline void		SetAzimuth(double v)	{	m_Azimuth=v; }
	inline void		Reset() 		{
		m_Time		= 0xffffffff;
		m_Date		= 0xffffffff;
		m_Validity	= false;
		m_Latitude	= 1000.0;
		m_Longitude	= 1000.0;
		m_Speed		= -1000.0;
		m_Azimuth	= 1000.0;
	}

public:
	// queryers
	inline bool		HasTime() const		{	return (m_Time!=0xffffffff); }
	inline bool     HasDate() const     {   return (m_Date!=0xffffffff); }
	inline bool		HasValidity() const	{	return true; }
	inline bool		HasLatitude() const	{	return (m_Latitude!=1000.0); }
	inline bool		HasLongitude() const	{	return (m_Longitude!=1000.0); }
	inline bool		HasSpeed() const	{	return (m_Speed!=-1000.0); }
	inline bool		HasAzimuth() const	{	return (m_Azimuth!=1000.0); }
	inline bool		IsEmpty() const		{
		return (!HasTime()) && (!HasDate()) && (!HasLatitude()) && (!HasLongitude()) && (!HasSpeed()) && (!HasAzimuth());
	}

	inline bool		IsComplete() const 
	{
		return HasTime() && HasDate() && HasLatitude() && HasLongitude();
	}
};

class GGATag : public NMEATag
{
private:
	unsigned int	m_Time;
	double		m_HDOP;
	int		m_Satellites;

	//unsigned int m_fixQuality;

	//double m_Altitude;
	//double m_Latitude;
	//double m_Longitude;

	void parseGGAString(vector<string> nmeaTokens);
public:
	inline GGATag() : NMEATag(0)
	{ Reset(); }
	inline GGATag(vector<string> nmeaTokens,int line_number) : NMEATag(line_number)
	{
		Reset();
		parseGGAString(nmeaTokens);
	}
	// getters
	inline unsigned int	GetTime() const		{	return m_Time; }
	inline double	GetHDOP() const			{	return m_HDOP; }
	inline int		GetSatellites() const			{	return m_Satellites; }
private:
	// setters
	inline void		SetTime(unsigned int v)		{	m_Time=v; }
	inline void		SetHDOP(double v)		{	m_HDOP=v; }
	inline void		SetSatellites(int v)		{	m_Satellites=v; }
	inline void		Reset() {
		m_Time		= 0xffffffff;
		m_HDOP		= -1000.f;
		m_Satellites= -1;
	}

public:
	// queryers
	inline bool		HasTime() const		{	return (m_Time!=0xffffffff); }
	inline bool		HasHDOP() const		{	return (m_HDOP!=-1000.f); }
	inline bool		HasSatellites() const	{	return (m_Satellites!=-1); }
	inline bool		IsEmpty() const	{
		return (!HasTime()) && (!HasHDOP()) && (!HasSatellites());
	}



	inline bool		IsComplete() const
	{
		return HasTime() && HasHDOP();
	}
};

class GSATag : public NMEATag
{
private:
	vector<int> m_usedSats;
	int m_totalSnr;
	int m_snrCount;

	void parseGSAString(vector<string> nmeaTokens);
public:
	inline GSATag(): NMEATag(0)
	{ 
		//m_usedSats = vector<int>();
		Reset(); 
	}
	inline GSATag(vector<string> nmeaTokens,int line_number) : NMEATag(line_number)
	{
		Reset();
		parseGSAString(nmeaTokens);
	}
	// getters
	inline int		GetSatellitesCount() const			{	return m_usedSats.size(); }
	inline int		GetSatPrn(int index) const			{	return m_usedSats[index]; }
	inline int		GetTotalSnr() const					{	return m_totalSnr; }
	inline int		GetSnrCount() const					{	return m_snrCount; }
	inline vector<int>::iterator GetUsedSatsBegin()		{	return m_usedSats.begin(); }
	inline vector<int>::iterator GetUsedSatsEnd()		{	return m_usedSats.end(); }
	
	inline void		AddSnr(int snr)			{	m_totalSnr += snr; m_snrCount++;}
private:
	// setters
	inline void		AddSat(int prn)				{	m_usedSats.push_back(prn); }
	inline void		Reset() {
		m_usedSats.clear();
		m_totalSnr = 0;
		m_snrCount = 0;
	}
public:
	// queryers
	inline bool		HasSats() const		{	return m_usedSats.size() != 0; }
	inline bool		HasSnr() const		{	return m_totalSnr != 0; }
	inline bool		IsEmpty() const	{
		return (!HasSats()) && (!HasSnr());
	}
};

class GSVTag : NMEATag
{
private:
	unsigned int m_total_sentences;
	unsigned int m_sentence_number;
	unsigned int m_num_sats;

	map<int,int> m_satsSnr;

	void parseGSVString(vector<string> nmeaTokens);
public:
	inline GSVTag(vector<string> nmeaTokens,int line_number): NMEATag(line_number)
	{
		Reset();
		parseGSVString(nmeaTokens);
	}

	//inline GSVTag()
	//{
	//	//m_satsSnr = map<int,double>();
	//	Reset();
	//}
	//getters
	inline unsigned int		GetTotalSentences() const	{ return m_total_sentences; }
	inline unsigned int		GetSentenceNumber() const	{ return m_sentence_number; }
	inline unsigned int		GetNumSats() const			{ return m_num_sats; }
	inline double			GetSatSnr(int prn) const	{ return m_satsSnr.find(prn)->second; }
	inline map<int,int>::iterator GetSatSnrBegin()	{ return m_satsSnr.begin(); }
	inline map<int,int>::iterator GetSatSnrEnd()	{ return m_satsSnr.end(); }
private:
	//setters
	inline void		Reset()
	{
		m_total_sentences = 0;
		m_sentence_number = 0;
		m_num_sats = 0;
		m_satsSnr.clear();
	}
	inline void		AddSatSnr(int prn,int snr)		{ m_satsSnr.insert(make_pair<int,int>(prn,snr)); }
	inline void		SetSetenceNumber(unsigned int sn)	{ m_sentence_number = sn; }
	inline void		SetTotalSetences(unsigned int ts)	{ m_total_sentences = ts; }
	inline void		SetNumSats(unsigned int ns)			{ m_num_sats = ns; }
public:
	//queryers
	inline bool		HasSatsPrn() const			{ return m_satsSnr.size() != 0; }
	inline bool		HasSentenceNumber() const	{ return m_sentence_number != 0; }
	inline bool		HasTotalSentences() const	{ return m_total_sentences != 0; }
	inline bool		IsLastSentence() const		{ return m_sentence_number == m_total_sentences && HasSentenceNumber(); }
	inline bool		IsFirstSentence() const		{ return m_sentence_number == 1; }
	inline bool		IsEmpty() const
	{
		return (!HasSatsPrn()) && (!HasSentenceNumber()) && (!HasTotalSentences());
	}


};

class TagSet
{
private:
	unsigned int m_time;

	GGATag m_ggaTag;
	GSATag m_gsaTag;
	RMCTag m_rmcTag;

	//unsigned m_RMC:1;
	//unsigned m_GGA:1;
	//unsigned m_GSA:1;
	bool m_rmc:1;
	bool m_gga:1;
	bool m_gsa:1;

public:
	inline TagSet(unsigned int time)
	{ 
		m_time = time; 

		m_rmc = 0;
		m_gga = 0;
		m_gsa = 0;
	}
	//setters
	inline void AddGGATag(GGATag gga) 
	{ 
		m_ggaTag = gga; 
		m_gga = 1;
	}
	inline void AddGSATag(GSATag gsa)
	{ 
		m_gsaTag = gsa; 
		m_gsa = 1;
	}
	inline void AddRMCTag(RMCTag rmc) {
		m_rmcTag = rmc;
		m_rmc = 1;
	}
	//getters
	inline unsigned int		GetTime() const		{ return m_time; }
	inline GGATag			GetGGATag() const	{ return m_ggaTag; }
	inline GSATag			GetGSATag() const	{ return m_gsaTag; }
	inline RMCTag			GetRMCTag() const	{ return m_rmcTag; }
	//queryers
	inline bool HasGGATag() const	{ return m_gga; }
	inline bool HasGSATag() const	{ return m_gsa; }
	inline bool HasRMCTag() const	{ return m_rmc; }
};

class CCapabilities {
private:
	unsigned m_GPRMC:1;
	unsigned m_GPGGA:1;
//	unsigned m_GPVTG:1; //duplicate info
	unsigned m_GPGSA:1;
	unsigned m_GPGSV:1;
public:
	inline CCapabilities(): m_GPRMC(0), m_GPGGA(0),m_GPGSV(0) ,m_GPGSA(0) { }
	inline void SetGPRMC() { m_GPRMC=1; }
	inline void SetGPGGA() { m_GPGGA=1; }
	inline void SetGPGSA() { m_GPGSA=1; }
//	inline void SetGPVTG() { m_GPVTG=1; }
	inline void SetGPGSV() { m_GPGSV=1; }
	inline bool HasGPRMC() const { return (m_GPRMC!=0); }
	inline bool HasGPGGA() const { return (m_GPGGA!=0); }
	inline bool HasGPGSA() const { return (m_GPGSA!=0); }
//	inline bool HasGPVTG() const { return (m_GPVTG!=0); }
	inline bool HasGPGSV() const { return (m_GPGSV!=0); }
};


class NMEALoader
{
private:
	string filename;

	vector<TagSet> readedTags;
	map<int,int> satSnrHistory;
	Route route;

	void loadfile();
	void updateSatSnr(GSVTag gsv);

	inline int getSatSnr(int prn)
	{
		map<int,int>::iterator itr = satSnrHistory.find(prn);
		if (itr != satSnrHistory.end())
		{
			return itr->second;
		}
		return 0;
	}

	inline TagSet* LastTagSet()
	{
		return (readedTags.size() != 0)? &readedTags[readedTags.size()-1] : 0;
	}

public:
	inline Route getRoute() { return route; }
	NMEALoader(string file_name);// : filename(file_name),route(filename,true){}

	static double convertDegrees(double f);
	static double convertKnotsToMetersPerSecond(double v);

	~NMEALoader(void);
};

#endif // __NMEALoader_H__
