
#include "kml.h"
#include "util.h"
#include "geometry.h"
#include "GPSPoint.h"
#include <ctime>
#include <sstream>

namespace kmlMatch {

	KMLBuilder::KMLBuilder()
	{

	}

	KMLBuilder::KMLBuilder(mapRepresentation::Map * m, const std::string& filename)
	{
		map = m;

		std::ofstream fout(filename.c_str(), std::ios::out);

		fout.precision(12);
		fout.setf(ios::fixed, ios::floatfield);

		fout << "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>" << std::endl
			<< "<kml xmlns=\"http://earth.google.com/kml/2.0\">" << std::endl
			<< "<Document>" << std::endl;

		buildLightMap(fout);

		fout << "</Document>" << std::endl
			<< "</kml>" << std::endl;

		fout.close();
	}

	KMLBuilder::KMLBuilder(mapRepresentation::Map * m, Route * r, const std::vector<int>& match, const std::vector<pair<int, int> >& segments, const string& partialName)
	{
		map = m;
		route = r;
		this->partialName = partialName;
		this->match = match;
		this->segments = segments;
	}

	KMLBuilder::KMLBuilder(Route * r, vector<Route> * vecRoute, const std::string& filename)
	{
		std::ofstream fout(filename.c_str(), std::ios::out);

		fout.precision(12);
		fout.setf(ios::fixed, ios::floatfield);

		fout << "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>" << std::endl
			<< "<kml xmlns=\"http://earth.google.com/kml/2.0\">" << std::endl
			<< "<Document>" << std::endl;

		route = r;

		buildTrace(fout);

		for (int i = 0; i<vecRoute->size(); i++)
		{
			route = &vecRoute->at(i);
			buildTrace(fout);
		}

		fout << "</Document>" << std::endl
			<< "</kml>" << std::endl;

		fout.close();
	}

	KMLBuilder::KMLBuilder(const KMLBuilder& k)
	{
		map = k.map;
		route = k.route;
		match = k.match;
		partialName = k.partialName;
		segments = k.segments;
	}

	const KMLBuilder& KMLBuilder::operator =(const KMLBuilder& k)
	{
		if (this != &k)
		{
			map = k.map;
			route = k.route;
			match = k.match;
			partialName = k.partialName;
			segments = k.segments;
		}

		return *this;
	}

	void KMLBuilder::buildKML()
	{
		std::stringstream ss;

		if (partialName.size() > 0)
			ss << "data/match_" << partialName << "_" << route->getName() << ".kml";
		else
			ss << "data/match_" << route->getName() << ".kml";

		std::ofstream fout(ss.str().c_str(), std::ios::out);

		fout.precision(12);
		fout.setf(ios::fixed, ios::floatfield);


		fout << "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>" << std::endl
			<< "<kml xmlns=\"http://earth.google.com/kml/2.0\">" << std::endl
			<< "<Document>" << std::endl;

		//fout << "	<description><![CDATA[NMEA]]></description>" << std::endl;

		buildMap(fout);
		buildTrace(fout);
		buildMatched(fout);
		buildUnmatched(fout);
		buildSegments(fout);

		fout << "</Document>" << std::endl
			<< "</kml>" << std::endl;

		fout.close();
	}

	void KMLBuilder::buildMap(std::ofstream& fout)
	{
		int i;
		position pos, pos2;
		std::map<int, mapRepresentation::mLink>::iterator it;
		std::map<unsigned int, mapRepresentation::mEdges>::iterator git;
		std::set<int>::iterator sit;

		fout << "	<Folder id=\"MAP\">" << std::endl
			<< "		<name>Map</name>" << std::endl
			<< "		<visibility>1</visibility>" << std::endl
			<< "		<open>0</open>" << std::endl;

		fout << "		<Folder id=\"MAPNODES\">" << std::endl
			<< "			<name>Nodes</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl
			<< "			<Style id=\"nodeMapIcon\">" << std::endl
			<< "				<IconStyle>" << std::endl
			<< "					<Icon><href>http://maps.google.com/mapfiles/kml/shapes/square.png</href></Icon>" << std::endl
			<< "					<scale>0.50</scale>" << std::endl
			<< "				</IconStyle>" << std::endl
			<< "			</Style>" << std::endl;

		for (git = map->graph.begin(); git != map->graph.end(); git++)
		{
			pos = map->getNodePosition(git->first);

			fout << "			<Placemark>" << std::endl
				<< "				<description>" << std::endl
				<< "					<br/>xy: " << pos.longitude << "," << pos.latitude << "<br/>" << std::endl
				<< "				</description>" << std::endl
				<< "				<styleUrl>#nodeMapIcon</styleUrl>" << std::endl
				<< "				<LookAt>" << std::endl
				<< "					<longitude>" << pos.longitude << "</longitude>" << std::endl
				<< "					<latitude>" << pos.latitude << "</latitude>" << std::endl
				<< "					<range>50.0</range>" << std::endl
				<< "					<tilt>0.0</tilt>" << std::endl
				<< "				</LookAt>" << std::endl
				<< "				<Point>" << std::endl
				<< "					<coordinates>" << pos.longitude << "," << pos.latitude << ",0</coordinates>" << std::endl
				<< "				</Point>" << std::endl
				<< "			</Placemark>" << std::endl;
		}

		fout << "		</Folder>" << std::endl;


		fout << "		<Folder id=\"MAPLINKS\">" << std::endl
			<< "			<name>Links</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl;

		for (it = map->links.begin(); it != map->links.end(); it++)
		{
			pos = map->getNodePosition(it->second.orID);
			pos2 = map->getNodePosition(it->second.destID);

			fout << "			<Placemark>" << std::endl
				<< "				<description>" << std::endl
				<< "					<br/>Link : " << it->first << "<br/>Heading: " << rad2deg(map->links[it->first].heading) << "<br/>" << std::endl
				<< "				</description>" << std::endl
				<< "				<name>" << "Link: " << it->first << "</name>" << std::endl
				<< "				<Style>" << std::endl
				<< "					<LineStyle>" << std::endl
				<< "						<color>ff" << "ffffff" << "</color>" << std::endl
				<< "						<width>4</width>" << std::endl
				<< "					</LineStyle>" << std::endl
				<< "				</Style>" << std::endl
				<< "				<LineString>" << std::endl
				<< "					<tessellate>0</tessellate>" << std::endl
				<< "					<altitudeMode>clampedToGround</altitudeMode>" << std::endl
				<< "					<coordinates>" << std::endl
				<< "						" << pos.longitude << "," << pos.latitude << ",0" << std::endl
				<< "						" << pos2.longitude << "," << pos2.latitude << ",0" << std::endl
				<< "					</coordinates>" << std::endl
				<< "				</LineString>" << std::endl
				<< "			</Placemark>" << std::endl;
		}

		fout << "		</Folder>" << std::endl;

		fout << "		<Folder id=\"MAPLINKSINFO\">" << std::endl
			<< "			<name>LinkInfo</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl;

		for (it = map->links.begin(); it != map->links.end(); it++)
			fout << builLinkInfo(it->first);

		fout << "		</Folder>" << std::endl;		

		fout << "   </Folder>" << std::endl;
	}

	void KMLBuilder::buildLightMap(std::ofstream& fout)
	{
		position pos, pos2;
		std::map<int, mapRepresentation::mLink>::iterator it;
		std::map<unsigned int, mapRepresentation::mEdges>::iterator git;
		std::set<int>::iterator sit, lit;
		std::set<int> ilinks;

		fout << "	<Folder id=\"MAP\">" << std::endl
			<< "		<name>Map</name>" << std::endl
			<< "		<visibility>1</visibility>" << std::endl
			<< "		<open>0</open>" << std::endl;

		/*fout << "		<Folder id=\"MAPNODES\">" << std::endl
			<< "			<name>Nodes</name>" << std::endl
			<< "			<visibility>0</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl
			<< "			<Style id=\"nodeMapIcon\">" << std::endl
			<< "				<IconStyle>" << std::endl
			<< "					<Icon><href>http://maps.google.com/mapfiles/kml/shapes/square.png</href></Icon>" << std::endl
			<< "					<scale>0.50</scale>" << std::endl
			<< "				</IconStyle>" << std::endl
			<< "			</Style>" << std::endl;

		for (git = map->graph.begin(); git != map->graph.end(); git++)
		{
			pos = map->getNodePosition(git->first);

			fout << "			<Placemark>" << std::endl
				<< "				<description>" << std::endl
				<< "					<br/>xy: " << pos.longitude << "," << pos.latitude << "<br/>" << std::endl
				<< "				</description>" << std::endl
				<< "				<styleUrl>#nodeMapIcon</styleUrl>" << std::endl
				<< "				<LookAt>" << std::endl
				<< "					<longitude>" << pos.longitude << "</longitude>" << std::endl
				<< "					<latitude>" << pos.latitude << "</latitude>" << std::endl
				<< "					<range>50.0</range>" << std::endl
				<< "					<tilt>0.0</tilt>" << std::endl
				<< "				</LookAt>" << std::endl
				<< "				<Point>" << std::endl
				<< "					<coordinates>" << pos.longitude << "," << pos.latitude << ",0</coordinates>" << std::endl
				<< "				</Point>" << std::endl
				<< "			</Placemark>" << std::endl;
		}

		fout << "		</Folder>" << std::endl;*/

		fout << "		<Folder id=\"MAPLINKS\">" << std::endl
			<< "			<name>Links</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl;

		for (it = map->links.begin(); it != map->links.end(); it++)
		{
			pos = map->getNodePosition(it->second.orID);
			pos2 = map->getNodePosition(it->second.destID);

			fout << "			<Placemark>" << std::endl
				<< "				<description>" << std::endl
				<< "					<br/>Link : " << it->first << "<br/>Heading: " << rad2deg(map->links[it->first].heading) << "<br/>" << std::endl
				<< "				</description>" << std::endl
				<< "				<name>" << "Link: " << it->first << "</name>" << std::endl
				<< "				<Style>" << std::endl
				<< "					<LineStyle>" << std::endl
				<< "						<color>ff" << "ffffff" << "</color>" << std::endl
				<< "						<width>4</width>" << std::endl
				<< "					</LineStyle>" << std::endl
				<< "				</Style>" << std::endl
				<< "				<LineString>" << std::endl
				<< "					<tessellate>0</tessellate>" << std::endl
				<< "					<altitudeMode>clampedToGround</altitudeMode>" << std::endl
				<< "					<coordinates>" << std::endl
				<< "						" << pos.longitude << "," << pos.latitude << ",0" << std::endl
				<< "						" << pos2.longitude << "," << pos2.latitude << ",0" << std::endl
				<< "					</coordinates>" << std::endl
				<< "				</LineString>" << std::endl
				<< "			</Placemark>" << std::endl;
		}

		fout << "		</Folder>" << std::endl;

		ilinks = getLinksToDraw();

		fout << "		<Folder id=\"MAPLINKSINFO\">" << std::endl
			<< "			<name>LinkInfo</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl;

		for (lit = ilinks.begin(); lit != ilinks.end(); lit++)
			fout << builLinkInfo(*lit);

		fout << "		</Folder>" << std::endl;		

		fout << "   </Folder>" << std::endl;
	}

	void KMLBuilder::buildTrace(std::ofstream& fout)
	{
		int i;
		time_t t;

		fout << "	<Folder id=\"TRACE\">" << std::endl
			<< "		<name>Trace</name>" << std::endl
			<< "		<visibility>1</visibility>" << std::endl
			<< "		<open>0</open>" << std::endl;

		fout << "		<Folder id=\"TRACELINKS\">" << std::endl
			<< "			<name>Links</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl;

		fout << "			<Placemark>" << std::endl
			<< "				<name>" << "Trace" << "</name>" << std::endl
			<< "				<Style>" << std::endl
			<< "					<LineStyle>" << std::endl
			<< "						<color>ff" << "ff00ff" << "</color>" << std::endl
			<< "						<width>4</width>" << std::endl
			<< "					</LineStyle>" << std::endl
			<< "				</Style>" << std::endl
			<< "				<LineString>" << std::endl
			<< "					<tessellate>0</tessellate>" << std::endl
			<< "					<altitudeMode>clampedToGround</altitudeMode>" << std::endl
			<< "					<coordinates>" << std::endl;

		for (i=0; i<route->size(); i++)
			fout << "						" << route->getLongitude(i) << "," << route->getLatitude(i) << ",0" << std::endl;

		fout << "					</coordinates>" << std::endl
			<< "				</LineString>" << std::endl
			<< "			</Placemark>" << std::endl
			<< "		</Folder>" << std::endl;


		fout << "		<Folder id=\"TRACENODES\">" << std::endl
			<< "			<name>Nodes</name>" << std::endl
			<< "			<visibility>1</visibility>" << std::endl
			<< "			<open>0</open>" << std::endl;

		for (i=0; i<route->size(); i++)
		{
			fout << route->pointToKml(i);

			/*t = (time_t)route->getTime(i);

			fout << "			<Placemark>" << std::endl
				<< "				<description>" << i << std::endl
				<< "					<br/>xy: " << route->getLongitude(i) << "," << route->getLatitude(i) << std::endl
				<< "					<br/>Heading: " << rad2deg(route->getHeading(i)) << std::endl
				<< "					<br/>Speed: " << route->getSpeed(i) << std::endl
				<< "					<br/>Date: " << ctime(&t)
				<< "				</description>" << std::endl
				<< "				<Style>" << std::endl
				<< "					<IconStyle>" << std::endl
				<< "						<Icon><href>http://maps.google.com/mapfiles/kml/shapes/arrow.png</href></Icon>" << std::endl
				<< "						<scale>0.50</scale>" << std::endl
				<< "						<heading>" << rad2deg(route->getHeading(i))+180 << "</heading>" << std::endl
				<< "					</IconStyle>" << std::endl
				<< "				</Style>" << std::endl
				<< "				<LookAt>" << std::endl
				<< "					<longitude>" << route->getLongitude(i) << "</longitude>" << std::endl
				<< "					<latitude>" << route->getLatitude(i) << "</latitude>" << std::endl
				<< "					<range>50.0</range>" << std::endl
				<< "					<tilt>0.0</tilt>" << std::endl
				<< "				</LookAt>" << std::endl
				<< "				<Point>" << std::endl
				<< "					<coordinates>" << route->getLongitude(i) << "," << route->getLatitude(i) << ",0</coordinates>" << std::endl
				<< "				</Point>" << std::endl
				<< "			</Placemark>" << std::endl;*/
		}

		fout << "		</Folder>" << std::endl
			<< "	</Folder>" << std::endl;
	}

	void KMLBuilder::buildMatched(std::ofstream& fout)
	{
		int i;
		position pos;
		std::pair<Point, double> res;

		fout << "	<Folder id=\"MATCH\">" << std::endl
			<< "		<name>Match</name>" << std::endl
			<< "		<visibility>1</visibility>" << std::endl
			<< "		<open>0</open>" << std::endl;

		for (i=0; i<match.size(); i++)
		{
			if (match[i] >= 0)
			{
				res = getNearestPointFromLink(Point(map->nodes[map->links[match[i]].orID].longm, map->nodes[map->links[match[i]].orID].latm),
					Point(map->nodes[map->links[match[i]].destID].longm, map->nodes[map->links[match[i]].destID].latm),
					Point(route->getLongitudeM(i), route->getLatitudeM(i)));

				pos = map->getNodePosition(map->links[match[i]].destID);

				GPSPoint g(GPSPoint::convertUTMToWGS84(res.first.getX(), res.first.getY(), GPSPoint::getZone(pos.longitude), GPSPoint::getLatZone(pos.latitude)));

				fout << "		<Placemark>" << std::endl
					<< "			<description>" << std::endl
					<< "					<br/>Trace Point: " << i << "<br/>Map Link: " << match[i] << "<br/>" << std::endl
					<< "			</description>" << std::endl
					<< "			<name>" << "Match: " << i << "</name>" << std::endl
					<< "			<Style>" << std::endl
					<< "				<LineStyle>" << std::endl
					<< "					<color>ff" << "ff0000" << "</color>" << std::endl
					<< "					<width>4</width>" << std::endl
					<< "				</LineStyle>" << std::endl
					<< "			</Style>" << std::endl
					<< "			<LineString>" << std::endl
					<< "				<tessellate>0</tessellate>" << std::endl
					<< "				<altitudeMode>clampedToGround</altitudeMode>" << std::endl
					<< "				<coordinates>" << std::endl
					<< "					" << route->getLongitude(i) << "," << route->getLatitude(i) << ",0" << std::endl
					<< "					" << g.lon << "," << g.lat << ",0" << std::endl
					<< "				</coordinates>" << std::endl
					<< "			</LineString>" << std::endl
					<< "		</Placemark>" << std::endl;
			}
		}

		fout << "	</Folder>" << std::endl;
	}

	void KMLBuilder::buildUnmatched(std::ofstream& fout)
	{
		int i;
		time_t t;

		fout << "	<Folder id=\"UNMATCH\">" << std::endl
			<< "		<name>Unmatch</name>" << std::endl
			<< "		<visibility>1</visibility>" << std::endl
			<< "		<open>0</open>" << std::endl
			<< "		<Style id=\"unmatchIcon\">" << std::endl
			<< "			<IconStyle>" << std::endl
			<< "				<Icon><href>http://maps.google.com/mapfiles/kml/pal3/icon59.png</href></Icon>" << std::endl
//			<< "				<Icon><href>http://maps.google.com/mapfiles/kml/shapes/caution.png</href></Icon>" << std::endl
			<< "				<scale>0.55</scale>" << std::endl
			<< "			</IconStyle>" << std::endl
			<< "		</Style>" << std::endl;

		for (i=0; i<match.size(); i++)
		{
			if (match[i] < 0)
			{
				t = (time_t)route->getArrivalTime(i);

				fout << "			<Placemark>" << std::endl
					<< "				<description>" << i << std::endl
					<< "					<br/>xy: " << route->getLongitude(i) << "," << route->getLatitude(i) << std::endl
					<< "					<br/>Heading: " << rad2deg(route->getHeading(i)) << std::endl
					<< "					<br/>Speed: " << route->getSpeed(i) << std::endl
					<< "					<br/>Date: " << ctime(&t)
					<< "				</description>" << std::endl
					<< "				<styleUrl>#unmatchIcon</styleUrl>" << std::endl
					<< "				<LookAt>" << std::endl
					<< "					<longitude>" << route->getLongitude(i) << "</longitude>" << std::endl
					<< "					<latitude>" << route->getLatitude(i) << "</latitude>" << std::endl
					<< "					<range>50.0</range>" << std::endl
					<< "					<tilt>0.0</tilt>" << std::endl
					<< "				</LookAt>" << std::endl
					<< "				<Point>" << std::endl
					<< "					<coordinates>" << route->getLongitude(i) << "," << route->getLatitude(i) << ",0</coordinates>" << std::endl
					<< "				</Point>" << std::endl
					<< "			</Placemark>" << std::endl;
			}
		}

		fout << "	</Folder>" << std::endl;
	}

	void KMLBuilder::buildSegments(std::ofstream& fout)
	{
		int i;

		fout << "	<Folder id=\"SEGMENTS\">" << std::endl
			<< "		<name>Segments</name>" << std::endl
			<< "		<visibility>1</visibility>" << std::endl
			<< "		<open>0</open>" << std::endl
			<< "		<Style id=\"flexSegIcon\">" << std::endl
			<< "			<IconStyle>" << std::endl
			<< "				<Icon><href>http://maps.google.com/mapfiles/kml/paddle/blu-blank.png</href></Icon>" << std::endl
			<< "				<scale>0.70</scale>" << std::endl
			<< "			</IconStyle>" << std::endl
			<< "		</Style>" << std::endl;

		for (i=0; i<(int)segments.size()-1; i++)
		{
			GPSPoint g(GPSPoint::convertUTMToWGS84((route->getLongitudeM(segments[i].second)+route->getLongitudeM(segments[i].second+1))/2,
				(route->getLatitudeM(segments[i].second)+route->getLatitudeM(segments[i].second+1))/2,
				GPSPoint::getZone(route->getLongitude(segments[i].second)),
				GPSPoint::getLatZone(route->getLatitude(segments[i].second))));

			fout << "		<Placemark>" << std::endl
				<< "			<description>" << i << std::endl
				<< "				<br/>Break between point: " << segments[i].second << " and " << segments[i].second+1 << std::endl
				<< "			</description>" << std::endl
				<< "			<styleUrl>#flexSegIcon</styleUrl>" << std::endl
				<< "			<LookAt>" << std::endl
				<< "				<longitude>" << g.lon << "</longitude>" << std::endl
				<< "				<latitude>" << g.lat << "</latitude>" << std::endl
				<< "				<range>50.0</range>" << std::endl
				<< "				<tilt>0.0</tilt>" << std::endl
				<< "			</LookAt>" << std::endl
				<< "			<Point>" << std::endl
				<< "				<coordinates>" << g.lon << "," << g.lat << ",0</coordinates>" << std::endl
				<< "			</Point>" << std::endl
				<< "		</Placemark>" << std::endl;
		}

		fout << "	</Folder>" << std::endl;
	}

	std::string KMLBuilder::builLinkInfo(int linkID)
	{
		ostringstream oss (ostringstream::out);
		mapRepresentation::mLink l = map->getLink(linkID);
		mapRepresentation::mNode o = map->getNode(l.orID);
		mapRepresentation::mNode d = map->getNode(l.destID);

		oss.precision(12);
		oss.setf(ios::fixed, ios::floatfield);

		GPSPoint g(GPSPoint::convertUTMToWGS84((d.longm + o.longm)/2, (d.latm + o.latm)/2,	
			GPSPoint::getZone(o.longitude), GPSPoint::getLatZone(o.latitude)));

		oss << "			<Placemark>" << std::endl
			<< "				<description>" << std::endl
			<< "					<br/>Link: " << linkID << "<br/>Heading: " << rad2deg(l.heading) << "<br/>" << std::endl
			<< "					Length: " << l.length << " m.<br/>Pass Count: " << l.match_count << "<br/>" << std::endl
			<< "				</description>" << std::endl
			<< "				<Style>" << std::endl
			<< "					<IconStyle>" << std::endl
			<< "						<Icon><href>http://maps.google.com/mapfiles/kml/shapes/arrow.png</href></Icon>" << std::endl
			<< "						<scale>0.40</scale>" << std::endl
			<< "						<heading>" << rad2deg(l.heading)+180 << "</heading>" << std::endl
			<< "					</IconStyle>" << std::endl
			<< "				</Style>" << std::endl
			<< "				<LookAt>" << std::endl
			<< "					<longitude>" << g.lon << "</longitude>" << std::endl
			<< "					<latitude>" << g.lat << "</latitude>" << std::endl
			<< "					<range>50.0</range>" << std::endl
			<< "					<tilt>0.0</tilt>" << std::endl
			<< "				</LookAt>" << std::endl
			<< "				<Point>" << std::endl
			<< "					<coordinates>" << g.lon << "," << g.lat << ",0</coordinates>" << std::endl
			<< "				</Point>" << std::endl
			<< "			</Placemark>" << std::endl;

		return oss.str();
	}

	std::set<int> KMLBuilder::getLinksToDraw()
	{
		std::set<int> ilinks;
		std::vector<int> path, temp;
		std::set<int> usedLinks;
		std::map<unsigned int, mapRepresentation::mEdges>::iterator it;
		std::set<unsigned int> nodes;
		std::set<int>::iterator sit, sit2;
		mapRepresentation::mEdges e;

		for (it = map->graph.begin(); it != map->graph.end(); it++)
		{
			if (it->second.predecessors.size() > 1 || it->second.successors.size() > 1)
			{
				e = (*it).second;

				for (sit = e.successors.begin(); sit != e.successors.end(); sit++)
				{
					sit2 = usedLinks.find(*sit);

					if (sit2 == usedLinks.end())
					{
						usedLinks.insert(*sit);

						temp = selectLinksFromPath(navigateForward(*sit));

						ilinks.insert(temp.begin(), temp.end());
					}
				}
	
				for (sit = e.predecessors.begin(); sit != e.predecessors.end(); sit++)
				{
					path = navigateBackward(*sit);

					sit2 = usedLinks.find(path.back());

					if (sit2 == usedLinks.end())
					{
						usedLinks.insert(path.back());

						temp = selectLinksFromPath(path);

						ilinks.insert(temp.begin(), temp.end());
					}
				}
			}
		}

		return ilinks;
	}

	std::vector<int> KMLBuilder::navigateForward(int link)
	{
		std::vector<int> temp;
		mapRepresentation::mEdges e;

		temp.push_back(link);

		e = map->getEdges(map->getLink(link).destID);		

		while (e.predecessors.size() == 1 && e.successors.size() == 1)
		{
			link = *e.successors.begin();

			temp.push_back(link);

			e = map->getEdges(map->getLink(link).destID);
		}

		return temp;
	}


	
	std::vector<int> KMLBuilder::navigateBackward(int link)
	{
		std::vector<int> temp;
		mapRepresentation::mEdges e;

		temp.push_back(link);

		e = map->getEdges(map->getLink(link).orID);		

		while (e.predecessors.size() == 1 && e.successors.size() == 1)
		{
			link = *e.predecessors.begin();

			temp.push_back(link);

			e = map->getEdges(map->getLink(link).orID);
		}

		return temp;
	}

	std::vector<int> KMLBuilder::selectLinksFromPath(const std::vector<int>& path)
	{
		int i, delta;
		std::vector<int> finalLinks;

		if (path.size() < 10)
			delta = 3;
		else if (path.size() < 20)
			delta = 4;
		else if (path.size() < 100)
			delta = 10;
		else
			delta = 30;

		for (i=0; i<path.size(); i+=delta)
			finalLinks.push_back(path[i]);


		if (((int)path.size() - (i - delta) > 4) || path.size() == 2 || path.size() == 3)
			finalLinks.push_back(path.back());
		else
			finalLinks.back() = path.back();

		return finalLinks;
	}
}
