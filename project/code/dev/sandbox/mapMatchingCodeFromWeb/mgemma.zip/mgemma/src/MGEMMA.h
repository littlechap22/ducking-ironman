#ifndef __MGEMMA_H__
#define __MGEMMA_H__

#include "util.h"
#include "maps.h"
#include "route.h"
#include "path.h"
#include "matching_marchal.h"
#include "matching_genetic.h"
#include "kml.h"
#include <algorithm>
#include <sstream>


namespace MapMatching {

	class MGEMMA {

	public:
		MGEMMA(mapRepresentation::Map * map, Route * route, bool log=false);
		~MGEMMA();

		void run(bool generateKML=false);

		std::vector<Path *> getMatched();
		std::vector<Path *> getShortMatched();
		std::vector<unMatchInfo *> getUnmatchedInfo();


	private:
		MGEMMA();
		MGEMMA(const MGEMMA& m);
		const MGEMMA& operator=(const MGEMMA& m);

		mapRepresentation::Map * map;
		Route * route;
		std::ofstream * out;

		std::vector<mapRepresentation::LinkKey> trace;
		geneticParameters params;
		std::vector<Path *> matchedTraces;
		std::vector<Path *> shortMatchedTraces;
		std::vector<unMatchInfo *> unmatchInfo;


		std::vector<int> reconstructMatchedTrace(std::vector<std::set<mapRepresentation::LinkKey> > * candidates, std::vector<Path *>& forwardsMatchedParts, std::vector<Path *>& backwardsMatchedParts);
		std::vector<std::pair<int, int> > buildAmbiguousSegments(std::vector<int>& criticalPoints);
		std::set<int> runGeneticOnAmbiguousSegments(const std::vector<std::pair<int, int> >& segments, std::vector<std::set<mapRepresentation::LinkKey> > * candidates);
		std::set<int> runSegment(int startPoint, int endPoint, std::vector<std::set<mapRepresentation::LinkKey> > * candidates);
		void constructOutput(std::set<int>& gaps, const std::vector<Path *>& paths, const std::vector<std::pair<int, int> >& segments);
	};
}

#endif // __MGEMMA_H__
