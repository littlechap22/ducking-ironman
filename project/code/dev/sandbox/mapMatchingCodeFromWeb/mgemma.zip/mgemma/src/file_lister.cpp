#include "file_lister.h"

#ifdef FILE_LISTER_POSIX

#include <dirent.h>


std::vector<std::string> getFiles(const std::string& path)
{
	size_t found;
	DIR * handle;
	dirent * entry;
	std::string name, nPath;
	std::vector<std::string> files;

	if (path.empty())
		nPath = ".";
	else
		nPath = path;

	handle = opendir(nPath.c_str());

	if (!handle)
		return files;

	nPath = path;

	if (!nPath.empty() && nPath[nPath.size()-1] != '/')
		nPath += "/";

	entry = readdir(handle);

	while (entry)
	{
		name = entry->d_name;

		if (name != "." && name != "..")
		{
			found = name.find_last_of(".");

			if (found != std::string::npos && name.substr(found) == ".txt")
				files.push_back((nPath + name));
		}

		entry = readdir(handle);
	}

	closedir(handle);

	return files;
}

#elif defined(FILE_LISTER_WINDOWS)

#define WIN32_LEAN_AND_MEAN

#include <tchar.h>
#include <windows.h>


std::vector<std::string> getFiles(const std::string& path)
{	
	size_t found;
	WIN32_FIND_DATA data;
	HANDLE hFind;
	BOOL cont = TRUE;
	TCHAR cPath[MAX_PATH+1];
	char filename[MAX_PATH+1];
	std::string nPath, name;
	std::vector<std::string> files;

	nPath = path;

	if (nPath.size() > 0 && nPath[nPath.size()-1] != '\\')
		nPath += "\\";
	else if (path == "\\")
		nPath = "";

	nPath += "*";

	memset(cPath, 0, (nPath.size()+1)*sizeof(TCHAR));
	::MultiByteToWideChar(CP_ACP, NULL, nPath.c_str(), -1, cPath, (int)nPath.size());

	//_tprintf(TEXT("%s\r\n"), cPath);

	hFind = FindFirstFile(cPath, &data);

	if (hFind == INVALID_HANDLE_VALUE)
		return files;

	nPath = path;

	if (nPath.size() > 0 && nPath[nPath.size()-1] != '\\')
		nPath += "\\";
	else if (path == "\\")
		nPath = "";

	while (hFind && cont)
	{
		//_tprintf(TEXT("%s\r\n"), data.cFileName);

		memset(filename, '\0', MAX_PATH+1);
		::WideCharToMultiByte(CP_ACP, NULL, data.cFileName, -1, filename, (int)_tcslen(data.cFileName), NULL, NULL);

		name = std::string(filename);

		if (name != "." && name != "..")
		{
			found = name.find_last_of(".");

			if (found != std::string::npos && name.substr(found) == ".txt")
				files.push_back((nPath + name));
		}

		cont = FindNextFile(hFind, &data);
	}	

	FindClose(hFind);

	return files;
}


#elif defined(FILE_LISTER_NOT_SUPPORTED)

std::vector<std::string> getFiles(const std::string& path)
{
	return std::vector<std::string>();
}

#endif
