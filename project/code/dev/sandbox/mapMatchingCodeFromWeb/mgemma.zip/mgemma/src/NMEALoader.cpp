
#include "NMEALoader.h"
#include "geometry.h"
#include "GPSPoint.h"
#include <cstring>
#include <iostream>
#include <fstream>
#include <sstream>


NMEALoader::NMEALoader(string file_name) : filename(file_name)//,route(filename,true)
{
	route.setOriginalFilename(file_name);
	loadfile();
}

NMEALoader::~NMEALoader(void)
{
}

//struct SPosition {
//	SPosition(): longitude(.0f), latitude(.0f), azimuth(.0f), speed(.0f), dop(.0f), timestamp(0), validity(false), datestamp(0) { }
//	SPosition(const SPosition& o): longitude(o.longitude), latitude(o.latitude), azimuth(o.azimuth), speed(o.speed), dop(o.dop), timestamp(o.timestamp), validity(o.validity), datestamp(o.datestamp) { }
//	float longitude;
//	float latitude;
//	float azimuth;
//	float speed;
//	float dop;
//	unsigned int timestamp;
//	bool validity;
//	unsigned int datestamp;
//};


// 1 knot = 0.514444444444 m/s
double NMEALoader::convertKnotsToMetersPerSecond(double v) {
	return v* 0.5144444444444444;
}

// Convert NMEA angles to decimal degrees
double NMEALoader::convertDegrees(double f) {
	int degrees = (int)(f/100.0);
	double minutes = f - degrees*100.0;
	minutes = ((minutes*100.0)/6000.0);
	f = degrees + minutes;
	return f;
}

void NMEALoader::loadfile()
{
	CCapabilities caps;
	//CGPRMC	lastGPRMC;
	//CGPGGA	lastGPGGA;
	//CGPGSA  lastGPGSA;
	//CGPGSV	lastGPGSV;
	//rNode lastPosition;
	//std::vector<rNode> positions;

	cout << "loading nmea file: " << filename << endl;

	std::ifstream ifs(filename.c_str());
	if (!ifs.is_open()) return;
	char line[512];

	//std::vector<std::string> fields;
	//std::string currentFrame;

	int lineCount = 0;
	while (ifs.good()) {
		ifs.getline(line,512, '\n');
		lineCount++;
		std::string sline(line);
		size_t trim=0;
		while((trim=sline.find("\r"))!=std::string::npos) sline.erase(trim,1);

		//cout << "line: " << ++lineCount << ": " << sline << endl;


		vector<string> tokens;

		size_t begin=0;
		size_t end=0;
		while(begin < sline.length())
		{
			end=sline.find(",",begin);
			if (end==std::string::npos) end=sline.length();
			tokens.push_back(sline.substr(begin,end-begin));

			begin=end+1;
		}

		if (tokens.size() == 0)
			continue;

		if (tokens[0].compare("$GPRMC")==0)
		{
			RMCTag rmc(tokens,lineCount);
			if (rmc.IsComplete())
			{
				//cout << "RMC tag complete: " << rmc.GetTime() << " conditions: size " << (this->readedTags.size() == 0);
				//if (this->readedTags.size() > 0)
				//	cout << "\ttime " << (this->LastTagSet()->GetTime() != rmc.GetTime()) << endl;
				//else
				//	cout << endl;
				if (this->readedTags.size() == 0 || this->LastTagSet()->GetTime() != rmc.GetTime())
					//&& rmc.IsComplete())
				{
					TagSet tagSet(rmc.GetTime());
					tagSet.AddRMCTag(rmc);
					readedTags.push_back(tagSet);
				}
				else
				{
					TagSet* tagSet = this->LastTagSet();
					tagSet->AddRMCTag(rmc);
				}
				caps.SetGPRMC();
			}
			//else
			//{
			//	cout << "line[" << lineCount << "]: rmcTag incomplete" << endl;
			//}
			//if (rmc.IsComplete())
			
		}
		else if (tokens[0].compare("$GPGGA")==0)
		{
			GGATag gga(tokens,lineCount);
			if (gga.IsComplete())
			{
				//cout << "GGA tag complete: " << gga.GetTime() << " conditions: size " << (this->readedTags.size() == 0);
				//if (this->readedTags.size() > 0)
				//	cout << "\ttime " << (this->LastTagSet()->GetTime() != gga.GetTime()) << endl;
				//else
				//	cout << endl;
				if (this->readedTags.size() == 0 || this->LastTagSet()->GetTime() != gga.GetTime())
					//&& gga.IsComplete())
				{
					TagSet tagSet(gga.GetTime());
					tagSet.AddGGATag(gga);
					readedTags.push_back(tagSet);
				}
				else
				{
					TagSet* tagSet = this->LastTagSet();
					tagSet->AddGGATag(gga);

				}
				caps.SetGPGGA();
			}
			//else
			//{
			//	cout << "line[" << lineCount << "]: ggaTag incomplete" << endl;
			//}
		}
		else if (tokens[0].compare("$GPGSA")==0)
		{
			GSATag gsa(tokens,lineCount);

			if (caps.HasGPGSV() && !gsa.IsEmpty())
			{
				//ir buscar os snrs a lista e somar para 
				vector<int>::iterator itr;
				int snrCount = 0;
				for (itr = gsa.GetUsedSatsBegin(); itr != gsa.GetUsedSatsEnd(); itr++)
				{
					gsa.AddSnr(this->getSatSnr(*itr));
					snrCount++;
				}
			}
			if (!gsa.IsEmpty())
			{
				if (this->readedTags.size() > 0)
					//&& !gsa.IsEmpty())
				{
					this->LastTagSet()->AddGSATag(gsa);
				}
				//if (!gsa.IsEmpty())
				caps.SetGPGSA();			
			}
			//else
			//{
			//	cout << "line[" << lineCount << "]: gsaTag empty" << endl;
			//}
		}
		else if (tokens[0].compare("$GPGSV")==0)
		{
			GSVTag gsv(tokens,lineCount);
			//if (gsv.IsFirstSentence())
				//reset satSnrHistory?
			if (!gsv.IsEmpty())
			{
				caps.SetGPGSV();
				this->updateSatSnr(gsv);
			}
			//else
			//{
			//	cout << "line[" << lineCount << "]: gsvTag empty" << endl;
			//}
		}
	}

	//cout << "Collected " << readedTags.size() << " tagSets." << endl;
	//cout << "Caps ->\trmc: " << caps.HasGPRMC() << "\tgga: " << caps.HasGPGGA() << "\tgsa: " << caps.HasGPGSA() << endl;

	int i = 0;
	for (vector<TagSet>::iterator itr = readedTags.begin(); itr != readedTags.end(); itr++)
	{
		RMCTag rmc(itr->GetRMCTag());
		GSATag gsa(itr->GetGSATag());
		GGATag gga(itr->GetGGATag());
		if ( (rmc.IsComplete() || !caps.HasGPRMC())
			&& (gga.IsComplete() || !caps.HasGPGGA())
			&& (!gsa.IsEmpty() || !caps.HasGPGSA() || !caps.HasGPGSV()))
		{
			rNode node;
			node.leaveTime = node.arrivalTime = rmc.GetDateTime();
			node.lat = rmc.GetLatitude();
			node.lon = rmc.GetLongitude();
			GPSPoint point(GPSPoint::convertWGS84ToUTM(node.lat,node.lon));
			node.latm = point.latm;
			node.lonm = point.longm;

			node.heading = rmc.GetAzimuth();
			node.speed = rmc.GetSpeed();
			node.validity = rmc.GetValidity();
			node.dop = gga.GetHDOP();
			node.avgSnr = (1.0 * gsa.GetTotalSnr()) / (1.0 * gsa.GetSnrCount());

			route.addNode(node);
		}
		else
		{
			cout << "TagSet incomplete[" << i << "]: time " << itr->GetTime() << endl
				<< "\trmc[" << rmc.GetTime()<< "]: " <<  rmc.IsComplete() << "[" << rmc.getLineNumber() << "]" << endl
				<< "\tgga[" << gga.GetTime()<< "]: " << gga.IsComplete() << "[" << gga.getLineNumber() << "]"<< endl
				<< "\tgsa: " << (!gsa.IsEmpty()) << "[" << gsa.getLineNumber() << "]" << endl;
		}
		i++;
	}

	//cout << "Route created with " << route.size() << " nodes." << endl;
}

void NMEALoader::updateSatSnr(GSVTag gsv)
{
	for (map<int,int>::iterator itr = gsv.GetSatSnrBegin(); itr != gsv.GetSatSnrEnd(); itr++)
	{
		map<int,int>::iterator historyItr =	satSnrHistory.find(itr->first);
		if (historyItr == satSnrHistory.end())
		{
			satSnrHistory.insert(make_pair<int,int>(itr->first,itr->second));
		}
		else
		{
			historyItr->second = itr->second;
		}
	}
}

void GGATag::parseGGAString(vector<string> nmeaTokens)
{
	if (nmeaTokens.size() < 9)
		return;

	if (!nmeaTokens[1].empty()) { // Time
		std::stringstream stream(nmeaTokens[1]);
		double v; stream>>v;
		this->SetTime((unsigned int)(v*1000));
//		++parsed;
	}
	//if (!(nmeaTokens[2].empty() || nmeaTokens[3].empty())) { // Latitude
	//	++parsed;
	//}
	//if (!(nmeaTokens[4].empty() || nmeaTokens[5].empty())) { // Longitude
	//	++parsed;
	//}
	//if (!nmeaTokens[6].empty()) { // Fix
	//	++parsed;
	//}
	if (!nmeaTokens[7].empty()) { // Sattelites
		std::stringstream stream(nmeaTokens[7]);
		int v; stream>>v;
		this->SetSatellites(v);
//		++parsed;
	}
	if (!nmeaTokens[8].empty()) { // HDOP
		std::stringstream stream(nmeaTokens[8]);
		double v; stream>>v;
		this->SetHDOP(v);
//		++parsed;
	}
//	return parsed;
}

void GSATag::parseGSAString(vector<string> nmeaTokens)
{
	//unsigned int parsed = 0;
	if (nmeaTokens.size() < 15)
		return;

	for (int i = 3; i < 15; i++)
	{
		if (!nmeaTokens[i].empty())
		{
			std::stringstream stream(nmeaTokens[i]);
			int v; stream >> v;
			this->AddSat(v);
		}
	}
}

void RMCTag::parseRMCString(vector<string> nmeaTokens)
{
	if (nmeaTokens.size() < 10)
		return;
	if (!nmeaTokens[1].empty()) { // Time
		std::stringstream stream(nmeaTokens[1]);
		double v;
		stream >> v;
		this->SetTime((unsigned int) (v*1000));
		//lastGPRMC.SetTime((unsigned int)(v*1000.f));
		//++parsed;
	}
	if (!nmeaTokens[2].empty()) { // Validity
		std::stringstream stream(nmeaTokens[2]);
		char v;
		stream >> v;
		this->SetValidity(v=='A');
//		++parsed;
	}
	if (!(nmeaTokens[3].empty() || nmeaTokens[4].empty())) { // Latitude
		std::stringstream stream1(nmeaTokens[3]);
		std::stringstream stream2(nmeaTokens[4]);
		double v; stream1 >> v;
		char s;  stream2 >> s;
		if (s=='S') v=-v;
		v = NMEALoader::convertDegrees(v);
		this->SetLatitude(v);
		//++parsed;
	}
	if (!(nmeaTokens[5].empty() || nmeaTokens[6].empty())) { // Longitude
		std::stringstream stream1(nmeaTokens[5]);
		std::stringstream stream2(nmeaTokens[6]);
		double v; stream1 >> v;
		char s;  stream2 >> s;
		if (s=='W') v=-v;
		v = NMEALoader::convertDegrees(v);
		this->SetLongitude(v);
		//++parsed;
	}
	if (!nmeaTokens[7].empty()) { // Speed
		std::stringstream stream(nmeaTokens[7]);
		double v; stream >> v;
		v = NMEALoader::convertKnotsToMetersPerSecond(v);
		this->SetSpeed(v);
		//++parsed;
	}
	if (!nmeaTokens[8].empty()) { // Azimuth
		std::stringstream stream(nmeaTokens[8]);
		double v; stream >> v;
		v = (float)deg2rad(v);
		this->SetAzimuth(v);
		//++parsed;
	}
	if (!nmeaTokens[9].empty()) { // Date
		std::stringstream stream(nmeaTokens[9]);
		unsigned int v; stream >> v;
		this->SetDate(v);
		//++parsed;
	}
}


void GSVTag::parseGSVString(vector<string> nmeaTokens)
{
	if (nmeaTokens.size() < 4)
		return;
	if (!nmeaTokens[1].empty()) // number of sentences
	{
		std::stringstream stream(nmeaTokens[1]);
		unsigned int v; stream >> v;
		this->SetTotalSetences(v);
	}
	if (!nmeaTokens[2].empty()) // sentence number
	{
		std::stringstream stream(nmeaTokens[2]);
		unsigned int v; stream >> v;
		this->SetSetenceNumber(v);
	}
	if (!nmeaTokens[3].empty()) // number of satelites in view
	{
		std::stringstream stream(nmeaTokens[3]);
		unsigned int v; stream >> v;
		this->SetNumSats(v);
	}

	//cout << "GPGSV fieldSize: " << fields.size() << endl;
	for (int i = 4; i + 3 < nmeaTokens.size() && i < 20; i+=4)
	{
		//cout << "\taccessing fields: " << i << "->" << i + 3 << endl;
		//if ((nmeaTokens[i].empty() && nmeaTokens[i+1].empty() && nmeaTokens[i+2].empty() && nmeaTokens[i+3].empty()) || 
		if ( nmeaTokens[i].empty() || nmeaTokens[i+3].empty())
			continue;
		//satInfo info;
		int prn = 0;
		int snr = 0;
		if (!nmeaTokens[i].empty()) // satelite prn (id)
		{
			std::stringstream stream(nmeaTokens[i]);
			stream >> prn;
		}
		//if(!nmeaTokens[i+1].empty()) // satelite elevation
		//{
		//	std::stringstream stream(nmeaTokens[i+1]);
		//	int v; stream> >v;
		//	//info.elev = deg2rad(v);
		//	info.elev = v;
		//}
		//if(!nmeaTokens[i+2].empty()) // satelite azimuth
		//{
		//	std::stringstream stream(nmeaTokens[i+2]);
		//	unsigned int v; stream> >v;
		//	//info.azimuth = deg2rad(v);
		//	info.elev = v;
		//}
		if(!nmeaTokens[i+3].empty()) // satelite snr
		{
			std::stringstream stream(nmeaTokens[i+3]);
			stream >> snr;
		}
		this->AddSatSnr(prn,snr);
	}
}
//unsigned int NMEALoader::parseGPGSV(const vector<string>& fields,CGPGSV& lastGPGSV)
//{
//	unsigned int parsed = 0;
//	bool firstTag = !lastGPGSV.HasSentences();
//	if (!fields[1].empty()) // number of sentences
//	{
//		if (firstTag){
//			std::stringstream stream(fields[1]);
//			unsigned int v; stream> >v;
//			lastGPGSV.SetSentences(v);
//		}
//		++parsed;
//	}
//	if (!fields[2].empty()) // sentence number
//	{
//		std::stringstream stream(fields[2]);
//		unsigned int v; stream> >v;
//		lastGPGSV.SetProcessedSentences(v);
//		++parsed;
//	}
//	if (!fields[3].empty()) // number of satelites in view
//	{
//		if (firstTag)
//		{
//			std::stringstream stream(fields[3]);
//			unsigned int v; stream> >v;
//			lastGPGSV.SetNumSats(v);
//		}
//		++parsed;
//	}
//	//cout << "GPGSV fieldSize: " << fields.size() << endl;
//	for (int i = 4; i < fields.size() && i < 20; i+=4)
//	{
//		//cout << "\taccessing fields: " << i << "->" << i + 3 << endl;
//		parsed += 4;
//		if ((fields[i].empty() && fields[i+1].empty() && fields[i+2].empty() && fields[i+3].empty())
//			|| fields[i].empty() || fields[i+3].empty())
//			continue;
//		satInfo info;
//		if (!fields[i].empty()) // satelite prn (id)
//		{
//			std::stringstream stream(fields[i]);
//			unsigned int v; stream> >v;
//			info.prn = v;
//		}
//		if(!fields[i+1].empty()) // satelite elevation
//		{
//			std::stringstream stream(fields[i+1]);
//			unsigned int v; stream> >v;
//			//info.elev = deg2rad(v);
//			info.elev = v;
//		}
//		if(!fields[i+2].empty()) // satelite azimuth
//		{
//			std::stringstream stream(fields[i+2]);
//			unsigned int v; stream> >v;
//			//info.azimuth = deg2rad(v);
//			info.elev = v;
//		}
//		if(!fields[i+3].empty()) // satelite snr
//		{
//			std::stringstream stream(fields[i+3]);
//			unsigned int v; stream> >v;
//			info.snr = v;
//		}
//		lastGPGSV.GetSats().insert(make_pair<unsigned int,satInfo>(info.prn,info));
//		//lastGPGSV.GetSats().push_back(info);
//	}
//	return parsed;
//}
