#include "matching_genetic_util.h"


namespace MapMatching {

	double fitnessTime = 0;
	double selectionBuildTime = 0;
	double crossOverTime = 0;
	double mutationTime = 0;
	double precalcDistsTime = 0;
	double isAchiveableLinkTime = 0;
	double sortPopulationTime = 0;
	double populationInitTime = 0;

	Distances::Distances()
	{
		map = NULL;
		route = NULL;
		out = NULL;
	}

	Distances::Distances(mapRepresentation::Map * m, Route * r, vector<set<int> > * forwardPossibleLinks, vector<set<int> > * backwardPossibleLinks, std::ofstream * outputLog)
		: minHeading(r->size()), maxHeading(r->size())
	{
		map = m;
		route = r;
		out = outputLog;

		calculateHeadingIntervals();
		calculateTraceLinkDistances();
		calculateNearLinkDistances(forwardPossibleLinks, backwardPossibleLinks);
	}

	Distances::Distances(mapRepresentation::Map * m, Route * r, std::vector<std::set<mapRepresentation::LinkKey> > * candidates, const std::set<int>& fixedGenes, std::ofstream * outputLog)
		: minHeading(r->size()), maxHeading(r->size())
	{
		map = m;
		route = r;
		out = outputLog;

		calculateHeadingIntervals();
		calculateTraceLinkDistances();
		calculateNearLinkDistances(candidates, fixedGenes);
	}

	Distances::~Distances()
	{	
		for (int i=0; i<dists.size(); i++)
			delete dists[i];
	}

	const Distances& Distances::operator=(const Distances& d)
	{
		if (this != &d)
		{
			int i;

			map = d.map;
			route = d.route;
			out = d.out;
			cumulativeTraceDists = d.cumulativeTraceDists;
			distLinks = d.distLinks;
			minHeading = d.minHeading;
			maxHeading = d.maxHeading;

			for (i=0; i<dists.size(); i++)
				delete dists[i];

			dists.clear();

			for (i=0; i<d.dists.size(); i++)
				dists.push_back(new std::map<int, double>(*d.dists[i]));	
		}

		return *this;
	}

	void Distances::calculateHeadingIntervals()
	{
		int i, j, start, end;
		double temp, currHeading;

		for (i=0; i<route->size(); i++)
		{
			currHeading = route->getHeading(i);
			minHeading[i] = maxHeading[i] = currHeading;

			start = i - DELTA_HEADING_POINT_RADIO;
			end = i + DELTA_HEADING_POINT_RADIO;

			if (start < 0)
				start = 0;

			if (end >= route->size())
				end = (int)route->size() - 1;

			for (j=start; j<=end; j++)
			{
				temp = ajustHeadingToInterval(route->getHeading(j), currHeading);

				minHeading[i] = Min(minHeading[i], temp);
				maxHeading[i] = Max(maxHeading[i], temp);
			}
		}
	}

	void Distances::calculateTraceLinkDistances()
	{
		int i;
		double temp = 0;

		cumulativeTraceDists.push_back(0);

		for (i=1; i<route->size(); i++)
		{
			temp += distance2Points(route->getLongitudeM(i-1), route->getLatitudeM(i-1), route->getLongitudeM(i), route->getLatitudeM(i));
			cumulativeTraceDists.push_back(temp);
		}

		if (out != NULL)
			(*out) << "Trace lenght: " << cumulativeTraceDists.back() << " m." << std::endl;
	}

	void Distances::calculateNearLinkDistances(vector<set<int> > * forwardPossibleLinks, vector<set<int> > * backwardPossibleLinks)
	{
		int i;
		std::vector<std::pair<int, double> > links, candidates;
		std::map<unsigned int, mapRepresentation::mEdges>::iterator graph_it;
		std::set<int>::iterator node_it;
		mapRepresentation::mNode na, nb;
		std::pair<Point, double> res;
		time_t start, end;
		std::vector<vector<pair<mapRepresentation::LinkKey, double> > > finalCandidates;

		time(&start);

		if (forwardPossibleLinks == NULL) //get candidates from Map
		{
			for (i=0; i<route->size(); i++)
			{
				links = map->getNearestLinksAndDistances(route->getLatitude(i), route->getLongitude(i), MAX_DIST_LINK);

				finalCandidates.push_back(links);
			}

			filterCandidatesByHeading(finalCandidates, set<int>());

			filterCandidatesBySuperLink(finalCandidates, set<int>());
		}
		else if (forwardPossibleLinks != NULL && backwardPossibleLinks == NULL) //candidates from Marchal (only one direction)
		{
			int j, start, end;
			set<int> linksToTest, result, temp;
			set<int>::iterator it;
			vector<set<int> > allLinks(route->size());

			for (i=0; i<route->size(); i++)
			{
				start = (int)Max(0, i-3);
				end = (int)Min((int)route->size()-1, i+2);

				for (j=start; j<=end; j++)
					allLinks[i].insert(forwardPossibleLinks->at(j).begin(), forwardPossibleLinks->at(j).end());
			}

			for (i=(int)route->size()-1; i>=0; i--)
			{
				if (i+1 == route->size() || forwardPossibleLinks->at(i+1).size() - forwardPossibleLinks->at(i).size() > 10) //end of a new match from marchal
				{
					linksToTest.clear();
					result.clear();

					for (j=i; j>i+3 && j>=0; j--)
						linksToTest.insert(allLinks[j].begin(), allLinks[j].end());

					for (it = linksToTest.begin(); it != linksToTest.end(); it++)
					{
						temp = map->getAllAchievableLinks(*it, 3);

						result.insert(temp.begin(), temp.end());
					}

					for (j=i; j>i+3 && j>=0; j--)
						allLinks[j].insert(result.begin(), result.end());
				}

				if (i == 0 || forwardPossibleLinks->at(i).size() - forwardPossibleLinks->at(i-1).size() > 10) //begin of a new match from marchal
				{
					linksToTest.clear();
					result.clear();

					for (j=i; j<i+2 && j<route->size(); j++)
						linksToTest.insert(allLinks[j].begin(), allLinks[j].end());

					for (it = linksToTest.begin(); it != linksToTest.end(); it++)
					{
						temp = map->getAllFormerLinks(*it, 3);

						result.insert(temp.begin(), temp.end());
					}

					for (j=i; j<i+3 && j<route->size(); j++)
						allLinks[j].insert(result.begin(), result.end());
				}
			}

			finalCandidates = std::vector<vector<pair<mapRepresentation::LinkKey, double> > >(route->size());

			for (i=0; i<route->size(); i++)
			{
				for (it = allLinks[i].begin(); it != allLinks[i].end(); it++)
				{
					mapRepresentation::mLink l = map->getLink(*it);

					res = getNearestPointFromLink(map->getNodePoint(l.orID), map->getNodePoint(l.destID), Point(route->getLongitudeM(i), route->getLatitudeM(i)));

					if (res.second <= MAX_DIST_LINK)
						finalCandidates[i].push_back(std::pair<mapRepresentation::LinkKey, double>(*it, res.second));
				}
			}

			filterCandidatesByHeading(finalCandidates, set<int>());

			filterCandidatesBySuperLink(finalCandidates, set<int>());
		}
		else if (forwardPossibleLinks != NULL && backwardPossibleLinks != NULL) // candidates from marchal (two directions)
		{
			set<int>::iterator it;
			set<int> linksToTest, forwardLinks, backwardLinks;
			std::vector<int> linksToAdd;
			vector<set<int> > allLinks(route->size());

			for (i=0; i<route->size(); i++)
			{
				linksToTest = forwardPossibleLinks->at(i);
				forwardLinks = linksToTest;

				for (it=linksToTest.begin(); it != linksToTest.end(); it++)
				{
					linksToAdd = map->getLinksUntilNextJunction(*it, 2);
					forwardLinks.insert(linksToAdd.begin(), linksToAdd.end());
				}

				linksToTest = backwardPossibleLinks->at((int)route->size()-1-i);
				backwardLinks = linksToTest;

				for (it=linksToTest.begin(); it != linksToTest.end(); it++)
				{
					linksToAdd = map->getLinksUntilPreviousJunction(*it, 2);
					backwardLinks.insert(linksToAdd.begin(), linksToAdd.end());
				}

				for (it = forwardLinks.begin(); it != forwardLinks.end(); it++)
					if (backwardLinks.find(*it) != backwardLinks.end())
						allLinks[i].insert(*it);

				if (allLinks[i].empty())
				{
					allLinks[i].insert(forwardLinks.begin(), forwardLinks.end());
					allLinks[i].insert(backwardLinks.begin(), backwardLinks.end());
				}
			}

			finalCandidates = std::vector<vector<pair<mapRepresentation::LinkKey, double> > >(route->size());

			for (i=0; i<route->size(); i++)
			{
				for (it = allLinks[i].begin(); it != allLinks[i].end(); it++)
				{
					mapRepresentation::mLink l = map->getLink(*it);

					res = getNearestPointFromLink(map->getNodePoint(l.orID), map->getNodePoint(l.destID), Point(route->getLongitudeM(i), route->getLatitudeM(i)));

					if (res.second <= MAX_DIST_LINK)
						finalCandidates[i].push_back(std::pair<mapRepresentation::LinkKey, double>(*it, res.second));
				}
			}

			filterCandidatesByHeading(finalCandidates, set<int>());

			filterCandidatesBySuperLink(finalCandidates, set<int>());
		}

		time(&end);

		set<int>::iterator it;
		std::map<int, double>::iterator mit;

		if (out != NULL)
		{
			for (i=0; i<route->size(); i++)
			{
				(*out) << i << ":    Min heading: " << (rad2deg(minHeading[i])-MAX_DELTA_HEADING) << " �   Max heading: " << (rad2deg(maxHeading[i])+MAX_DELTA_HEADING) << " �" << std::endl;

				if (forwardPossibleLinks != NULL)
				{
					(*out) << "Candidates from Marchal (Forwards): ";

					for (it = forwardPossibleLinks->at(i).begin(); it != forwardPossibleLinks->at(i).end(); it++)
						(*out) << *it << " ";
					(*out) << std::endl;
				}

				if (backwardPossibleLinks != NULL)
				{
					(*out) << "(Backwards): ";

					for (it = backwardPossibleLinks->at((int)route->size()-1-i).begin(); it != backwardPossibleLinks->at((int)route->size()-1-i).end(); it++)
						(*out) << *it << " ";
					(*out) << std::endl;
				}

				(*out) << "Final Candidates: ";

				for (mit = dists[i]->begin(); mit != dists[i]->end(); mit++)
					(*out) << mit->first << " (" << mit->second << " m.)  ";
				(*out) << std::endl << std::endl;
			}

			(*out) << std::endl << "Time precalculating distances from trace points to nearest links: " << difftime(end, start) << " s." << std::endl;
		}
	}

	void Distances::calculateNearLinkDistances(vector<set<mapRepresentation::LinkKey> > * candidates, const std::set<int>& fixedGenes)
	{
		int i, j;
		mapRepresentation::LinkKey lKey;
		mapRepresentation::mLink l;
		std::pair<Point, double> res;
		set<mapRepresentation::LinkKey>::iterator it;
		std::set<mapRepresentation::SuperLinkKey> allowedSuperLinks;
		std::vector<std::pair<mapRepresentation::LinkKey, double> > links;
		std::vector<std::vector<std::pair<mapRepresentation::LinkKey, double> > > finalCandidates(route->size());
		time_t start, end;

		time(&start);

		for (i=0; i<route->size(); i++)
		{
			if (fixedGenes.find(i) == fixedGenes.end()) // find links in the map
			{
				allowedSuperLinks.clear();

				for (it = candidates->at(i).begin(); it != candidates->at(i).end(); it++)
					allowedSuperLinks.insert(map->getSuperLinkKey(*it));

				links = map->getNearestLinksAndDistances(route->getLatitude(i), route->getLongitude(i), MAX_DIST_LINK);


				for (j=0; j<links.size(); j++)
				{
					if (allowedSuperLinks.find(map->getSuperLinkKey(links[j].first)) != allowedSuperLinks.end())
						finalCandidates[i].push_back(std::pair<mapRepresentation::LinkKey, double>(links[j].first, links[j].second));
				}
			}
			else
			{
				if (!candidates->at(i).empty())
				{
					lKey = *candidates->at(i).begin();
					l = map->getLink(lKey);

					res = getNearestPointFromLink(map->getNodePoint(l.orID), map->getNodePoint(l.destID), Point(route->getLongitudeM(i), route->getLatitudeM(i)));

					finalCandidates[i].push_back(std::pair<mapRepresentation::LinkKey, double>(lKey, res.second));
				}
			}
		}

		filterCandidatesByHeading(finalCandidates, fixedGenes);

		filterCandidatesBySuperLink(finalCandidates, set<int>());


		time(&end);

		std::map<mapRepresentation::LinkKey, double>::iterator mit;

		if (out != NULL)
		{
			for (i=0; i<route->size(); i++)
			{
				(*out) << i << ":    Min heading: " << (rad2deg(minHeading[i])-MAX_DELTA_HEADING) << " �   Max heading: " << (rad2deg(maxHeading[i])+MAX_DELTA_HEADING) << " �" << std::endl;

				(*out) << "Candidates from Marchal: ";

				for (it = candidates->at(i).begin(); it != candidates->at(i).end(); it++)
					(*out) << *it << " ";
				(*out) << std::endl;

				(*out) << "Final Candidates: ";

				for (mit = dists[i]->begin(); mit != dists[i]->end(); mit++)
					(*out) << mit->first << " (" << mit->second << " m.)  ";
				(*out) << std::endl << std::endl;
			}

			(*out) << std::endl << "Time precalculating distances from trace points to nearest links: " << difftime(end, start) << " s." << std::endl;
		}
	}

	void Distances::filterCandidatesByHeading(vector<vector<pair<mapRepresentation::LinkKey, double> > >& candidates, const std::set<int>& fixedGenes)
	{
		int i, j;
		double heading, theading, delta_rad, min_heading, max_heading;
		delta_rad = deg2rad(MAX_DELTA_HEADING);

		for (i=0; i<route->size(); i++)
		{
			if (fixedGenes.find(i) == fixedGenes.end())
			{
				heading = route->getHeading(i);
				min_heading = minHeading[i] - delta_rad;
				max_heading = maxHeading[i] + delta_rad;

				for (j=(int)candidates[i].size()-1; j>=0; j--)
				{
					theading = map->getLink(candidates[i][j].first).heading;
					theading = ajustHeadingToInterval(theading, heading);

					if (!(min_heading <= theading && max_heading >= theading))
						candidates[i].erase(candidates[i].begin()+j);
				}
			}
		}
	}

	void Distances::filterCandidatesBySuperLink(const vector<vector<pair<mapRepresentation::LinkKey, double> > >& candidates, const std::set<int>& fixedGenes)
	{
		int i, j;
		double dist;
		mapRepresentation::mLink l;
		mapRepresentation::SuperLinkKey superKey;
		std::vector<std::map<mapRepresentation::SuperLinkKey, std::pair<mapRepresentation::LinkKey, double> > > filteredCandidates(route->size());
		std::vector<std::vector<std::pair<mapRepresentation::LinkKey, double> > > newCandidates(route->size());
		std::map<mapRepresentation::SuperLinkKey, std::pair<mapRepresentation::LinkKey, double> >::iterator it, it2;
		std::map<int, double> * finalCandidates;
		std::map<int, double>::iterator mit;

		for (i=0; i<route->size(); i++)
		{
			if (fixedGenes.find(i) == fixedGenes.end())
			{
				for (j=0; j<candidates[i].size(); j++)
				{
					superKey = map->getSuperLinkKey(candidates[i][j].first);
					it = filteredCandidates[i].find(superKey);

					if (it == filteredCandidates[i].end())
						filteredCandidates[i].insert(make_pair(superKey, std::pair<mapRepresentation::LinkKey, double>(candidates[i][j].first, candidates[i][j].second)));
					else if (candidates[i][j].second < it->second.second)
						filteredCandidates[i][superKey] = std::pair<mapRepresentation::LinkKey, double>(candidates[i][j].first, candidates[i][j].second);
				}
			}
		}

		for (i=0; i<route->size()-1; i++)
		{
			for (it = filteredCandidates[i].begin(); it != filteredCandidates[i].end(); it++)
			{
				it2 = filteredCandidates[i+1].find(it->first);

				if (it2 != filteredCandidates[i+1].end())
				{
					if (map->getSequenceNumber(it->second.first) > map->getSequenceNumber(it2->second.first))
					{
						if (fixedGenes.find(i) == fixedGenes.end())
						{
							l = map->getLink(it2->second.first);
							dist = getNearestPointFromLink(map->getNodePoint(l.orID), map->getNodePoint(l.destID), Point(route->getLongitudeM(i), route->getLatitudeM(i))).second;
							newCandidates[i].push_back(std::pair<mapRepresentation::LinkKey, double>(it2->second.first, dist));
						}

						if (fixedGenes.find(i+1) == fixedGenes.end())
						{
							l = map->getLink(it->second.first);
							dist = getNearestPointFromLink(map->getNodePoint(l.orID), map->getNodePoint(l.destID), Point(route->getLongitudeM(i+1), route->getLatitudeM(i+1))).second;
							newCandidates[i+1].push_back(std::pair<mapRepresentation::LinkKey, double>(it->second.first, dist));
						}
					}
				}
			}
		}

		for (i=0; i<route->size(); i++)
		{
			finalCandidates = new std::map<int, double>();

			for (it = filteredCandidates[i].begin(); it != filteredCandidates[i].end(); it++)
				finalCandidates->insert(make_pair(it->second.first, it->second.second));

			if (!newCandidates[i].empty())
			{
				for (j=0; j<newCandidates[i].size(); j++)
					finalCandidates->insert(make_pair(newCandidates[i][j].first, newCandidates[i][j].second));
			}

			dists.push_back(finalCandidates);	
		}
	}

	vector<int> Distances::getValidLinks(int point) const
	{
		vector<int> temp;
		std::map<int, double>::iterator it;

		for (it = dists[point]->begin(); it != dists[point]->end(); it++)
			temp.push_back(it->first);

		return temp;
	}

	double Distances::getDistanceFromPointToLink(int point, int link)
	{
		std::pair<Point, double> res;

		if (dists[point]->find(link) == dists[point]->end())
		{
			mapRepresentation::mLink l = map->getLink(link);
			res = getNearestPointFromLink(map->getNodePoint(l.orID), map->getNodePoint(l.destID), Point(route->getLongitudeM(point), route->getLatitudeM(point)));

			dists[point]->insert(make_pair(link, res.second));

			return res.second;
		}
		else
			return dists[point]->find(link)->second;
	}

	int Distances::getNearestLink(int point)
	{
		int link;
		double dist;
		std::map<int, double>::iterator it;

		link = INVALID_LINK;

		for (it = dists[point]->begin(); it != dists[point]->end(); it++)
		{
			if (link == INVALID_LINK || it->second < dist)
			{
				dist = it->second;
				link = it->first;
			}
		}

		return link;
	}

	double Distances::getDistanceBetweenLinks(int first, int second)
	{
		stringstream ss;
		std::map<string, double>::iterator it;

		ss << first << "." << second;

		it = distLinks.find(ss.str());

		if (it != distLinks.end())
			return it->second;
		else
		{
			double d = distance2Points(map->getNodePoint(map->getLink(first).destID), map->getNodePoint(map->getLink(second).orID));
			distLinks.insert(make_pair(ss.str(), d));
			return d;	
		}
	}

	Individual::Individual(int n)
	{
		size = n;
		chromo = new int[size];
		avgDist = 0;
		maxMinDist = 0;
		maxDist = 0;
		uncoveredDist = 0;
		gapDist = 0;
		continuityLength = 0;
		smallsDist = 0;
		infDist = 0;
		avgDisc = 0;
		maxDisc = 0;
		score = 0;
		invScore = 0;
	}

	Individual::~Individual()
	{
		delete[] chromo;
	}

	Individual::Individual(const Individual &i)
	{
		size = i.size;
		chromo = new int[size];
		memcpy(chromo, i.chromo, sizeof(int)*size);
		avgDist = i.avgDist;
		maxMinDist = i.maxMinDist;
		maxDist = i.maxDist;
		uncoveredDist = i.uncoveredDist;
		gapDist = i.gapDist;
		continuityLength = i.continuityLength;
		smallsDist = i.smallsDist;
		infDist = i.infDist;
		avgDisc = i.avgDisc;
		maxDisc = i.maxDisc;
		score = i.score;		
		invScore = i.invScore;
	}

	const Individual& Individual::operator=(const Individual &i)
	{
		if (this != &i)
		{
			if (size != i.size)
			{
				delete[] chromo;
				size = i.size;
				chromo = new int[size];
			}

			memcpy(chromo, i.chromo, sizeof(int)*size);
			avgDist = i.avgDist;
			maxMinDist = i.maxMinDist;
			maxDist = i.maxDist;
			uncoveredDist = i.uncoveredDist;
			gapDist = i.gapDist;
			continuityLength = i.continuityLength;
			smallsDist = i.smallsDist;
			infDist = i.infDist;
			avgDisc = i.avgDisc;
			maxDisc = i.maxDisc;
			score = i.score;			
			invScore = i.invScore;
		}

		return *this;
	}

	std::string Individual::toString()
	{
		int i;
		std::ostringstream oss (std::ostringstream::out);

		oss << "maxMinDist = " << maxMinDist << " m.   maxDist = " << maxDist << " m.  avgDist = " << avgDist << " m.  uncoveredDist = " << uncoveredDist << " m.  gapDist = " << gapDist << " m.  continuityLength = " << continuityLength << " m.  smallsDist = " << smallsDist << " m.  infDist = " << infDist << " m.  avgDiscDist = " << avgDisc << " m.  maxDiscDist = " << maxDisc << " m.  Score: " << score << "  invScore: " << invScore << "    ";

		for (i=0; i<size; i++)
			oss << chromo[i] << " ";

		oss << std::endl;

		return oss.str();
	}


	template <typename T>
	RouletteWheel<T>::RouletteWheel(std::vector<std::pair<double, T> > elems, double total)
	{
		double sum = 0;

		for (int i=0; i<elems.size(); i++)
		{
			sum += elems[i].first;

			if(i==(int)elems.size()-1)
				std::cout << "Sum: " << sum << "  sum/total: " << sum/total << std::endl;					

			r.insert(RouletteWheelNode<T>((double)sum/total, elems[i].second));
		}
	}

	template <typename T>
	RouletteWheel<T>::RouletteWheel(std::vector<std::pair<double, T> > elems)
	{
		double sum = 0;

		for (int i=0; i<elems.size(); i++)
		{
			sum += elems[i].first;

			if (i == (int)elems.size())
				sum = 1.0000000001;

			r.insert(RouletteWheelNode<T>(sum, elems[i].second));
		}
	}

	template <typename T>
	T RouletteWheel<T>::getSelected()
	{
		int rd = rand();
		double num = (double) rd / RAND_MAX;
		RouletteWheelNode<T> temp(num, T());

		//std::set<RouletteWheelNode<T> >::iterator it = r.lower_bound(temp);

		if (r.lower_bound(temp) == r.end())
		{
			//std::cout << "ERROR: RouletteWheel - value: " << temp.getValue() << " rand = " << rd << std::endl;
			//it--;
			//std::set<RouletteWheelNode<T> >::iterator it = r.end();
			//it--;
			//return it->getObject();
			return r.rbegin()->getObject();
			//	return (r.end()--)->getObject();
		}

		/*cout.precision(12);
		if (RAND_MAX - t < 10)
		std::cout << t << " / " << RAND_MAX << " = " << num << std::endl;

		std::set<RouletteWheelNode<T> >::iterator it = r.lower_bound(temp);

		if (it == r.end())
		{
		it--;
		std::cout << "ERROR Roulette: last value " << it->getValue() << std::endl; 
		}*/

		//return it->getObject();
		return (r.lower_bound(temp))->getObject();
	}

	template <typename T>
	std::string RouletteWheel<T>::toString()
	{
		double last = 0;
		std::ostringstream oss (std::ostringstream::out);

		oss << "Roulette: size = " << r.size() << std::endl;

		//std::cout << "Roulette: size = " << r.size() << std::endl;

		/*for (std::set<RouletteWheelNode<T> >::iterator it = r.begin(); it != r.end(); it++)
		{
		oss << it->getValue() << "  -> " << it->getObject() << "  diff = " << (it->getValue() - last) << std::endl;
		last = it->getValue();
		}*/

		oss << std::endl;

		return oss.str();
	}

	template <typename T>
	T Tournament<T>::getSelected()
	{
		int i, j, tSize = (int)pow(2.0, tournamentSize);
		vector<int> selected(tSize);

		for (i=0; i<tSize; i++)
			selected[i] = (rand() % elements.size());

		while (tSize > 0)
		{
			tSize /= 2;

			for (i=0, j=0; i<tSize; i++, j+=2)
			{
				if ((double)rand() / RAND_MAX < probBestIndividual) //select the best
				{
					if (elements[selected[j]].first < elements[selected[j+1]].first)
						selected[i] = selected[j];
					else
						selected[i] = selected[j+1];
				}
				else
				{
					if (elements[selected[j]].first > elements[selected[j+1]].first)
						selected[i] = selected[j];
					else
						selected[i] = selected[j+1];
				}
			}
		}

		return elements[selected[0]].second;
	}

	template <typename T>
	std::string Tournament<T>::toString()
	{
		std::ostringstream oss (std::ostringstream::out);

		oss << "Total of elements: " << elements.size() << std::endl
			<< "Size of Tournament: " << tournamentSize << std::endl << std::endl;

		return oss.str();
	}


	Population::Population()
	{
		map = NULL;
		route = NULL;
		dists = NULL;
		out = NULL;
		params = NULL;
		popSize = -1;
		indSize = -1;
		segment_length = -1;
		routePtr = -1;
		direct_individuals = -1;
		generation = -1;
		total_scores = -1;
		inv_total_scores = -1;
		best_from_ever = -1;
		diff_scores = -1;
		max_diff = -1;
		min_diff = -1;
		best_diff = -1;
		worst_diff = -1;
	}

	Population::Population(mapRepresentation::Map * m, Route * r, Distances * d, geneticParameters * p, int routePtr, int indSize, std::ofstream * outputLog)
		: population(p->POP_SIZE), newPopulation(p->POP_SIZE)
	{
		map = m;
		route = r;
		dists = d;
		params = p;
		out = outputLog;
		popSize = params->POP_SIZE;
		this->indSize = indSize;
		this->routePtr = routePtr;

		segment_length = dists->getTraceDistance(routePtr, routePtr+indSize-1);

		if (segment_length <= 0)
			segment_length = 1e-9;

		if (out != NULL)
			(*out) << "Segment Length: " << segment_length << " m." << std::endl;

		direct_individuals = popSize * params->DIRECT_PASS;

		if ((popSize - direct_individuals) % 2 != 0)
			direct_individuals++;

		generation = 0;
		total_scores = 0;
		inv_total_scores = 0;
		best_from_ever = -1;
		diff_scores = -1;
		max_diff = -1;
		min_diff = -1;
		best_diff = -1;
		worst_diff = -1;
	}

	Population::~Population()
	{

	}

	Population::Population(const Population &p)
	{
		map = p.map;
		route = p.route;
		dists = p.dists;
		params = p.params;
		out = p.out;
		popSize = p.popSize;
		routePtr = p.routePtr;
		indSize = p.indSize;
		segment_length = p.segment_length;
		direct_individuals = p.direct_individuals;
		generation = p.generation;
		total_scores = p.total_scores;
		inv_total_scores = p.inv_total_scores;
		best_from_ever = p.best_from_ever;
		diff_scores = p.diff_scores;
		max_diff = p.max_diff;
		min_diff = p.min_diff;
		best_diff = p.best_diff;
		worst_diff = p.worst_diff;
		population = p.population;
		newPopulation = p.newPopulation;

		for (int i=0; i<p.selection.size(); i++)
			selection.push_back(p.selection[i]->newObject());

		//roulettes = p.roulettes;
		bests = p.bests;
		achiveableSuperLinks = p.achiveableSuperLinks;
	}

	const Population& Population::operator =(const Population &p)
	{
		if (this != &p)
		{
			map = p.map;
			route = p.route;
			dists = p.dists;
			params = p.params;
			out = p.out;
			popSize = p.popSize;
			routePtr = p.routePtr;
			indSize = p.indSize;
			segment_length = p.segment_length;
			direct_individuals = p.direct_individuals;
			generation = p.generation;
			total_scores = p.total_scores;
			inv_total_scores = p.inv_total_scores;
			best_from_ever = p.best_from_ever;
			diff_scores = p.diff_scores;
			max_diff = p.max_diff;
			min_diff = p.min_diff;
			best_diff = p.best_diff;
			worst_diff = p.worst_diff;
			population = p.population;
			newPopulation = p.newPopulation;
			selection.clear();

			for (int i=0; i<p.selection.size(); i++)
				selection.push_back(p.selection[i]->newObject());

			//roulettes = p.roulettes;
			bests = p.bests;
			achiveableSuperLinks = p.achiveableSuperLinks;
		}

		return *this;
	}

	void Population::initializePopulation(bool fixedGene, int gene, int allele)
	{
		int i, j;
		double temp;
		time_t start, end;
		vector<pair<double, int> > list;
		vector<int> validLinks;

		srand((unsigned int)time(NULL));

		time(&start);

		//build roulettes
		for (i=0; i<indSize; i++)
		{
			list.clear();

			if (fixedGene && gene == (routePtr+i))
			{
				list.push_back(pair<double, int>(1.0, allele));
				selection.push_back(new RouletteWheel<int>(list));
			}
			else
			{
				validLinks = dists->getValidLinks(routePtr+i);

				if (validLinks.empty())
				{
					list.push_back(pair<double, int>(1.0, INVALID_LINK));
					selection.push_back(new RouletteWheel<int>(list));
				}
				else
				{
					temp = (double)(1.0 - params->PROB_INVALID_LINK) / (int)validLinks.size();

					list.push_back(pair<double, int>(params->PROB_INVALID_LINK, INVALID_LINK));

					for (j=0; j<validLinks.size(); j++)
						list.push_back(pair<double, int>(temp, validLinks[j]));

					selection.push_back(new RouletteWheel<int>(list));
				}

				/* old way (geometric)
				total = 0;
				validLinks = dists->getValidLinks(routePtr+i);

				for (j=0; j<validLinks.size(); j++)
				{
				dist = dists->getDistanceFromPointToLink(routePtr+i, validLinks[j]);

				if (dist < 1e-12)
				temp = 1e12;
				else
				temp = 1 / dist;

				/* RouletteWheel based on distance
				total += temp;
				list.push_back(make_pair(temp, validLinks[j]));

				}

				if (list.size() == 0)
				{
				list.push_back(pair<double, int>(1, NON_VALID_LINK));
				selection.push_back(new RouletteWheel<int>(list, 1));
				}
				else
				{
				temp = total;
				total /= (1-PROB_NON_VALID_LINK);
				list.push_back(make_pair(total - temp, NON_VALID_LINK));
				selection.push_back(new RouletteWheel<int>(list, total));					
				}*/
			}
		}

		time(&end);

		if (out != NULL)
			(*out) << "Roulettes built in " << difftime(end, start) << " seconds." << std::endl;

		/*for (i=0; i<indSize; i++)
		if (out != NULL)
		std::cout << i << " :  " << selection[i]->toString();*/


		for (i=0; i<popSize; i++)
		{
			Individual ind(indSize);

			for (j=0; j<indSize; j++)
				ind.setGene(j, selection[j]->getSelected());

			population[i] = ind;
		}

		fitness(true);
	}

	void Population::initializePopulation(set<int>& fixedGenes)
	{
		int i, j;
		double temp;
		time_t start, end;
		vector<pair<double, int> > list;
		vector<int> validLinks;

		srand((unsigned int)time(NULL));

		time(&start);

		//build roulettes
		for (i=0; i<indSize; i++)
		{
			list.clear();
			validLinks = dists->getValidLinks(routePtr+i);

			if (fixedGenes.find(routePtr+i) != fixedGenes.end())
			{
				if (validLinks.empty())
					list.push_back(pair<double, int>(1.0, INVALID_LINK));
				else
					list.push_back(pair<double, int>(1.0, validLinks.front()));
			}
			else
			{
				if (validLinks.empty())
					list.push_back(pair<double, int>(1.0, INVALID_LINK));
				else
				{
					temp = (double)(1.0 - params->PROB_INVALID_LINK) / (int)validLinks.size();

					list.push_back(pair<double, int>(params->PROB_INVALID_LINK, INVALID_LINK));

					for (j=0; j<validLinks.size(); j++)
						list.push_back(pair<double, int>(temp, validLinks[j]));
				}				
			}

			selection.push_back(new RouletteWheel<int>(list));
		}

		time(&end);

		if (out != NULL)
			(*out) << "Roulettes built in " << difftime(end, start) << " seconds." << std::endl;

		for (i=0; i<popSize; i++)
		{
			Individual ind(indSize);

			for (j=0; j<indSize; j++)
				ind.setGene(j, selection[j]->getSelected());

			population[i] = ind;
		}

		fitness(true);
	}

	void Population::crossOver()
	{
		int i, j;
		double cut, num;
		vector<pair<double, Individual *> > vals;
		time_t start, end;

		time(&start);

		// Selection: RouletteWheel
		/*for (i=0; i<population.size(); i++)
			vals.push_back(make_pair(population[i].getInvScore(), &population[i]));

		RouletteWheel<Individual *> rw(vals, inv_total_scores);

		Selection<Individual *> * sel = &rw;*/

		// Selection: Tournament
		for (i=0; i<population.size(); i++)
			vals.push_back(make_pair(population[i].getScore(), &population[i]));

		Tournament<Individual *> t(vals, params->TOURNAMENT_PROB_BEST_INDIVIDUAL);

		Selection<Individual *> * sel = &t;

		time(&end);

		selectionBuildTime += difftime(end, start);

		time(&start);

		for (i=direct_individuals; i<popSize; i+=2)
		{
			newPopulation[i] = *sel->getSelected();
			newPopulation[i+1] = *sel->getSelected();

			if ((double)rand()/RAND_MAX < params->RECOMBINATION_PROB)
			{
				cut = rand() % newPopulation[i].getSize();

				for (j=cut; j<newPopulation[i].getSize(); j++)
				{
					num = newPopulation[i].getGene(j);
					newPopulation[i].setGene(j, newPopulation[i+1].getGene(j));
					newPopulation[i+1].setGene(j, num);
				}
			}
		}

		time(&end);
		crossOverTime += difftime(end, start);
	}

	void Population::mutation()
	{
		int i, j;
		time_t start, end;

		time(&start);

		for (i=direct_individuals; i<newPopulation.size(); i++)
			for (j=0; j<newPopulation[i].getSize(); j++)
				if ((double)rand() / RAND_MAX < params->MUTATION_PROB)
					newPopulation[i].setGene(j, selection[j]->getSelected());

		time(&end);
		mutationTime += difftime(end, start);
	}

	void Population::fitness(bool all)
	{
		int i, startEval;
		int currGene, nextGene, ptr, individual_size, start, end;
		double dist, sum, maxDistance, maxMinDistance, tempMinDistance, sum_discs, count_discs;
		bool is_achiveable_link, looping;
		time_t startTime, endTime;

		time(&startTime);

		if (all)
			startEval = 0;
		else
			startEval = direct_individuals;

		total_scores = 0;
		inv_total_scores = 0;

		for (i=0; i<startEval; i++)
		{
			total_scores += population[i].getScore();
			inv_total_scores += population[i].getInvScore();
		}

		individual_size = population[startEval].getSize();

		for (i = startEval; i<population.size(); i++)
		{
			looping = true;
			ptr = 0;
			sum = 0;
			sum_discs = 0;
			count_discs = 0;
			maxDistance = 0;
			maxMinDistance = 0;
			currGene = population[i].getGene(0);
			nextGene = population[i].getGene(1);

			population[i].setUncoveredDistance(0);
			population[i].setGapDistance(0);
			population[i].setContinuityLength(0);
			population[i].setAvgDiscDistance(0);
			population[i].setMaxDiscDistance(0);

			while (ptr < individual_size)
			{
				if (currGene != INVALID_LINK)
				{
					looping = true;

					while (looping)
					{
						start = ptr;
						is_achiveable_link = true;
						tempMinDistance = 1000;

						while (ptr < individual_size && currGene != INVALID_LINK && is_achiveable_link)
						{
							dist = dists->getDistanceFromPointToLink(routePtr+ptr, currGene);
							sum += dist;

							if (dist > maxDistance)
								maxDistance = dist;

							if (dist < tempMinDistance)
								tempMinDistance = dist;


							if (ptr < individual_size - 1)
							{
								nextGene = population[i].getGene(ptr+1);

								if (currGene != nextGene && nextGene != INVALID_LINK)
									is_achiveable_link = isAchiveableLink(currGene, nextGene);

								currGene = nextGene;
							}

							ptr++;
						}

						if (ptr >= individual_size)
							end = individual_size - 1;
						else
							end = ptr - 1;

						if (ptr >= individual_size || currGene == INVALID_LINK)
							looping = false;

						if (tempMinDistance > maxMinDistance)
							maxMinDistance = tempMinDistance;

						dist = dists->getTraceDistance(routePtr+start, routePtr+end);	
						population[i].addToContinuityLength(dist * dist);

						if (currGene != INVALID_LINK && !is_achiveable_link) //gap
						{
							dist = dists->getDistanceBetweenLinks(population[i].getGene(ptr-1), currGene);
							population[i].addToGapDistance(dist);
						}
						else if (currGene != INVALID_LINK && map->areMirrored(population[i].getGene(ptr-1), currGene))
							population[i].addToGapDistance(2 * map->getLinkLength(currGene));
					}
				}
				else // INVALID_LINK (-1)
				{
					if (ptr > 0)
					{
						dist = dists->getDistanceFromPointToLink(routePtr+ptr, population[i].getGene(ptr-1));

						sum_discs += dist;
						count_discs++;

						if (dist > population[i].getMaxDiscDistance())
							population[i].setMaxDiscDistance(dist);
					}

					start = ptr;

					while (ptr < individual_size && currGene == INVALID_LINK)
					{
						sum += params->D_LIMIT;

						ptr++;

						if (ptr < individual_size)
							currGene = population[i].getGene(ptr);
					}

					if (ptr >= individual_size)
						end = individual_size - 1;
					else
						end = ptr - 1;

					if (ptr <= individual_size - 1)
					{
						dist = dists->getDistanceFromPointToLink(routePtr+ptr-1, population[i].getGene(ptr));

						sum_discs += dist;
						count_discs++;

						if (dist > population[i].getMaxDiscDistance())
							population[i].setMaxDiscDistance(dist);
					}

					if (start > 0)
						start--;

					if (end < individual_size - 1)
						end++;

					dist = dists->getTraceDistance(routePtr+start, routePtr+end);

					population[i].addToUncoveredDistance(dist);
					population[i].addToContinuityLength(dist * dist);
				}
			}

			population[i].setAvgDistance(sum / individual_size);
			population[i].setMaxDistance(maxDistance);
			population[i].setMaxMinDistance(maxMinDistance);

			if (count_discs > 0)
				population[i].setAvgDiscDistance(sum_discs / count_discs);

			population[i].setScore((population[i].getAvgDistance() / params->D_LIMIT) * params->W_AVG
				+ (population[i].getMaxMinDistance() / params->D_LIMIT) * params->W_MAX_MIN
				+ (population[i].getMaxDistance() / params->D_LIMIT) * params->W_MAX
				+ (population[i].getUncoveredDistance() / segment_length) * params->W_UNCOV
				+ (population[i].getGapDistance() / (3*params->D_LIMIT)) * params->W_GAP
				+ (((segment_length * segment_length) / population[i].getContinuityLength()) - 1) * params->W_CONTLEN
				+ (population[i].getAvgDiscDistance() / (3*params->D_LIMIT)) * params->W_AVGDISC
				+ (population[i].getMaxDiscDistance() / (3*params->D_LIMIT)) * params->W_MAXDISC);

			//only to debug values
			/*if (generation % 50 == 0 && i % 10 == 0 && out != NULL)
			{
			(*out) << population[i].toString();
			(*out) << population[i].getScore() << " = " << ((population[i].getAvgDistance() / D_LIMIT) * W_AVG) << " + "
			<< ((population[i].getMaxMinDistance() / D_LIMIT) * W_MAX_MIN) << " + "
			<< ((population[i].getMaxDistance() / D_LIMIT) * W_MAX) << " + "
			<< ((population[i].getUncoveredDistance() / segment_length) * W_UNCOV) << " + "
			<< ((population[i].getGapDistance() / (3*D_LIMIT)) * W_GAP) << " + "
			<< continuity_score * W_CONTLEN << " + "
			<< ((population[i].getAvgDiscDistance() / (3*D_LIMIT)) * W_AVGDISC) << " + "
			<< ((population[i].getMaxDiscDistance() / (3*D_LIMIT)) * W_MAXDISC) << std::endl << std::endl;
			}*/


			if (population[i].getScore() < 1e-9)
				population[i].setInvScore(1e9);
			else		
				population[i].setInvScore((double)1.0 / population[i].getScore());

			total_scores += population[i].getScore();
			inv_total_scores += population[i].getInvScore();
		}

		time(&endTime);

		fitnessTime += difftime(endTime, startTime);
	}

	std::vector<int> Population::getIndividualGaps(const Individual& ind)
	{
		int i, currGene, nextGene;
		std::vector<int> gaps;

		currGene = ind.getGene(0);

		for (i=0; i<ind.getSize()-1; i++)
		{
			nextGene = ind.getGene(i+1);

			if (currGene != INVALID_LINK && nextGene != INVALID_LINK && currGene != nextGene)
				if (!isAchiveableLink(currGene, nextGene))
					gaps.push_back(i);

			currGene = nextGene;
		}

		return gaps;
	}


	void Population::nextGeneration()
	{
		int i;
		double diff;
		Individual * i1, * i2;
		time_t sSort, eSort;

		generation++;

		time(&sSort);
		RankedPopulation r(&population);
		time(&eSort);

		sortPopulationTime += difftime(eSort, sSort);

		//save best
		for (i=0; i<direct_individuals && r.hasNext(); i++)
			newPopulation[i] = *r.next();

		crossOver();
		mutation();

		population.swap(newPopulation);

		fitness(false);

		time(&sSort);
		RankedPopulation rank(&population);
		RankedPopulation oldRank(&newPopulation);
		time(&eSort);

		sortPopulationTime += difftime(eSort, sSort);

		i1 = rank.next();
		i2 = oldRank.next();

		bests.push_back(*i1);

		if (generation <= 1)
			best_from_ever = 1;
		else if (i1->getScore() < bests[best_from_ever-1].getScore())
			best_from_ever = generation;

		diff = (i1->getScore() - i2->getScore()) * (i1->getScore() - i2->getScore());
		diff_scores = 0;
		best_diff= diff;
		max_diff = diff;
		min_diff = diff;	

		while (rank.hasNext())
		{
			i1 = rank.next();
			i2 = oldRank.next();

			diff = (i1->getScore() - i2->getScore()) * (i1->getScore() - i2->getScore());
			diff_scores += diff;

			if (diff > max_diff)
				max_diff = diff;

			if (diff < min_diff)
				min_diff = diff;
		}

		worst_diff = diff;
	}

	void Population::printGeneration()
	{
		Individual * temp;

		if (out != NULL)
		{
			RankedPopulation rank(&population);

			(*out) << "Population: " << generation << std::endl;

			while (rank.hasNext())
			{
				temp = rank.next();
				(*out) << temp->toString();
			}

			(*out) << std::endl;
		}
	}

	void Population::printGenerationStatistics()
	{
		int i;
		Individual * temp;
		RankedPopulation rank(&population);

		if (out == NULL)
			return;

		(*out) << std::endl << "### Generation Statistics ###" << std::endl;
		(*out) << "Generation: " << generation << std::endl;

		(*out) << "Best individuals from this generation:" << std::endl;

		for (i=0; i<population.size() && rank.hasNext(); i++)
		{
			temp = rank.next();

			if (i-5 < 0)
				(*out) << temp->toString();

			if (i-5 == 0)
				(*out) << "Worst individuals from this generation:" << std::endl;

			if (population.size()-i <= 5)
				(*out) << temp->toString();
		}

		(*out) << std::endl << "Population avgScore = " << (total_scores/popSize) << std::endl;

		(*out) << std::endl << "Score diferences between current and previous generation" << std::endl;
		(*out) << "minDiff = " << min_diff << "  avgDiff = " << diff_scores/popSize << "  maxDiff = " << max_diff << std::endl;
		(*out) << "Diff from best indiviuals " << best_diff << std::endl;
		(*out) << "Diff from worst indiviuals " << worst_diff << std::endl;

		(*out) << std::endl;
	}

	void Population::printPopulationStatistics()
	{
		if (out == NULL)
			return;

		(*out) << std::endl << "### Population Statistics ###" << std::endl;
		(*out) << "Size: " << popSize << std::endl;
		(*out) << "Direct Pass: " << direct_individuals << "  (" << (params->DIRECT_PASS*100) << "%)" << std::endl;
		(*out) << "Chromosome size: " << route->size() << std::endl;
		(*out) << "Probabilities: Recombination = " << params->RECOMBINATION_PROB << "  Mutation = " << params->MUTATION_PROB << "  Non valid link (-1) = " << params->PROB_INVALID_LINK << std::endl;
		(*out) << "Segment Length: " << segment_length << " m." << std::endl;
		(*out) << "Weights: W_MAX_MIN = " << params->W_MAX_MIN << "  W_AVG = " << params->W_AVG << "  W_MAX = " << params->W_MAX << "  W_UNCOV = " << params->W_UNCOV << "  W_GAP = " << params->W_GAP << "  W_CONTLEN = " << params->W_CONTLEN << "  W_AVGDISC = " << params->W_AVGDISC << "  W_MAXDISC = " << params->W_MAXDISC << std::endl;
		(*out) << "D_LIMIT = " << params->D_LIMIT << "  MAX_DIST_LINK = " << MAX_DIST_LINK << std::endl;
		(*out) << std::endl;
	}

	void Population::printBestIndividuals()
	{
		int i;

		if (out == NULL)
			return;

		(*out) << "Best Individual from ever : generation = " << best_from_ever << std::endl;
		(*out) << bests[best_from_ever-1].toString();

		(*out) << std::endl << "Best from each generation:" << std::endl;

		for (i=0; i<bests.size(); i++)
			(*out) << i+1 << " -> " << bests[i].toString();
	}

	bool Population::isAchiveableLink(int orLink, int destLink)
	{
		int order;
		time_t start, end;

		time(&start);

		if (orLink == destLink)
		{
			time(&end);
			isAchiveableLinkTime += difftime(end, start);
			return true;
		}

		mapRepresentation::SuperLinkKey oK = map->getSuperLinkKey(orLink);
		mapRepresentation::SuperLinkKey dK = map->getSuperLinkKey(destLink);

		if (oK == dK)
		{
			int diff = map->getSequenceNumber(destLink) - map->getSequenceNumber(orLink) - 1;

			time(&end);
			isAchiveableLinkTime += difftime(end, start);
			return (diff <= params->TOLERANCE_LINKS && diff >= 0);
		}


		std::map<mapRepresentation::SuperLinkKey, set<mapRepresentation::SuperLinkKey> >::iterator it;
		set<mapRepresentation::SuperLinkKey>::iterator sit;

		it = achiveableSuperLinks.find(oK);

		if (it == achiveableSuperLinks.end())
			it = achiveableSuperLinks.insert(make_pair(oK, map->getAllAchievableSuperLinks(oK, params->TOLERANCE_SUPER_LINKS+1, params->TOLERANCE_LINKS))).first;

		sit = it->second.find(dK);

		if (sit != it->second.end())
		{
			order = map->getSequenceNumber(destLink);

			time(&end);
			isAchiveableLinkTime += difftime(end, start);

			return order <= (params->TOLERANCE_LINKS+1);
		}

		time(&end);
		isAchiveableLinkTime += difftime(end, start);
		return false;
	}


	RankedPopulation::RankedPopulation(vector<Individual> * pop)
	{
		int i;

		for (i=0; i<pop->size(); i++)
			rank.insert(&pop->at(i));

		it = rank.begin();
	}

	bool RankedPopulation::hasNext()
	{
		return it != rank.end();
	}

	Individual * RankedPopulation::next()
	{
		Individual * temp = *it;
		it++;
		return temp;
	}
}
