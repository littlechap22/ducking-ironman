
#include "path.h"

Path::Path()
{
	score = 0;
	avgScore = 0;
	pathLength = 0;
	connectAfter = -1;
	connectBefore = -1;
}

Path::~Path()
{

}

Path::Path(const Path &p)
{
	path = p.path;
	score = p.score;
	avgScore = p.avgScore;
	pathLength = p.pathLength;
	firstMatch = p.firstMatch;
	lastMatch = p.lastMatch;
	connectAfter = p.connectAfter;
	connectBefore = p.connectBefore;
}

const Path& Path::operator=(const Path &p)
{
	if (this != &p)
	{
		path = p.path;
		score = p.score;
		avgScore = p.avgScore;
		pathLength = p.pathLength;
		firstMatch = p.firstMatch;
		lastMatch = p.lastMatch;
		connectAfter = p.connectAfter;
		connectBefore = p.connectBefore;
	}
	return *this;
}

void Path::printPath()
{
	unsigned int i;
	std::cout << "Score: " << score << "  Avg: " << avgScore << " Start: " << firstMatch << " Last: " << lastMatch <<  " Links: ";

	for (i = 0; i < path.size(); i++)
		std::cout << "(" << path[i].first << ", " << path[i].second << ")  ";

	std::cout << std::endl << std::endl;
}
